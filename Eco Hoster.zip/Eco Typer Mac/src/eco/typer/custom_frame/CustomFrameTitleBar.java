package eco.typer.custom_frame;
import eco.typer.utils.*;
import eco.typer.listeners.*;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import eco.typer.custom_objects.CButton;
import eco.typer.settings.Settings;

@SuppressWarnings("serial")
public class CustomFrameTitleBar extends JPanel {
	
	public static CButton exit, mini;
	public static JLabel title, rightClickNotif;
	public static JPanel timeColor;
	
	public CustomFrameTitleBar(){	//This class constructs a custom title bar as a jpanel and returns it
		
		setLayout(null);
		
		setBounds(0, 0, Settings.FRAME_WIDTH, 25);
		setBackground(new Color(60, 60, 60));
		
		exit = new CButton("X");
		exit.setBackground(Settings.PRIMARY_COLOR);
		exit.setBounds(Settings.FRAME_WIDTH - 50, 0, 50, 25);
		exit.setBorderPainted(false);
		add(exit);
		exit.addActionListener(e -> {
			System.exit(0);
		});
		
		mini = new CButton("_");
		mini.setBackground(Settings.BACKGROUND_COLOR);
		mini.setBounds(Settings.FRAME_WIDTH - 100, 0, 50, 25);
		add(mini);
		mini.addActionListener(e -> {
			Settings.frame.setState(JFrame.ICONIFIED);
		});
		
		CButton restartTimer = new CButton("Restart Timer");
		restartTimer.setBounds(Settings.FRAME_WIDTH - 150, 0, 150, 25);
		//add(restartTimer);
		
		timeColor = new JPanel();
		timeColor.setBackground(Color.WHITE);
		timeColor.setBounds(30, 0, 10, 25);
		add(timeColor);
		
		title = new JLabel(Settings.FRAME_TITLE);
		title.setForeground(Color.WHITE);
		//title.setHorizontalAlignment(SwingConstants.CENTER);
		Utils.setFont(title, "OpenSans-Regular.ttf", 18);
		title.setBounds(45, 0, Settings.FRAME_WIDTH - 45, 25);
		add(title);
		
		rightClickNotif = new JLabel("--Right Click Anywhere--");
		rightClickNotif.setForeground(Color.LIGHT_GRAY);
		Utils.setFont(rightClickNotif, "OpenSans-Regular.ttf", 18);
		rightClickNotif.setBounds(200, 0, Settings.FRAME_WIDTH - 200, 25);
		add(rightClickNotif);
		
		JLabel icon = new JLabel(Utils.getImage("iconS.png"));
		icon.setBounds(3, -2, 24, 28);
		add(icon);
		
	}

}
