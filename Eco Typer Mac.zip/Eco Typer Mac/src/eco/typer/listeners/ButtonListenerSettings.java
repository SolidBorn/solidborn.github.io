package eco.typer.listeners;
import eco.typer.tabs.*;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import eco.typer.custom_frame.CustomFrame;
import eco.typer.settings.Settings;
import eco.typer.utils.Utils;

public class ButtonListenerSettings implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		case "Save/Load Files":
			if(Utils.getTabCount() > 2)
				Toolkit.getDefaultToolkit().beep();
			else {
				CustomFrame.tabbedPane.add("Save and Load Files", new SaveAndLoadTab());
				Utils.setLastTab();
				Utils.disableButtons();
			}
			break;
		case "Save File":
			if(SaveAndLoadTab.fileNameField.getText().equals("") || SpamTextTab.textArea.getText().equals(""))
				Toolkit.getDefaultToolkit().beep();
			else {
				File fileName = new File(Settings.HOST_FILES_DIR + "/" + SaveAndLoadTab.fileNameField.getText() + ".eco");
				System.out.println(fileName);
				BufferedWriter writer;
				try {
					writer = new BufferedWriter(new FileWriter(fileName));
					writer.write(SpamTextTab.textArea.getText());
					writer.close();
					Utils.closeLastTab();
					Utils.enableButtons();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			break;
		case "Load File":
			if(SaveAndLoadTab.fileList.getSelectedValue() == null)
				Toolkit.getDefaultToolkit().beep();
			else {
				Settings.HOST_NAME = SaveAndLoadTab.fileList.getSelectedValue().toString();
				File fileName = new File(Settings.HOST_FILES_DIR + "/" + Settings.HOST_NAME + ".eco");
				SpamTextTab.textArea.setText("");
				BufferedReader reader;
				try {
					reader = new BufferedReader(new FileReader(fileName));
					String line;
					while((line = reader.readLine()) != null)
						SpamTextTab.textArea.append(line + ",");
					SpamTextTab.textArea.setText(SpamTextTab.textArea.getText().substring(0, SpamTextTab.textArea.getText().length() - 1));
					SpamTextTab.textArea.setText(SpamTextTab.textArea.getText().replaceAll(",", "\n"));
					reader.close();
					Utils.closeLastTab();
					Utils.enableButtons();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			break;
		case "Delete File":
			if(SaveAndLoadTab.fileList.getSelectedValue() == null)
				Toolkit.getDefaultToolkit().beep();
			else {
				File fileName = new File(Settings.HOST_FILES_DIR + "/" + SaveAndLoadTab.fileList.getSelectedValue() + ".eco");
				fileName.delete();
				Utils.closeLastTab();
				CustomFrame.tabbedPane.add("Save and Load Files", new SaveAndLoadTab());
				Utils.setLastTab();
			}
			break;
		case "Set Delay":
			Utils.closeLastTab();
			SpamTextTab.clearAllSpam.setVisible(false);
			Utils.enableButtons();
			SettingsTab.spamSpeed.setEditable(true);
			SettingsTab.spamSpeed.setSelectedItem(SpamSpeedTab.secondsSpinner.getValue());
			SettingsTab.spamSpeed.setEditable(false);
			break;
			
		case "Set Time":
			Utils.closeLastTab();
			SpamTextTab.clearAllSpam.setVisible(false);
			Utils.enableButtons();
			SettingsTab.execTime.setEditable(true);
			SettingsTab.execTime.setSelectedItem(SpamRunningTab.hoursSpinner.getValue() + " : " + SpamRunningTab.minutesSpinner.getValue());
			SettingsTab.execTime.setEditable(false);
			break;
		}
		
	}

}
