package eco.typer.threads;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.Timer;

import eco.typer.Settings.Constants;
import eco.typer.Settings.Settings;
import eco.typer.audio.Audio;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_frame.CustomFrameTitleBar;
import eco.typer.panels.CompactModePanel;
import eco.typer.tools.Utils;

public class TyperThread implements Runnable {
	
	private Thread worker;
	public boolean running;
	private RobotClass bot;
	public boolean breakTyperThread;
	//---
//	public static Audio audio = new Audio("/data/audio/Autumn_Voyage.mid");
	public Audio audio;
	public GameClientChecker clientChecker;
	public CompactModePanel compactPanel;
	public Timer backgroundTimer;
	//---
	private int EXEC_TIME;
	private int TEXT_DELAY_BETWEEN_LINES;
	private int BEGINNING_DELAY;
	private String SCREENSHOT_1;
	private int SCREENSHOT_2 = 0;
	//---
	private String[] textsToType;
	private String executionTime;
	private String spamIntervals;
	private int typingSpeed;
	private String finalCommand;
	private String screenshotIntervals;
	private boolean isScreenshotTimestampsOn;
	private boolean isFinishedAlarmOn;
	private String finishedAlarmSound;
	private boolean is24HourClockOn;
	private String watchClient;

	public TyperThread(String[] textsToType, String executionTime, String spamIntervals, int typingSpeed,
			String finalCommand, String screenshotIntervals, boolean isScreenshotTimestampsOn,
			boolean isFinishedAlarmOn, String finishedAlarmSound, boolean is24HourClockOn, String watchClient) {
		this.textsToType = textsToType;
		this.executionTime = executionTime;
		this.spamIntervals = spamIntervals;
		this.typingSpeed = typingSpeed;
		this.finalCommand = finalCommand;
		this.screenshotIntervals = screenshotIntervals;
		this.isScreenshotTimestampsOn = isScreenshotTimestampsOn;
		this.isFinishedAlarmOn = isFinishedAlarmOn;
		this.finishedAlarmSound = finishedAlarmSound;
		this.is24HourClockOn = is24HourClockOn;
		this.watchClient = watchClient;
		setDefaults();
	}

	public void start() {
		spawnClientWatcherIfNeccessary();
		this.bot = new RobotClass();
		this.breakTyperThread = false;
		worker = new Thread(this);
		worker.start();
	}

	public void stop() {
		this.running = false;
		this.breakTyperThread = true;
		if(this.audio != null)	this.audio.stopAudio();
		if(this.clientChecker != null)	this.clientChecker.stop();
	}
	
	public void pause() {
		this.backgroundTimer.stop();
		this.bot.releaseShift();
		this.running = false;
		this.BEGINNING_DELAY = 5000;
	}
	public void resume() {
		this.running = true;
		this.backgroundTimer.start();
	}

	@Override
	public void run() {
		running = true;
		startTimer();
		int spamLineCounter = 0;
		while(true) {
			if(running) {
				if(this.BEGINNING_DELAY != 0)	sleep(this.BEGINNING_DELAY);	this.BEGINNING_DELAY = 0;
				String line = this.textsToType[spamLineCounter];
				for(char c : line.toCharArray()) {
					if(running) {
						this.bot.typeCharacter(c);
						sleep(this.typingSpeed);
					}
				}
				if(running)	this.bot.pressEnter();
				spamLineCounter++;
				if(spamLineCounter == this.textsToType.length)	spamLineCounter = 0;
				sleep(this.TEXT_DELAY_BETWEEN_LINES);
			}
			if(this.breakTyperThread) break;	//Prevents this thread from multiplying
		}
	}
	
	int timeRem, timeElap;
	private void startTimer() {
		timeRem = this.EXEC_TIME;
		timeElap = 0;
		if(this.is24HourClockOn) {
			Constants.typer.compactPanel.startTime.setText(" Start Time: " + (DateTimeFormatter.ofPattern("HH:mm:ss").format(LocalDateTime.now())));
			Constants.typer.compactPanel.endTime.setText(" End Time: " + (DateTimeFormatter.ofPattern("HH:mm:ss").format(LocalDateTime.now().plusSeconds(this.EXEC_TIME))));
		} else {
			Constants.typer.compactPanel.startTime.setText(" Start Time: " + (DateTimeFormatter.ofPattern("hh:mm:ss").format(LocalDateTime.now())));
			Constants.typer.compactPanel.endTime.setText(" End Time: " + (DateTimeFormatter.ofPattern("hh:mm:ss").format(LocalDateTime.now().plusSeconds(this.EXEC_TIME))));
		}
		backgroundTimer = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!running)
					((Timer)e.getSource()).stop();
				if(timeRem <= 0) {
					Constants.typer.stop();
					unsetCompact();
					executeFinalCommand();
					((Timer)e.getSource()).stop();
					if(Constants.typer.clientChecker != null) Constants.typer.clientChecker.stop();
					if(Constants.typer.audio != null) {
						Constants.typer.audio.playAudio();
						JOptionPane.showMessageDialog(Settings.frame, "Eco Typer has finished.", "Alarm", JOptionPane.WARNING_MESSAGE);
						Constants.typer.audio.stopAudio();
					}
				}
				Constants.typer.compactPanel.remainingTime.setText(" Remaining Time: " + Integer.toString(timeRem / 3600) + " : " + Integer.toString((timeRem % 3600) / 60) + " : " + Integer.toString(timeRem % 60));
				Constants.typer.compactPanel.elapsedTime.setText(" Elapsed Time: " + Integer.toString(timeElap / 3600) + " : " + Integer.toString((timeElap % 3600) / 60) + " : " + Integer.toString(timeElap % 60));
				CustomFrameTitleBar.title.setText(Constants.FRAME_TITLE + "[ " + Integer.toString(timeRem / 3600) + " : " + Integer.toString((timeRem % 3600) / 60) + " : " + Integer.toString(timeRem % 60) + " ]");
				if(!running) CustomFrameTitleBar.title.setText(Constants.FRAME_TITLE);
				timeRem--;
				timeElap++;
				checkScreenshot();
			}

			private void checkScreenshot() {
				switch(Constants.typer.screenshotIntervals) {
				case "Screenshots: 15 Minutes":
					if(timeRem % 900 == 0)
						takeScreenshot();
					break;
				case "Screenshots: 30 Minutes":
					if(timeRem % 1800 == 0)
						takeScreenshot();
					break;
				case "Screenshots: 45 Minutes":
					if(timeRem % 2700 == 0)
						takeScreenshot();
					break;
				case "Screenshots: 1 Hour":
					if(timeRem % 3600 == 0)
						takeScreenshot();
					break;
				}
			}

			private void executeFinalCommand() {
				switch(Constants.OPERATING_SYSTEM) {
				case "Windows":
					switch(Constants.typer.finalCommand) {
					case "Final Command":
					case "Do Nothing":
						break;
					case "Close RuneScape Client":
						//TODO
						break;
					case "Close Eco Typer":
						System.exit(0);
						break;
					case "Close RuneScape Client and Eco":
						//TODO
						System.exit(0);
						break;
					case "Logoff Computer":
						//TODO
						break;
					case "Restart Computer":
						//TODO
						break;
					case "Shutdown Computer":
						//TODO
						break;
					}
					break;
				case "Mac":
				case "Linux":
					switch(Constants.typer.finalCommand) {
					case "Final Command":
					case "Do Nothing":
						break;
					case "Close RuneScape Client":
						//TODO
						break;
					case "Close Eco Typer":
						System.exit(0);
						break;
					case "Close RuneScape Client and Eco":
						//TODO
						System.exit(0);
						break;
					}
					break;
				default:
						
					break;
				}
			}
    	});
		backgroundTimer.start();
	}

	
	
	
	private void checkScreenshot() {
		if(!Constants.typer.screenshotIntervals.equals("Screenshots: Off")) {
			DateFormat dateFormat = new SimpleDateFormat("MM-dd-yy  (HH mm ss)");
			SCREENSHOT_1 = dateFormat.format(new Date());
			File screenshotFolder = new File(Constants.SCREENSHOT_DIRECTORY + "/" + SCREENSHOT_1);
			screenshotFolder.mkdir();
		}
	}
	private void takeScreenshot() {
		while(new File(Constants.SCREENSHOT_DIRECTORY + "/" + SCREENSHOT_1 + "/" + SCREENSHOT_2 + ".png").exists())
			SCREENSHOT_2++;
		String fileName = Constants.SCREENSHOT_DIRECTORY + "/" + SCREENSHOT_1 + "/" + SCREENSHOT_2 + ".png";
		if(Constants.typer.isScreenshotTimestampsOn) {
			Robot robot = null;
			try { robot = new Robot(); } catch (AWTException e) {}
			
			Rectangle screenRect = new Rectangle(0, 0, 0, 0);
			for(GraphicsDevice gd : GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices())
				screenRect = screenRect.union(gd.getDefaultConfiguration().getBounds());
			BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
			try {	ImageIO.write(screenFullImage, "png", new File(fileName));	} catch (IOException e) {}
		} else {
			Utils.TimeStampScreenshot(fileName);
		}
	}
	
	private void sleep(int i) {
		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			Utils.writeErrorReport(e, 142);
		}
	}

	private void setDefaults() {
		this.BEGINNING_DELAY = 5000;
		this.compactPanel = new CompactModePanel();
		formatExecutionTime();
		formatSpamInterval();
		setCompact();
		if(this.isFinishedAlarmOn == true)
			if(this.finishedAlarmSound.equals("Alarm Sound"))
				this.audio = new Audio("/data/audio/Simpsons.mid");
			else
				this.audio = new Audio("/data/audio/" + this.finishedAlarmSound + ".mid");
		System.err.println("--- Pause Button isn't coded yet --- " + "\n" + "--- Compact Mode (Just needs to test on mac) --- " + "\n" + "--- Game Client Checker (Just needs to test)  --- " + "\n" + "--- Final Command (Need to finish filling it and test) --- ");
		CustomFrame.settingsPanel.startButton.setBackground(Constants.PRIMARY_COLOR);
	}

	private void setCompact() {
		if(Constants.OPERATING_SYSTEM.equals("Windows"))
			Settings.frame.setLocation(0, 0);
		else
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - Constants.FRAME_WIDTH, 0);
		Settings.frame.setSize(Constants.FRAME_WIDTH, 25);
		CustomFrame.updateDisplay(compactPanel);
		CustomFrame.leftSelectionMenu.freeze();
		CustomFrameTitleBar.mini.setVisible(false);
		CustomFrameTitleBar.exit.setVisible(false);
		CustomFrameTitleBar.pauseButton.setVisible(true);
		CustomFrameTitleBar.stopButton.setVisible(true);
	}
	
	public void unsetCompact() {
		Settings.frame.setSize(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
		CustomFrameTitleBar.title.setText(Constants.FRAME_TITLE);
		CustomFrame.updateDisplay(CustomFrame.lastVisitedPanel);
		CustomFrame.leftSelectionMenu.unfreeze();
		CustomFrameTitleBar.mini.setVisible(true);
		CustomFrameTitleBar.exit.setVisible(true);
		CustomFrameTitleBar.pauseButton.setVisible(false);
		CustomFrameTitleBar.stopButton.setVisible(false);
	}

	private void spawnClientWatcherIfNeccessary() {
		checkScreenshot();
		switch(this.watchClient) {
		case "Watch Client: Rs3":
			this.clientChecker = new GameClientChecker(0);
			this.clientChecker.start();
			break;
		case "Watch Client: OSRS":
			this.clientChecker = new GameClientChecker(1);
			this.clientChecker.start();
			break;
		case "Watch Client: RuneLite":
			this.clientChecker = new GameClientChecker(2);
			this.clientChecker.start();
			break;
		case "Watch Client: Off":
			break;
		default:
			Utils.writeErrorReport(new IllegalStateException(), 849);
			break;
		}
	}
	
	private void formatExecutionTime() {
		switch(this.executionTime) {	//Set in Seconds
		case "1 Minute(s)":
			this.EXEC_TIME = 60 + 1;
			break;
		case "15 Minute(s)":
			this.EXEC_TIME = 900 + 1;
			break;
		case "30 Minute(s)":
			this.EXEC_TIME = 1800 + 1;
			break;
		case "45 Minute(s)":
			this.EXEC_TIME = 2700 + 1;
			break;
		case "1 Hour(s)":
			this.EXEC_TIME = 3600 + 1;
			break;
		case "2 Hour(s)":
			this.EXEC_TIME = 7200 + 1;
			break;
		default:
			int hours = Integer.parseInt(this.executionTime.substring(0, 2));
			int minutes = Integer.parseInt(this.executionTime.substring(13, 15));
			this.EXEC_TIME = (60 * (60 * hours) + 60 * minutes) + 1;
			break;
		}
	}
	
	private void formatSpamInterval() {
		switch(this.spamIntervals) {
		case "0 Second(s)":
			this.TEXT_DELAY_BETWEEN_LINES = 100;
			break;
		case "1 Second(s)":
			this.TEXT_DELAY_BETWEEN_LINES = 1000;
			break;
		case "2 Second(s)":
			this.TEXT_DELAY_BETWEEN_LINES = 2000;
			break;
		case "4 Second(s)":
			this.TEXT_DELAY_BETWEEN_LINES = 4000;
			break;
		case "7 Second(s)":
			this.TEXT_DELAY_BETWEEN_LINES = 7000;
			break;
		default:
			this.TEXT_DELAY_BETWEEN_LINES = 1000 * Integer.parseInt(this.spamIntervals.replace(" Second(s)", ""));
			break;

		}
	}

}







































class RobotClass {
	
	private Robot bot;

	public RobotClass() {
		try {
			this.bot = new Robot();
		} catch (AWTException e) {
			Utils.writeErrorReport(e, 230);
		}
	}

	public void typeCharacter(char c) {
		if (Constants.shiftCases.contains(c)) {
			bot.keyPress(KeyEvent.VK_SHIFT);
			bot.delay(35);
		}
		int keyStroke = Constants.mapStrokes.get(Character.toLowerCase(c));
		try {
		    bot.keyPress(keyStroke);
		    bot.keyRelease(keyStroke);
		} catch (IllegalArgumentException e1) {
			Utils.writeErrorReport(e1, 050);
		}
		if (Constants.shiftCases.contains(c)) {
			bot.delay(35);
			bot.keyRelease(KeyEvent.VK_SHIFT);
		}
	}
	
	public void pressEnter() {
		bot.keyPress(KeyEvent.VK_ENTER);
		bot.delay(35);
		bot.keyRelease(KeyEvent.VK_ENTER);
	}
	
	public void releaseShift() {
		bot.keyRelease(KeyEvent.VK_SHIFT);
	}
	
}