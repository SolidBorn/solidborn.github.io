package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.listeners.*;
import eco.typer.settings.*;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class ThemeChooser extends JPanel {
	
	public ThemeChooser() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addColors();
		
		JLabel changeNote = new JLabel("Theme will apply after program restart");
		changeNote.setBounds(5, 260, 400, 30);
		changeNote.setHorizontalAlignment(SwingConstants.CENTER);
		changeNote.setForeground(Settings.PRIMARY_COLOR);
		add(changeNote);
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(410, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
	}
	
	private void addColors() {
		CButton blue = new CButton(null, Color.BLUE);
		blue.setActionCommand("Blue");
		blue.setBounds(5, 195, 160, 40);
		blue.addActionListener(new ButtonListenerThemes());
		add(blue);
		CButton green = new CButton(null, Color.GREEN);
		green.setActionCommand("Green");
		green.setBounds(5, 30, 160, 160);
		green.addActionListener(new ButtonListenerThemes());
		add(green);
		CButton yellow = new CButton(null, Color.YELLOW);
		yellow.setActionCommand("Yellow");
		yellow.setBounds(170, 30, 125, 90);
		yellow.addActionListener(new ButtonListenerThemes());
		add(yellow);
		CButton pink = new CButton(null, Color.PINK);
		pink.setActionCommand("Pink");
		pink.setBounds(170, 125, 160, 65);
		pink.addActionListener(new ButtonListenerThemes());
		add(pink);
		CButton cyan = new CButton(null, Color.CYAN);
		cyan.setActionCommand("Cyan");
		cyan.setBounds(170, 195, 100, 40);
		cyan.addActionListener(new ButtonListenerThemes());
		add(cyan);
		CButton red = new CButton(null, Color.RED);
		red.setActionCommand("Red");
		red.setBounds(275, 195, 55, 40);
		red.addActionListener(new ButtonListenerThemes());
		add(red);
		CButton orange = new CButton(null, Color.ORANGE);
		orange.setActionCommand("Orange");
		orange.setBounds(335, 125, 85, 110);
		orange.addActionListener(new ButtonListenerThemes());
		add(orange);
		CButton magenta = new CButton(null, Color.MAGENTA);
		magenta.setActionCommand("Magenta");
		magenta.setBounds(425, 125, 40, 80);
		magenta.addActionListener(new ButtonListenerThemes());
		add(magenta);
		CButton custom1 = new CButton(null, new Color(11, 117, 115));
		custom1.setActionCommand("Custom 1");
		custom1.setBounds(300, 30, 165, 90);
		custom1.addActionListener(new ButtonListenerThemes());
		add(custom1);
		CButton custom2 = new CButton(null, new Color(30, 144, 255));
		custom2.setActionCommand("Custom 2");
		custom2.setBounds(425, 210, 145, 25);
		custom2.addActionListener(new ButtonListenerThemes());
		add(custom2);
		CButton custom3 = new CButton(null, new Color(105, 139, 34));
		custom3.setActionCommand("Custom 3");
		custom3.setBounds(470, 95, 100, 110);
		custom3.addActionListener(new ButtonListenerThemes());
		add(custom3);
		CButton custom4 = new CButton(null, new Color(72, 61, 139));
		custom4.setActionCommand("Custom 4");
		custom4.setBounds(575, 95, 27, 140);
		custom4.addActionListener(new ButtonListenerThemes());
		add(custom4);
		CButton custom5 = new CButton(null, new Color(238, 64, 0));
		custom5.setActionCommand("Custom 5");
		custom5.setBounds(470, 30, 133, 60);
		custom5.addActionListener(new ButtonListenerThemes());
		add(custom5);
	}

}
