package eco.typer.utils;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListModel;

import eco.typer.custom_frame.CustomFrame;
import eco.typer.settings.Settings;
import eco.typer.tabs.*;

public class Utils {
	/**
	 * This class has a multitude of different methods that don't fit anywhere specific.
	 * Think of this class as a screwdriver class, it's used for many different functions throughout the program
	 */
	
	public static void setFont(Component c, String fontName, float size) {
		try {
			Font font = Font.createFont(0, Utils.class.getResource("/data/fonts/" + fontName).openStream());
			GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
			genv.registerFont(font);
			font = font.deriveFont(size);
			c.setFont(font);
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void openWebpage(String url) {
	    Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
	    if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
	        try {
	            desktop.browse(new URL(url).toURI());
	        } catch (Exception e) {
	           // e.printStackTrace();
	        }
	    }
	}
	
	public static ImageIcon getImage(String name) {
		return new ImageIcon(Utils.class.getResource("/data/img/" + name));
	}
	
	public static int getTabCount() {
		return CustomFrame.tabbedPane.getTabCount();
	}
	
	public static void closeLastTab() {
		CustomFrame.tabbedPane.remove(CustomFrame.tabbedPane.getTabCount() - 1);
	}
	
	public static void setLastTab() {
		CustomFrame.tabbedPane.setSelectedIndex(CustomFrame.tabbedPane.getTabCount() - 1);
	}
	
	public static ListModel<String> getSavedFiles() {
		DefaultListModel<String> filesList = new DefaultListModel<String>();
		File[] files = Settings.HOST_FILES_DIR.listFiles();
		for(File f : files)
			if(f.isFile())
				filesList.add(0, f.getName().replaceAll(".eco", ""));
		return filesList;
	}
	
	public static void disableButtons() {
		SpamTextTab.addSpam.setEnabled(false);
		SpamTextTab.editSpam.setEnabled(false);
		SettingsTab.start.setEnabled(false);
		SettingsTab.loadFile.setEnabled(false);
		SettingsTab.execTime.setEnabled(false);
		SettingsTab.spamSpeed.setEnabled(false);
	}
	
	public static void enableButtons() {
		SpamTextTab.addSpam.setEnabled(true);
		SpamTextTab.editSpam.setEnabled(true);
		SettingsTab.start.setEnabled(true);
		SettingsTab.loadFile.setEnabled(true);
		SettingsTab.execTime.setEnabled(true);
		SettingsTab.spamSpeed.setEnabled(true);
	}
	
	public static void TimeStampScreenshot(String fileName) {
		try {
			Robot robot = null;
			try {	robot = new Robot();	} catch (AWTException e) {}
			Rectangle screenRect = new Rectangle(0, 0, 0, 0);
			for(GraphicsDevice gd : GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices())
				screenRect = screenRect.union(gd.getDefaultConfiguration().getBounds());
			DateFormat dateForm = new SimpleDateFormat("HH:mm:ss");
			BufferedImage bi = robot.createScreenCapture(screenRect);
			Graphics2D graphics = bi.createGraphics();
			Font font = new Font("Sans Serif", Font.BOLD, 60);
			graphics.setFont(font);
			graphics.setColor(Settings.PRIMARY_COLOR);
			graphics.drawString("Eco Typer - Made By Dakota", 10, (int) ((screenRect.getHeight() / 2) - 50));
			graphics.drawString("Time - " + dateForm.format(new Date()), 10, (int) (screenRect.getHeight() / 2));
			graphics.drawString("Host - " + Settings.HOST_NAME, 10, (int) ((screenRect.getHeight() / 2) + 50));
			bi.flush();
			ImageIO.write(bi, "png", new File(fileName));
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Something went wrong when trying to take a Time Stamp");
		}
	}
	
	public static FrameProperities loadCache() {
		FrameProperities fp = null;
		if(new File(System.getProperty("user.home") + "/Eco Typer/Cache").exists())
			fp = deserializeData(fp);
		else {
			fp = new FrameProperities();
			fp.color = Color.GREEN.darker();
			fp.spam1 = "[Name] Altar/Obby/Glory/Sips [Name]";
			fp.spam2 = "[Name] Altar/Obby/No Lag/Glory [Name]";
			fp.spam3 = "[ Name ] [ Name ] [ Name ] [ Name]";
			fp.spam4 = "[ Name ] <<< .H.O.S.T >>> [ Name ]";
			fp.spam5 = "Host: { Name }";
			fp.spam6 = "> Name < Newly Opened / No Lag > Name <";
		}
		return fp;
	}
	
	public static FrameProperities deserializeData(FrameProperities fp) {
		try {
			FileInputStream fileIn = new FileInputStream(System.getProperty("user.home") + "/Eco Typer/Cache");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			fp = (FrameProperities) in.readObject();
			in.close();
			fileIn.close();
		} catch (ClassNotFoundException | IOException e) {
			JOptionPane.showMessageDialog(null, "There was an error.\nPlease go to your root directory -> Your Name -> Eco Typer and delete the Cache file.\nReload the program and it should work now", "Cache Error", JOptionPane.ERROR_MESSAGE);
		}
		return fp;
	}
	
	public static void serializeFrameData() {
		FrameProperities fp = new FrameProperities();
		fp.color = Settings.PRIMARY_COLOR;
		fp.spam1 = Settings.SPAM_LINE_1;
		fp.spam2 = Settings.SPAM_LINE_2;
		fp.spam3 = Settings.SPAM_LINE_3;
		fp.spam4 = Settings.SPAM_LINE_4;
		fp.spam5 = Settings.SPAM_LINE_5;
		fp.spam6 = Settings.SPAM_LINE_6;
		
		try {
			FileOutputStream outStream = new FileOutputStream(System.getProperty("user.home") + "/Eco Typer/Cache");
			ObjectOutputStream out = new ObjectOutputStream(outStream);
			out.writeObject(fp);
			out.close();
			outStream.close();
			System.out.println("Serialized Data now stored in " + System.getProperty("user.home") + "/Eco Typer/Cache");
		} catch (IOException e) {
			System.err.println("Something went wrong when trying to write serialized data (Utils Class)");
			e.printStackTrace();
		}
	}
	
}
