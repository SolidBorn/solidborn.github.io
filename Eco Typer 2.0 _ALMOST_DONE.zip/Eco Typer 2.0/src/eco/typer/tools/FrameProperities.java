package eco.typer.tools;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class FrameProperities implements Serializable {
	
	public Color color;
	public double totalProfit;
	public String notepadText;
	public ArrayList<MoneyCounter> profitCounter;

}
