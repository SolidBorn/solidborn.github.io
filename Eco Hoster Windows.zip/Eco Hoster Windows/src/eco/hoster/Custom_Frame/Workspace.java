package eco.hoster.Custom_Frame;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class Workspace extends JPanel {
	
	private final int WORKSPACE_WIDTH = Settings.FRAME_WIDTH - 310;
	private final int WORKSPACE_HEIGHT = Settings.FRAME_HEIGHT;
	
	public JLabel rightClickNotif;
	
	public Workspace() {
		setProperities();
		setRightClickNotification();
		
		//TODO
	}
	
	private void setRightClickNotification() {
		rightClickNotif = new JLabel("--Right Click Anywhere--");
		rightClickNotif.setForeground(Color.LIGHT_GRAY);
		rightClickNotif.setHorizontalAlignment(JLabel.CENTER);
		rightClickNotif.setBounds(0, 0, this.WORKSPACE_WIDTH, this.WORKSPACE_HEIGHT);
		Utils.setFont(rightClickNotif, "OpenSans-Regular.ttf", 18);
		add(rightClickNotif);
	}

	private void setProperities() {
		setLayout(null);
		setBounds(160, 0, this.WORKSPACE_WIDTH, this.WORKSPACE_HEIGHT);
		setBackground(new Color(60, 60, 60));
	}

}
