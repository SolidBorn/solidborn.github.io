package typer.Tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import typer.Settings.CustomFrame;
import typer.Settings.Settings;
import typer.Tabs.CentralPanel;

public class HostUpdaterThread implements Runnable {
	
	private Thread worker;
    private boolean running;
    private int interval;
    
    public HostUpdaterThread() {
    	interval = 30000;
        running = false;
    }
    
    public void start() {
        worker = new Thread(this);
        worker.start();
    }
  
    public void stop() {
        running = false;
    }
    
	public void run() {
		running = true;
		while(running) {
			
			Settings.allHosts = new ArrayList<Host>();
			if(CentralPanel.tableModel.getRowCount() > 0) {
			    for (int i = CentralPanel.tableModel.getRowCount() - 1; i > -1; i--) {
			    	CentralPanel.tableModel.removeRow(i);
			    }
			}
			Website site = new Website();
			CustomFrame.updateStatus("Fetching Rs3 Hosts...");
			site.populateRs3Hosts();
			CustomFrame.updateStatus("Fetching OSRS Hosts...");
			site.populateOSRSHosts();
			for(Host h : Settings.allHosts)
				CentralPanel.tableModel.addRow(new Object[]{h.getServer(), h.getUsername(), h.getWorld(), h.getLocation()});
			
			for(int i = interval; i > 0; i = i - 1000) {
				CustomFrame.updateStatus("Refreshing Hosts in " + i / 1000 + " seconds");
				try { 
	                Thread.sleep(1000); 
	            } catch (InterruptedException e){ 
	                Thread.currentThread().interrupt();
	                System.out.println("Thread was interrupted, Failed to complete operation");
	            }
			}
			
		}
	}

}

class Website {
	
	private String websiteData;
	
	public Website() {
		String status = "Try again";
		int tryCount = 0;
		
		while(status.equals("Try again")) {
			try {
				
				URL url = new URL(Settings.TEXTFILE_LINK);
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
				String line;
				while((line = reader.readLine()) != null) {
					websiteData += " " + line;
				}
				reader.close();
				
				if(!websiteData.contains("RS3 Hosts"))
					websiteData = "";
				else
					status = "Stop";
			} catch(IOException e) {
				tryCount++;
				CustomFrame.updateStatus("Connection Failed... Attempting to reconnect... " + tryCount + " ");
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
//				if(tryCount >= 7)
//					break;
			}
		}
	}
	
	public void populateRs3Hosts() {
		String webString = this.websiteData;
		if(webString != null)
		try {
			
			webString = webString.substring(webString.indexOf("RS3"), webString.length());
			webString = webString.substring(webString.indexOf('[') + 1, webString.indexOf(']'));
			if(webString.contains("}, {")) webString = webString.replace("}, {", "\n");
			webString = webString.substring(1, webString.length() - 1);
			
			String[] datas = webString.split("\n");
			for(int i = 0; i < datas.length; i++) {	//This will loop through every single rs3 host
				String currentLine = datas[i];
				currentLine = currentLine.replace(", ", " ");
				currentLine = currentLine.replace("\"loc\": ", "\"loc\":");
				currentLine = currentLine.replace("\"World\": ", "\"World\":");
				currentLine = currentLine.replace("\"Username\": ", "\"Username\":");
				currentLine = currentLine.replace("\"Username\":\"", "\"Username:");
				currentLine = currentLine.replace("\"loc\":\"", "\"loc:");
				currentLine = currentLine.replace("\"World\":", "\"World:");
				currentLine = currentLine.replaceAll("\" \"", "\"\"");
				currentLine = currentLine.replace(" \"", "\"\"");
				if(!currentLine.substring(currentLine.length() - 1, currentLine.length()).equals("\"")) currentLine = currentLine + "\"";
				currentLine = currentLine.replaceAll(" ", "_");
				currentLine = currentLine.replace("\"\"", "\n");
				currentLine = currentLine.substring(1, currentLine.length() - 1);
				currentLine = currentLine.replaceAll("_", " ");
				String[] subData = currentLine.split("\n");
				String[] hostData = new String[3];
				for(int j = 0; j < subData.length; j++) {
					if(subData[j].contains("Username:"))
						hostData[0] = subData[j].replace("Username:", "");
					if(subData[j].contains("World:"))
						hostData[1] = subData[j].replace("World:", "");
					if(subData[j].contains("loc:"))
						hostData[2] = subData[j].replace("loc:", "");
				}
				Settings.allHosts.add(new Host("RS3", hostData[0], hostData[1], hostData[2]));
			}
			
		} catch(Exception e) {
//			e.printStackTrace();
			System.err.println("Couldn't read in rs3 Host");
		}
		
	}
	
	public void populateOSRSHosts() {
		String webString = this.websiteData;
		if(webString != null)
		try {
		
			webString = webString.substring(webString.indexOf("OSRS"), webString.length());
			webString = webString.substring(webString.indexOf('[') + 1, webString.indexOf(']'));
			if(webString.contains("}, {")) webString = webString.replace("}, {", "\n");
			webString = webString.substring(1, webString.length() - 1);
			
			String[] datas = webString.split("\n");
			for(int i = 0; i < datas.length; i++) {	//This will loop through every single osrs host
				String currentLine = datas[i];
				currentLine = currentLine.replace(", ", " ");
				currentLine = currentLine.replace("\"loc\": ", "\"loc\":");
				currentLine = currentLine.replace("\"World\": ", "\"World\":");
				currentLine = currentLine.replace("\"Username\": ", "\"Username\":");
				currentLine = currentLine.replace("\"Username\":\"", "\"Username:");
				currentLine = currentLine.replace("\"loc\":\"", "\"loc:");
				currentLine = currentLine.replace("\"World\":", "\"World:");
				currentLine = currentLine.replaceAll("\" \"", "\"\"");
				currentLine = currentLine.replace(" \"", "\"\"");
				if(!currentLine.substring(currentLine.length() - 1, currentLine.length()).equals("\"")) currentLine = currentLine + "\"";
				currentLine = currentLine.replaceAll(" ", "_");
				currentLine = currentLine.replace("\"\"", "\n");
				currentLine = currentLine.substring(1, currentLine.length() - 1);
				currentLine = currentLine.replaceAll("_", " ");
				String[] subData = currentLine.split("\n");
				String[] hostData = new String[3];
				for(int j = 0; j < subData.length; j++) {
					if(subData[j].contains("Username:"))
						hostData[0] = subData[j].replace("Username:", "");
					if(subData[j].contains("World:"))
						hostData[1] = subData[j].replace("World:", "");
					if(subData[j].contains("loc:"))
						hostData[2] = subData[j].replace("loc:", "");
				}
				Settings.allHosts.add(new Host("OSRS", hostData[0], hostData[1], hostData[2]));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			System.err.println("Couldn't read in osrs Host");
		}
	}

}