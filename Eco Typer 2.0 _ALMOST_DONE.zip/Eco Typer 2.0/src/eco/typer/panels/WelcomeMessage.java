package eco.typer.panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.plaf.basic.BasicScrollBarUI;

import eco.typer.Settings.Constants;
import eco.typer.Settings.Settings;
import eco.typer.custom_frame.CPanel;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_objects.*;
import eco.typer.tools.MediaFire;
import eco.typer.tools.Utils;

@SuppressWarnings("serial")
public class WelcomeMessage extends CPanel {
	
	public WelcomeMessage() {
		super("");	//This is the only exeption
		
		JLabel icon = new JLabel(Utils.getImage("eco.png"));
		icon.setBackground(Color.WHITE);
		icon.setBounds(10, 10, 100, 100);
		add(icon);
		
		JLabel title = new JLabel(Constants.FRAME_TITLE);
		title.setBounds(130, 10, CustomFrame.WORKPANEL_WIDTH - 130, 50);
		title.setForeground(Color.WHITE);
		Utils.setFont(title, "Neon.ttf", 50);
		add(title);
		
		if(Constants.isUpdate == 1) {
			CButton updateButton = new CButton("Update Available - Click to Download", Color.RED);
			updateButton.setBounds(130, 70, 300, 30);
			updateButton.setActionCommand("Download_Update");
			updateButton.addActionListener(e -> {
				Settings.frame.dispose();
				MediaFire downloader = new MediaFire();
				try {
					downloader.download(Constants.DOWNLOAD_LINK, System.getProperty("user.dir") + "/Eco Typer Mac_Update");
					JOptionPane.showMessageDialog(Settings.frame, "Update Successful\n\nYou'll have to unpack the \"Eco Typer_Update.zip\" yourself.", "Eco Typer Update", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					Utils.writeErrorReport(e1, 111);
				}
			});
			add(updateButton);
			
			JTextArea updateDescription = new JTextArea(Constants.UPDATE_DESCRIPITION);
			updateDescription.setBackground(Constants.BACKGROUND_COLOR);
			updateDescription.setForeground(Color.WHITE);
			updateDescription.setEditable(false);
			updateDescription.setHighlighter(null);
			updateDescription.setWrapStyleWord(true);
			updateDescription.setLineWrap(true);
			JScrollPane sp = new JScrollPane(updateDescription);
			sp.getVerticalScrollBar().setUI(new CScrollBar());
			sp.setBorder(null);
			sp.setBounds(10, 110, CustomFrame.WORKPANEL_WIDTH - 20, CustomFrame.WORKPANEL_HEIGHT - 110);
			add(sp);
		} else if(Constants.isUpdate == -1){
			JLabel noUpdateText = new JLabel("You're running the most up to date version");
			noUpdateText.setForeground(Color.WHITE);
			noUpdateText.setBounds(130, 70, CustomFrame.WORKPANEL_WIDTH - 130, 30);
			add(noUpdateText);
			
			if(Constants.isAlert) {
				JLabel alertIcon = new JLabel(Utils.getImage("alert.png"));
				alertIcon.setBounds(10, 110, 32, 32);
				add(alertIcon);
				
				JTextArea updateDescription = new JTextArea(Constants.ALERT);
				updateDescription.setBackground(Constants.BACKGROUND_COLOR);
				updateDescription.setForeground(Color.WHITE);
				updateDescription.setEditable(false);
				updateDescription.setHighlighter(null);
				updateDescription.setWrapStyleWord(true);
				updateDescription.setLineWrap(true);
				JScrollPane sp = new JScrollPane(updateDescription);
				sp.getVerticalScrollBar().setUI(new CScrollBar());
				sp.setBorder(null);
				sp.setBounds(55, 110, CustomFrame.WORKPANEL_WIDTH - 65, CustomFrame.WORKPANEL_HEIGHT - 110);
				add(sp);
			}
		} else {
			JLabel noUpdateText;
			if(Constants.isUpdate == 0 && Settings.speedUpBoot == true) {
				noUpdateText = new JLabel("YOU ARE IN DEVELOPER MODE, SPEEDUP IS ENABLED - TURN OFF FOR RELEASE");
				noUpdateText.setForeground(Color.CYAN);
			}
			else {
				noUpdateText = new JLabel("We could not determine if there is an update");
				noUpdateText.setForeground(Color.ORANGE);
			}
			noUpdateText.setBounds(130, 70, CustomFrame.WORKPANEL_WIDTH - 130, 30);
			add(noUpdateText);
		}
	}

}

class CScrollBar extends BasicScrollBarUI {
	private final Dimension d = new Dimension();

	@SuppressWarnings("serial")
	@Override
	protected JButton createDecreaseButton(int orientation) {
		return new JButton() {
			@Override
			public Dimension getPreferredSize() {
				return d;
			}
		};
	}

	@SuppressWarnings("serial")
	@Override
	protected JButton createIncreaseButton(int orientation) {
		return new JButton() {
			@Override
			public Dimension getPreferredSize() {
				return d;
			}
		};
	}

	@Override
	protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
		g.setColor(Constants.BACKGROUND_COLOR);
		g.fillRect(r.x, r.y, r.width, r.height);
	}

	@Override
	protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		Color color = null;
		JScrollBar sb = (JScrollBar) c;
		if (!sb.isEnabled() || r.width > r.height) {
			return;
		} else if (isDragging) {
			color = Color.DARK_GRAY;
		} else if (isThumbRollover()) {
			color = Color.LIGHT_GRAY;
		} else {
			color = Color.GRAY;
		}
		g2.setPaint(color);
		g2.fillRoundRect(r.x, r.y, r.width, r.height, 10, 10);
		g2.setPaint(Constants.PRIMARY_COLOR);
		g2.drawRoundRect(r.x, r.y, r.width, r.height, 10, 10);
		g2.dispose();
	}

	@Override
	protected void setThumbBounds(int x, int y, int width, int height) {
		super.setThumbBounds(x, y, width, height);
		scrollbar.repaint();
	}
	
}