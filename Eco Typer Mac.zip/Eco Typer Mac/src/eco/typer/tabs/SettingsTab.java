package eco.typer.tabs;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_objects.*;
import eco.typer.listeners.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.geom.GeneralPath;
import java.util.Dictionary;
import java.util.Hashtable;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicSliderUI;

import eco.typer.settings.Settings;
import eco.typer.utils.Utils;

@SuppressWarnings("serial")
public class SettingsTab extends JPanel {
	
	/**
	 * This class is busy, but it contains everything in the settings tab
	 * including some listeners and a custom slider UI
	 */
	public static CButton start, loadFile;
	public static CComboBox spamSpeed, execTime, finishCommand, hourlyScreenshot;
	public static CTextField startTime, endTime, elapsedTime, remainingTime;
	public static CCheckBox compactMode, alwaysOnTop, ssTimeStamp, finishAlarm;
	public static IconLabel infoForm, developerMessage, screenshots, themeChooser, emailMe, iconFieldText;
	public static JSlider typeSpeedSlider;
	
	public SettingsTab() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addComboBoxes();
		addTextFields();
		addCheckBoxes();
		addButtons();
	}
	
	private void addComboBoxes() {
		spamSpeed = new CComboBox("Spam Intervals", Settings.SPAM_SPEED_OPTIONS);
		spamSpeed.setBounds(10, 10, 190, 30);
		spamSpeed.addActionListener(e -> {
			if(spamSpeed.getSelectedItem().toString().equals("Custom Delay Time"))
				if(Utils.getTabCount() > 2)
					Toolkit.getDefaultToolkit().beep();
				else {
					CustomFrame.tabbedPane.add("Custom Delay Time", new SpamSpeedTab());
					Utils.setLastTab();
					Utils.disableButtons();
				}
		});
		add(spamSpeed);
		
		execTime = new CComboBox("Execution Time", Settings.EXEC_TIME_OPTIONS);
		execTime.setBounds(10, 50, 190, 30);
		execTime.addActionListener(e -> {
			if(execTime.getSelectedItem().toString().equals("Custom Time"))
				if(Utils.getTabCount() > 2)
					Toolkit.getDefaultToolkit().beep();
				else {
					CustomFrame.tabbedPane.add("Custom Running Time", new SpamRunningTab());
					Utils.setLastTab();
					Utils.disableButtons();
				}
		});
		add(execTime);
		
		finishCommand = new CComboBox("Final Command", Settings.FINISHING_COMMAND_OPTIONS);
		finishCommand.setBounds(210, 10, 390, 30);
		add(finishCommand);
		
		typeSpeedSlider = new JSlider(10, 50);
		typeSpeedSlider.setLabelTable(labelTable());
		typeSpeedSlider.setUI(new CustomSliderUI(typeSpeedSlider));
		TitledBorder sliderBorder = new TitledBorder(new LineBorder(Color.LIGHT_GRAY, 1), "Typing Speed");
		sliderBorder.setTitleColor(Color.WHITE);
		typeSpeedSlider.setBorder(sliderBorder);
		typeSpeedSlider.setSnapToTicks(true);
		typeSpeedSlider.setFocusable(false);
		typeSpeedSlider.setBounds(210, 50, 390, 60);
		typeSpeedSlider.setBackground(null);
		typeSpeedSlider.setPaintTicks(true);
		typeSpeedSlider.setPaintLabels(true);
		typeSpeedSlider.setMajorTickSpacing(20);
		typeSpeedSlider.setMinorTickSpacing(5);
		add(typeSpeedSlider);
	}

	@SuppressWarnings("rawtypes")
	private Dictionary labelTable() {
		JLabel fastLabel = new JLabel("Fastest");
		fastLabel.setForeground(Color.WHITE);
		JLabel slowLabel = new JLabel("Slowest");
		slowLabel.setForeground(Color.WHITE);
		Dictionary<Integer, Component> labelTable = new Hashtable<Integer, Component>();
		labelTable.put(10, fastLabel);
		labelTable.put(50, slowLabel);
		return labelTable;
	}
	
	private void addTextFields() {
		startTime = new CTextField("Start Time:", "dark", false);
		startTime.setBounds(10, 90, 190, 30);
		startTime.setBorder(null);
		startTime.setEditable(false);
		add(startTime);
		
		endTime = new CTextField("End Time:", "dark", false);
		endTime.setBounds(10, 130, 190, 30);
		endTime.setBorder(null);
		endTime.setEditable(false);
		add(endTime);
		
		elapsedTime = new CTextField("Elapsed Time:", "dark", false);
		elapsedTime.setBounds(10, 170, 190, 30);
		elapsedTime.setBorder(null);
		elapsedTime.setEditable(false);
		add(elapsedTime);
		
		remainingTime = new CTextField("Remaining Time:", "light", false);
		remainingTime.setBounds(10, 210, 190, 30);
		remainingTime.setBorder(null);
		remainingTime.setEditable(false);
		add(remainingTime);
	}
	
	private void addCheckBoxes() {
		compactMode = new CCheckBox("Compact Mode");
		compactMode.setBounds(410, 160, 190, 30);
		compactMode.setSelected(true);
		compactMode.setForeground(Color.WHITE);
		checkSelected(compactMode);
		add(compactMode);
		
		alwaysOnTop = new CCheckBox("Pin to Top");
		alwaysOnTop.setBounds(210, 160, 190, 30);
		alwaysOnTop.setSelected(true);
		alwaysOnTop.setForeground(Color.WHITE);
		checkSelected(alwaysOnTop);
		add(alwaysOnTop);
		
		hourlyScreenshot = new CComboBox("Screenshots: 15 Minutes", Settings.SCREENSHOTS_TIME_INTERVALS);
		hourlyScreenshot.setBounds(210, 130, 190, 30);
		hourlyScreenshot.addActionListener(e -> {
			if(hourlyScreenshot.getSelectedItem().toString().equals("Screenshots: Off"))
				ssTimeStamp.setEnabled(false);
			else
				ssTimeStamp.setEnabled(true);
		});
		add(hourlyScreenshot);
		
		ssTimeStamp = new CCheckBox("Time Stamps");
		ssTimeStamp.setBounds(410, 130, 190, 30);
		ssTimeStamp.setForeground(Color.DARK_GRAY);
		checkSelected(ssTimeStamp);
		add(ssTimeStamp);
		
		finishAlarm = new CCheckBox("Finished Alarm");
		finishAlarm.setToolTipText("<html>If toggled, will sound an alarm when the timer has finished<br><b>Make sure to have your volume turned up</b></html>");
		finishAlarm.setBounds(210, 190, 190, 30);
		finishAlarm.setForeground(Color.WHITE);
		finishAlarm.setSelected(true);
		checkSelected(finishAlarm);
		add(finishAlarm);
	}
	
	private void checkSelected(CCheckBox box) {
		box.addActionListener(e -> {
			if(box.isSelected())
				box.setForeground(Color.WHITE);
			else
				box.setForeground(Color.DARK_GRAY);
		});
	}
	
	private void addButtons() {
		start = new CButton("Start");
		start.setBounds(10, 260, 190, 30);
		start.addActionListener(new ButtonListenerStart());
		add(start);
		loadFile = new CButton("Save/Load Files");
		loadFile.setBounds(410, 260, 190, 30);
		loadFile.addActionListener(new ButtonListenerSettings());
		add(loadFile);
		
		IconLabel watermark = new IconLabel("Made by: Dakota", 10);
		watermark.setBounds(Settings.FRAME_WIDTH - 100, Settings.FRAME_HEIGHT - 60, 150, 30);
		add(watermark);
		infoForm = new IconLabel("\uf05a", "Information", 15, Color.WHITE);
		infoForm.setBounds(Settings.FRAME_WIDTH - 22, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(infoForm);
		developerMessage = new IconLabel("\uf0e0", "Developer Message", 15, Color.WHITE);
		developerMessage.setBounds(Settings.FRAME_WIDTH - 44, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(developerMessage);
		screenshots = new IconLabel("\uf187", "Screenshots", 15, Color.WHITE);
		screenshots.setBounds(Settings.FRAME_WIDTH - 66, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(screenshots);
		themeChooser = new IconLabel("\uf1fc", "Theme Chooser", 15, Color.WHITE);
		themeChooser.setBounds(Settings.FRAME_WIDTH - 88, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(themeChooser);
		emailMe = new IconLabel("\uf1d8", "Email Me", 15, Color.WHITE);
		emailMe.setBounds(Settings.FRAME_WIDTH - 110, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(emailMe);
		iconFieldText = new IconLabel("", 15);
		add(iconFieldText);
	}

}

class CustomSliderUI extends BasicSliderUI {

	private Color majorTickColor = Settings.PRIMARY_COLOR.brighter();
	private Color minorTickColor = Settings.PRIMARY_COLOR;
    private BasicStroke stroke = new BasicStroke(1f, BasicStroke.CAP_ROUND, 
            BasicStroke.JOIN_ROUND, 0f, new float[]{1f, 2f}, 0f);

    public CustomSliderUI(JSlider b) {
        super(b);
    }

    @Override
    public void paint(Graphics g, JComponent c) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        super.paint(g, c);
    }

    @Override
    protected Dimension getThumbSize() {
        //return new Dimension(12, 16);
    	return new Dimension(14, 18);
    }

    @Override
    public void paintTrack(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke old = g2d.getStroke();
        g2d.setStroke(stroke);
        g2d.setPaint(Color.WHITE.darker()); //TODO
        if (slider.getOrientation() == SwingConstants.HORIZONTAL) {
            g2d.drawLine(trackRect.x, trackRect.y + trackRect.height / 2, 
                    trackRect.x + trackRect.width, trackRect.y + trackRect.height / 2);
        } else {
            g2d.drawLine(trackRect.x + trackRect.width / 2, trackRect.y, 
                    trackRect.x + trackRect.width / 2, trackRect.y + trackRect.height);
        }
        g2d.setStroke(old);
    }
    
    @Override
    public void paintMajorTickForHorizSlider(Graphics g, Rectangle tickBounds, int x) {
    	int coordinateX = x;
    	if(slider.getOrientation()==JSlider.HORIZONTAL) {   
    		g.setColor(majorTickColor);    
    		g.drawLine(coordinateX, 0, coordinateX, tickBounds.height);  //Draw Major TICK
    	}  
    }
    
    @Override
    public void paintMinorTickForHorizSlider(Graphics g, Rectangle tickBounds, int x) {  
    	int coordinateX = x;  
    	if(slider.getOrientation()==JSlider.HORIZONTAL) {  
    		g.setColor(minorTickColor);  
    		g.drawLine(coordinateX, 0, coordinateX, tickBounds.height / 2);  //Draw Minor TICK
    	}  
    }

    @Override
    public void paintThumb(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        int x1 = thumbRect.x + 2;
        int x2 = thumbRect.x + thumbRect.width - 2;
        int width = thumbRect.width - 4;
        int topY = thumbRect.y + thumbRect.height / 2 - thumbRect.width / 3;
        GeneralPath shape = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
        shape.moveTo(x1, topY);
        shape.lineTo(x2, topY);
        shape.lineTo((x1 + x2) / 2, topY + width);
        shape.closePath();
        //g2d.setPaint(new Color(81, 83, 186)); //Inner Color
        g2d.setPaint(Color.LIGHT_GRAY);
        g2d.fill(shape);
        Stroke old = g2d.getStroke();
        g2d.setStroke(new BasicStroke(2f));
        //g2d.setPaint(new Color(131, 127, 211));	//Outer Color
        g2d.setPaint(Color.WHITE);
        g2d.draw(shape);
        g2d.setStroke(old);
    }
    
}