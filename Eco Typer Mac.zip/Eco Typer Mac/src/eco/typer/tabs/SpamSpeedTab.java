package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.listeners.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerListModel;

import eco.typer.settings.Settings;

@SuppressWarnings("serial")
public class SpamSpeedTab extends JPanel {
	
	public static JSpinner secondsSpinner;
	private CButton setDelay;
	
	public SpamSpeedTab() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		JLabel spamDelayLabel = new JLabel("Spam Delay Time");
		spamDelayLabel.setBounds(10, 10, 200, 30);
		spamDelayLabel.setFont(new Font("Cosmic Sans MS", Font.BOLD, 20));
		spamDelayLabel.setForeground(Color.WHITE);
		add(spamDelayLabel);
		
		SpinnerCircularListModel secondsModel = new SpinnerCircularListModel(Settings.TIME_SECONDS);
		secondsSpinner = new JSpinner(secondsModel);
		secondsSpinner.setBounds(10, 40, 200, 30);
		setColors(secondsSpinner);
		add(secondsSpinner);
		
		setDelay = new CButton("Set Delay");
		setDelay.setBounds(10, 70, 100, 30);
		setDelay.addActionListener(new ButtonListenerSettings());
		add(setDelay);
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(10, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
	}
	
	private void setColors(JSpinner spinner) {
		JComponent editor = spinner.getEditor();
		for(int i = 0; i < editor.getComponentCount(); i++) {
			Component c = editor.getComponent(i);
			if(c instanceof JTextField) {
				((JTextField) c).setEditable(false);
				c.setForeground(Color.WHITE);
				c.setBackground(Settings.BACKGROUND_COLOR);
				((JTextField) c).setBorder(null);
				c.setFont(new Font("Cosmic Sans MS", Font.BOLD, 13));
				((JTextField) c).setHorizontalAlignment(JTextField.CENTER);
			}
		}
	}

}

@SuppressWarnings("serial")
class SpinnerCircularListModel extends SpinnerListModel {
	public SpinnerCircularListModel(Object[] items) {
		super(items);
	}
	
	public Object getNextValue() {
		List<?> list = getList();
		int index = list.indexOf(getValue());
		
		index = (index >= list.size() - 1) ? 0 : index + 1;
		return list.get(index);
	}
	
	public Object getPreviousValue() {
		List<?> list = getList();
		int index = list.indexOf(getValue());
		
		index = (index <= 0) ? list.size() - 1 : index - 1;
		return list.get(index);
	}
}