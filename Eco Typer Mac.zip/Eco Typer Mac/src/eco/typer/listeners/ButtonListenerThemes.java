package eco.typer.listeners;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.typer.settings.Settings;
import eco.typer.tabs.SettingsTab;
import eco.typer.tabs.SpamTextTab;
import eco.typer.utils.Utils;

public class ButtonListenerThemes implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		case "Blue":
			updateColor(Color.BLUE.darker());
			break;
		case "Cyan":
			updateColor(Color.CYAN.darker());
			break;
		case "Green":
			updateColor(Color.GREEN.darker());
			break;
		case "Magenta":
			updateColor(Color.MAGENTA.darker());
			break;
		case "Orange":
			updateColor(Color.ORANGE.darker());
			break;
		case "Pink":
			updateColor(Color.PINK.darker());
			break;
		case "Red":
			updateColor(Color.RED.darker());
			break;
		case "Yellow":
			updateColor(Color.YELLOW.darker());
			break;
		case "Custom 1":
			updateColor(new Color(11, 117, 115).darker());
			break;
		case "Custom 2":
			updateColor(new Color(30, 144, 255).darker());
			break;
		case "Custom 3":
			updateColor(new Color(105, 139, 34).darker());
			break;
		case "Custom 4":
			updateColor(new Color(72, 61, 139).darker());
			break;
		case "Custom 5":
			updateColor(new Color(238, 64, 0).darker());
			break;
		default:
			System.err.println("Unrecognized Command for theme change: " + e.getActionCommand());
			break;
		}
		
	}
	
	private void updateColor(Color c) {
		Settings.PRIMARY_COLOR = c;
		Utils.serializeFrameData();
		closeFunction();
	}
	
	private void closeFunction() {
		Utils.closeLastTab();
		SpamTextTab.clearAllSpam.setVisible(false);
		Utils.enableButtons();
		if(SettingsTab.spamSpeed.getSelectedItem().toString().equals("Custom Delay Time")) {
			SettingsTab.spamSpeed.setEditable(true);
			SettingsTab.spamSpeed.setSelectedItem("Spam Intervals");
			SettingsTab.spamSpeed.setEditable(false);
		}
		if(SettingsTab.spamSpeed.getSelectedItem().toString().equals("Custom Time")) {
			SettingsTab.spamSpeed.setEditable(true);
			SettingsTab.spamSpeed.setSelectedItem("Execution Time");
			SettingsTab.spamSpeed.setEditable(false);
		}
		
	}

}
