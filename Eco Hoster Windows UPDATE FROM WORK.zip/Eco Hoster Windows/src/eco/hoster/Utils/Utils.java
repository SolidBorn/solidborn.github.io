package eco.hoster.Utils;

import java.awt.Component;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.FontFormatException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import eco.hoster.Custom_Frame.CustomFrame;
import eco.hoster.Custom_Objects.CButton;
import eco.hoster.Custom_Objects.CMenu;
import eco.hoster.Custom_Objects.CMenuItem;
import eco.hoster.Settings.Settings;

public class Utils {
	
	private static ArrayList<Object> objects = new ArrayList<Object>();
	
	public static void setFont(Component c, String fontName, float size) {
		try {
			Font font = Font.createFont(0, Utils.class.getResource("/data/fonts/" + fontName).openStream());
			GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
			genv.registerFont(font);
			font = font.deriveFont(size);
			c.setFont(font);
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void openWebpage(String url) {
	    Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
	    if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
	        try {
	            desktop.browse(new URL(url).toURI());
	        } catch (Exception e) {
	           // e.printStackTrace();
	        }
	    }
	}
	
	public static ImageIcon getImage(String name) {
		return new ImageIcon(Utils.class.getResource("/data/img/" + name));
	}
	
	public static void add(Container c, Object o) {
		c.add((Component) o);
		objects.add(o);
	}
	
	public static void updateTheme() {
		for(Object o : objects) {
			if(o instanceof CMenu) {
				CMenu temp = (CMenu) o;
				temp.setForeground(Settings.PRIMARY_COLOR);
			}
			if(o instanceof CMenuItem) {
				CMenuItem temp = (CMenuItem) o;
				temp.setForeground(Settings.PRIMARY_COLOR);
			}
			if(o instanceof CButton) {
				CButton temp = (CButton) o;
				temp.setBackground(Settings.PRIMARY_COLOR.darker());
			}
		}
	}
	
	public static void clearWorkspace() {
		CustomFrame.workspace.removeAll();
		CustomFrame.workspace.revalidate();
		CustomFrame.workspace.repaint();
	}

}
