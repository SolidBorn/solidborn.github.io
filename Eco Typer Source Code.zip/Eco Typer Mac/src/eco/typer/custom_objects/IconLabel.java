package eco.typer.custom_objects;
import eco.typer.tabs.*;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.LineMetrics;
import java.io.IOException;

import javax.swing.JLabel;

import eco.typer.custom_frame.*;
import eco.typer.settings.*;
import eco.typer.tabs.PersonalSpam;
import eco.typer.utils.Utils;

@SuppressWarnings("serial")
public class IconLabel extends JLabel implements MouseListener {
	/**
	 * This class is used to display those custom icons, such as the theme picker icon
	 * I will not comment this class, as it's really a final class. It does not need to be touched.
	 * This class also has the most constructors by far, for many uses throughout the program
	 */
	private int tracking;
	private String action, statusText;
	
	public IconLabel(String text, int fontSize) {
		super(text);
		this.tracking = 1;
		setForeground(Settings.PRIMARY_COLOR);
		this.setRightShadow(1, 1, Settings.ICON_SHADOW);
		Utils.setFont(this, "OpenSans-Light.ttf", fontSize);
	}
	
	public IconLabel(String text, int fontSize, String action) {
		super(text);
		this.tracking = 1;
		this.action = action;
		setForeground(Settings.PRIMARY_COLOR);
		addMouseListener(this);
		this.setRightShadow(1, 1, Settings.ICON_SHADOW);
		Utils.setFont(this, "OpenSans-Light.ttf", fontSize);
	}
	
	public IconLabel(String text, String action, int fontSize) {
		super(text);
		this.statusText = action;
		this.action = action;
		setForeground(Settings.PRIMARY_COLOR);
		addMouseListener(this);
		this.setRightShadow(1, 1, Settings.ICON_SHADOW);
		Utils.setFont(this, "FontAwesome.ttf", fontSize);
	}
	
	public IconLabel(String text, String action, int fontSize, Color color) {
		super(text);
		this.statusText = action;
		this.tracking = 1;
		this.action = action;
		setForeground(color);
		addMouseListener(this);
		this.setRightShadow(1, 1, Settings.ICON_SHADOW);
		Utils.setFont(this, "FontAwesome.ttf", fontSize);
	}
	
	public IconLabel(String text, String action, String font, int fontSize) {
		super(text);
		this.statusText = action;
		this.tracking = 1;
		this.action = action;
		setForeground(Settings.PRIMARY_COLOR);
		addMouseListener(this);
		this.setRightShadow(1, 1, Settings.ICON_SHADOW);
		Utils.setFont(this, font, fontSize);
	}
	
	private int left_x, left_y, right_x, right_y;
	private Color left_color, right_color;
	public void setLeftShadow(int x, int y, Color color) {
		left_x = x;
		left_y = y;
		left_color = color;
	}
	
	public void setRightShadow(int x, int y, Color color) {
		right_x = x;
		right_y = y;
		right_color = color;
	}
	
	public Dimension getPreferredSize() {
		String text = getText();
		FontMetrics fm = this.getFontMetrics(getFont());
		
		int w = fm.stringWidth(text);
		w += (text.length() - 1) * tracking;
		w += left_x + right_x;
		
		int h = fm.getHeight();
		h += left_y + right_y;
		
		return new Dimension(w, h);
	}
	
	public void paintComponent(Graphics g) {
		((Graphics2D)g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		
		char[] chars = getText().toCharArray();
		
		FontMetrics fm = this.getFontMetrics(getFont());
		int h = fm.getAscent();
		@SuppressWarnings("unused")
		LineMetrics lm = fm.getLineMetrics(getText(), g);
		g.setFont(getFont());
		
		int x = 0;
		
		for(int i = 0; i < chars.length; i++) {
			char ch = chars[i];
			int w = fm.charWidth(ch) + tracking;
			
			g.setColor(left_color);
			g.drawString("" + ch, x - left_x, h - left_y);
			
			g.setColor(right_color);
			g.drawString("" + ch, x + right_x, h + right_y);
			
			g.setColor(getForeground());
			g.drawString("" + ch, x, h);
			
			x += w;
		}
	}

	@Override
	public void setForeground(Color c) {
		super.setForeground(c);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {
		switch(this.action) {
		
		case "Information":	//Icon for information in SettingsTab
			Utils.openWebpage("http://ecotype.webs.com/documentation");
			break;
			
		case "Developer Message":	//Icon for developer message in SettingsTab
			Utils.openWebpage("http://ecotype.webs.com/my-message");
			break;
			
		case "Screenshots":	//Icon for screenshots in SettingsTab
			try {
				Desktop.getDesktop().open(Settings.SCREENSHOT_DIR);
			} catch(IOException e1) {
				e1.printStackTrace();
			}
			break;
			
		case "Theme Chooser":	//Icon for theme picker in SettingsTab
			if(Utils.getTabCount() > 2)
				Toolkit.getDefaultToolkit().beep();
			else {
				CustomFrame.tabbedPane.add("Theme Chooser", new ThemeChooser());
				Utils.setLastTab();
				Utils.disableButtons();
			}
			break;
			
		case "Email Me":
			Utils.openWebpage("mailto:typer.eco@gmail.com");
			break;
			
		case "Edit Spams":	//Icon for editing altar spam in the Altar Spam portion of adding spam
			Utils.closeLastTab();
			CustomFrame.tabbedPane.add("Edit Altar Presets", new EditAltarSpam());
			Utils.setLastTab();
			break;
			
		case "PlusPersonalLine":	//Icon for adding a line in the Personal Spam portion of adding spam
			addLastLine();
			break;
			
		case "MinusPersonalLine":	//Icon for subtracting a line in the Personal Spam portion of adding spam
			removeLastLine();
			break;
			
		default:
			System.err.println("Unknown IconLabel Command: " + this.action);	
			break;
		
		}
	}
	
	private void addLastLine() {
		if(!PersonalSpam.spamLine1.isVisible()) {
			PersonalSpam.spamLine1.setVisible(true);
			PersonalSpam.colorText1.setVisible(true);
			PersonalSpam.effectText1.setVisible(true);
		}
		else if(!PersonalSpam.spamLine2.isVisible()) {
			PersonalSpam.spamLine2.setVisible(true);
			PersonalSpam.colorText2.setVisible(true);
			PersonalSpam.effectText2.setVisible(true);
		}
		else if(!PersonalSpam.spamLine3.isVisible()) {
			PersonalSpam.spamLine3.setVisible(true);
			PersonalSpam.colorText3.setVisible(true);
			PersonalSpam.effectText3.setVisible(true);
		}
		else if(!PersonalSpam.spamLine4.isVisible()) {
			PersonalSpam.spamLine4.setVisible(true);
			PersonalSpam.colorText4.setVisible(true);
			PersonalSpam.effectText4.setVisible(true);
		}
		else if(!PersonalSpam.spamLine5.isVisible()) {
			PersonalSpam.spamLine5.setVisible(true);
			PersonalSpam.colorText5.setVisible(true);
			PersonalSpam.effectText5.setVisible(true);
		}
		else if(!PersonalSpam.spamLine6.isVisible()) {
			PersonalSpam.spamLine6.setVisible(true);
			PersonalSpam.colorText6.setVisible(true);
			PersonalSpam.effectText6.setVisible(true);
		}
		else if(!PersonalSpam.spamLine7.isVisible()) {
			PersonalSpam.spamLine7.setVisible(true);
			PersonalSpam.colorText7.setVisible(true);
			PersonalSpam.effectText7.setVisible(true);
		}
		else
			Toolkit.getDefaultToolkit().beep();
	}
	
	private void removeLastLine() {
		if(PersonalSpam.spamLine7.isVisible()) {
			PersonalSpam.spamLine7.setVisible(false);
			PersonalSpam.colorText7.setVisible(false);
			PersonalSpam.effectText7.setVisible(false);
		}
		else if(PersonalSpam.spamLine6.isVisible()) {
			PersonalSpam.spamLine6.setVisible(false);
			PersonalSpam.colorText6.setVisible(false);
			PersonalSpam.effectText6.setVisible(false);
		}
		else if(PersonalSpam.spamLine5.isVisible()) {
			PersonalSpam.spamLine5.setVisible(false);
			PersonalSpam.colorText5.setVisible(false);
			PersonalSpam.effectText5.setVisible(false);
		}
		else if(PersonalSpam.spamLine4.isVisible()) {
			PersonalSpam.spamLine4.setVisible(false);
			PersonalSpam.colorText4.setVisible(false);
			PersonalSpam.effectText4.setVisible(false);
		}
		else if(PersonalSpam.spamLine3.isVisible()) {
			PersonalSpam.spamLine3.setVisible(false);
			PersonalSpam.colorText3.setVisible(false);
			PersonalSpam.effectText3.setVisible(false);
		}
		else if(PersonalSpam.spamLine2.isVisible()) {
			PersonalSpam.spamLine2.setVisible(false);
			PersonalSpam.colorText2.setVisible(false);
			PersonalSpam.effectText2.setVisible(false);
		}
		else if(PersonalSpam.spamLine1.isVisible()) {
			PersonalSpam.spamLine1.setVisible(false);
			PersonalSpam.colorText1.setVisible(false);
			PersonalSpam.effectText1.setVisible(false);
		}
		else
			Toolkit.getDefaultToolkit().beep();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		setForeground(this.getForeground().darker());
		if(statusText.equals("Developer Message"))
			SettingsTab.iconFieldText.setBounds(Settings.FRAME_WIDTH - 155, Settings.FRAME_HEIGHT - 140, 150, 30);
		if(statusText.equals("Information"))
			SettingsTab.iconFieldText.setBounds(Settings.FRAME_WIDTH - 98, Settings.FRAME_HEIGHT - 140, 90, 30);
		if(statusText.equals("Screenshots"))
			SettingsTab.iconFieldText.setBounds(Settings.FRAME_WIDTH - 101, Settings.FRAME_HEIGHT - 140, 100, 30);
		if(statusText.equals("Theme Chooser"))
			SettingsTab.iconFieldText.setBounds(Settings.FRAME_WIDTH - 128, Settings.FRAME_HEIGHT - 140, 120, 30);
		if(statusText.equals("Email Me"))
			SettingsTab.iconFieldText.setBounds(Settings.FRAME_WIDTH - 75, Settings.FRAME_HEIGHT - 140, 80, 30);
		
		SettingsTab.iconFieldText.setText(this.statusText);
		SettingsTab.iconFieldText.setForeground(Settings.PRIMARY_COLOR);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		setForeground(this.getForeground().brighter());
		SettingsTab.iconFieldText.setText("");
	}

}
