package eco.typer.panels;

import eco.typer.custom_frame.CPanel;

@SuppressWarnings("serial")
public class PageEditor extends CPanel {
	
	public PageEditor(String pageName) {
		super("Page Editor - " + pageName);
		
		
	}

}
