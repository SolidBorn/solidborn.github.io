package eco.typer.Settings;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JWindow;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import eco.typer.custom_frame.CustomFrame;
import eco.typer.tools.FrameProperities;
import eco.typer.tools.Utils;
import eco.typer.tools.Website;

public class Settings {
	
	public static final String VERSION = "09-30-2018"; //TODO
	//TODO Make multiple websites to read from to avoid overloading from 1 site
	public static final boolean speedUpBoot = true;		//For developing, make false for release
	public static final boolean printWebsiteData = true;	//Toggle for printing data read from website
	
	public static CustomFrame frame;
	public static void main(String[] args) {
		
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			Utils.writeErrorReport(e, 100);
		}
		
		Constants.splashWindow = loadingCacheFrame();
		checkSerializedData();
		initializeShiftCases();
		
		UIManager.put("ComboBox.selectionForeground", Constants.PRIMARY_COLOR.brighter());
	    UIManager.put("ComboBox.selectionBackground", Constants.BACKGROUND_COLOR);
		
		frame = new CustomFrame();
		
	}
	
	private static void initializeShiftCases() {
		char[] shiftC = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '{', '}', '|', ':', '<', '>', '?', '+', '"'};
		Constants.shiftCases = new ArrayList<Character>();
		for(char c : shiftC)
			Constants.shiftCases.add(c);
		Constants.mapStrokes = new HashMap<>();
		Constants.mapStrokes.put('a', KeyEvent.VK_A);
		Constants.mapStrokes.put('b',  KeyEvent.VK_B);
		Constants.mapStrokes.put('c',  KeyEvent.VK_C);
		Constants.mapStrokes.put('d',  KeyEvent.VK_D);
		Constants.mapStrokes.put('e',  KeyEvent.VK_E);
		Constants.mapStrokes.put('f',  KeyEvent.VK_F);
		Constants.mapStrokes.put('g',  KeyEvent.VK_G);
		Constants.mapStrokes.put('h',  KeyEvent.VK_H);
		Constants.mapStrokes.put('i',  KeyEvent.VK_I);
		Constants.mapStrokes.put('j',  KeyEvent.VK_J);
		Constants.mapStrokes.put('k',  KeyEvent.VK_K);
		Constants.mapStrokes.put('l',  KeyEvent.VK_L);
		Constants.mapStrokes.put('m',  KeyEvent.VK_M);
		Constants.mapStrokes.put('n',  KeyEvent.VK_N);
		Constants.mapStrokes.put('o',  KeyEvent.VK_O);
		Constants.mapStrokes.put('p',  KeyEvent.VK_P);
		Constants.mapStrokes.put('q',  KeyEvent.VK_Q);
		Constants.mapStrokes.put('r',  KeyEvent.VK_R);
		Constants.mapStrokes.put('s',  KeyEvent.VK_S);
		Constants.mapStrokes.put('t',  KeyEvent.VK_T);
		Constants.mapStrokes.put('u',  KeyEvent.VK_U);
		Constants.mapStrokes.put('v',  KeyEvent.VK_V);
		Constants.mapStrokes.put('w',  KeyEvent.VK_W);
		Constants.mapStrokes.put('x',  KeyEvent.VK_X);
		Constants.mapStrokes.put('y',  KeyEvent.VK_Y);
		Constants.mapStrokes.put('z',  KeyEvent.VK_Z);
		Constants.mapStrokes.put('`', KeyEvent.VK_BACK_QUOTE);
		Constants.mapStrokes.put('0', KeyEvent.VK_0);
		Constants.mapStrokes.put('1', KeyEvent.VK_1);
		Constants.mapStrokes.put('2', KeyEvent.VK_2);
		Constants.mapStrokes.put('3', KeyEvent.VK_3);
		Constants.mapStrokes.put('4', KeyEvent.VK_4);
		Constants.mapStrokes.put('5', KeyEvent.VK_5);
		Constants.mapStrokes.put('6', KeyEvent.VK_6);
		Constants.mapStrokes.put('7', KeyEvent.VK_7);
		Constants.mapStrokes.put('8', KeyEvent.VK_8);
		Constants.mapStrokes.put('9', KeyEvent.VK_9);
		Constants.mapStrokes.put('-', KeyEvent.VK_MINUS);
		Constants.mapStrokes.put('=', KeyEvent.VK_EQUALS);
		Constants.mapStrokes.put('\t', KeyEvent.VK_TAB);
		Constants.mapStrokes.put('\n', KeyEvent.VK_ENTER);
		Constants.mapStrokes.put('[', KeyEvent.VK_OPEN_BRACKET);
		Constants.mapStrokes.put(']', KeyEvent.VK_CLOSE_BRACKET);
		Constants.mapStrokes.put('\\', KeyEvent.VK_BACK_SLASH);
		Constants.mapStrokes.put(';', KeyEvent.VK_SEMICOLON);
		Constants.mapStrokes.put('\'', KeyEvent.VK_QUOTE);
		Constants.mapStrokes.put('\"', KeyEvent.VK_QUOTEDBL);
		Constants.mapStrokes.put(',', KeyEvent.VK_COMMA);
		Constants.mapStrokes.put('.', KeyEvent.VK_PERIOD);
		Constants.mapStrokes.put('/', KeyEvent.VK_SLASH);
		Constants.mapStrokes.put(' ', KeyEvent.VK_SPACE);
		//All the items that require shift are below
		Constants.mapStrokes.put('~', KeyEvent.VK_BACK_QUOTE);
		Constants.mapStrokes.put('!', KeyEvent.VK_1);
		Constants.mapStrokes.put('@', KeyEvent.VK_2);
		Constants.mapStrokes.put('#', KeyEvent.VK_3);
		Constants.mapStrokes.put('$', KeyEvent.VK_4);
		Constants.mapStrokes.put('%', KeyEvent.VK_5);
		Constants.mapStrokes.put('^', KeyEvent.VK_6);
		Constants.mapStrokes.put('&', KeyEvent.VK_7);
		Constants.mapStrokes.put('*', KeyEvent.VK_8);
		Constants.mapStrokes.put('(', KeyEvent.VK_9);
		Constants.mapStrokes.put(')', KeyEvent.VK_0);
		Constants.mapStrokes.put('_', KeyEvent.VK_MINUS);
		Constants.mapStrokes.put('{', KeyEvent.VK_OPEN_BRACKET);
		Constants.mapStrokes.put('}', KeyEvent.VK_CLOSE_BRACKET);
		Constants.mapStrokes.put('|', KeyEvent.VK_BACK_SLASH);
		Constants.mapStrokes.put(':', KeyEvent.VK_SEMICOLON);
		Constants.mapStrokes.put('<', KeyEvent.VK_COMMA);
		Constants.mapStrokes.put('>', KeyEvent.VK_PERIOD);
		Constants.mapStrokes.put('?', KeyEvent.VK_SLASH);
		Constants.mapStrokes.put('+', KeyEvent.VK_EQUALS);
		Constants.mapStrokes.put('"', KeyEvent.VK_QUOTE);
		//-----------------
	}
	private static void checkDir() {
		if(!Constants.SCREENSHOT_DIRECTORY.exists())
			Constants.SCREENSHOT_DIRECTORY.mkdirs();
		if(!Constants.HOST_FILES_DIRECTORY.exists()) {
			showAlerts();
			Constants.HOST_FILES_DIRECTORY.mkdirs();
		}
	}
	private static void showAlerts() {
		Constants.splashWindow.setAlwaysOnTop(false);
		String welcomeMessage = "Welcome To Eco Typer:" + "\n"
				+ "We're very happy to see you choose Eco Typer for your automated typer." + "\n"
				+ "Unfortunately some great things need to be restricted. Eco Typer is restricted due to Java only supporting an english keyboard layout." + "\n"
				+ "Below are directions for how to set your keyboard for your native choice of operating system." + "\n\n";
		if(Constants.OPERATING_SYSTEM.equals("Windows")) {
			welcomeMessage = welcomeMessage
					+ "Step 1. Open Settings" + "\n"
					+ "Step 2. Go to Time and Langauge" + "\n"
					+ "Step 3. Scroll down to Region and Language" + "\n"
					+ "Step 4. Make sure Languages is to set English (United States)";
		} else if(Constants.OPERATING_SYSTEM.equals("Mac")) {
			welcomeMessage = welcomeMessage
					+ "Step 1. TODO" + "\n"
					+ "Step 2. TODO" + "\n"
					+ "Step 3. TODO" + "\n"
					+ "Step 4. TODO";
		} else {
			welcomeMessage = welcomeMessage
					+ "We've detected you're running Linux. Unfortunaly we couldn't cover every Linux distro so we suggest googling directions " + "\n"
					+ "for your choice of distro.";
		}
    	JOptionPane.showMessageDialog(Constants.splashWindow, welcomeMessage, "Welcome", JOptionPane.INFORMATION_MESSAGE);
    	
		if(Constants.OPERATING_SYSTEM.equals("Mac")) {
	    	String message = "Important:" + "\n"
					+ "For all people running Mac OS, there's an aditional step you need to follow." + "\n\n"
					+ "Step 1. Open System Preferences" + "\n"
					+ "Step 2. Go to Security and Privacy" + "\n"
					+ "Step 3. Scroll down to Accessibility" + "\n"
					+ "Step 4. Make sure \"Jar Launcher\" is ticked" + "\n"
					+ "*note, you might have to click the lock box in the bottom left and enter your password" + "\n\n"
					+ "Why do you have to do this?" + "\n"
					+ "Out of the box Mac OS doesn't allow 3rd party applications to have Accessibility settings turned on, " + "\n"
					+ "but due to the nature of this program, Eco Typer requires it to be enabled.";
	    	JOptionPane.showMessageDialog(Constants.splashWindow, message, "Mac OS", JOptionPane.INFORMATION_MESSAGE);
		}
		Constants.splashWindow.setAlwaysOnTop(true);
	}
	private static void checkSerializedData() {
		Website webReader = new Website();
		Constants.DOWNLOAD_LINK = webReader.getDownloadLink();
		Constants.UPDATE_DESCRIPITION = webReader.getUpdateDesc();
		Constants.isUpdate = webReader.checkForUpdate();
		Constants.OPERATING_SYSTEM = webReader.getOperatingSystem();
		if(Constants.OPERATING_SYSTEM.equals("Windows"))	//This works because webReader.getOperatingSystem() returns "Windows"
			Constants.FINISHING_COMMAND_OPTIONS = new String[] {"Do Nothing", "Close RuneScape Client", "Close Eco Typer", "Close RuneScape Client and Eco",  "Logoff Computer", "Restart Computer", "Shutdown Computer"};
		else
			Constants.FINISHING_COMMAND_OPTIONS = new String[] {"Do Nothing", "Close This Program"};
		Constants.ALERT = webReader.getAlert();
		Constants.isAlert = webReader.checkAlertStatus();
		
		if(Settings.printWebsiteData) {
			System.out.println("Download Link => " + Constants.DOWNLOAD_LINK);
			System.out.println("Update Description. => " + Constants.UPDATE_DESCRIPITION);
			System.out.println("Is there an update? => " + Constants.isUpdate);
			System.out.println("Operating System => " + Constants.OPERATING_SYSTEM);
			System.out.println("Alert Message => " + Constants.ALERT);
			System.out.println("Is there a new Alert? => " + Constants.isAlert);
			System.out.println();
		}
		
		checkDir();
		FrameProperities fp = Utils.loadCache();
		Constants.PRIMARY_COLOR = fp.color;
		Constants.SPAM_LINE_1 = fp.spam1;
		Constants.SPAM_LINE_2 = fp.spam2;
		Constants.SPAM_LINE_3 = fp.spam3;
		Constants.SPAM_LINE_4 = fp.spam4;
		Constants.SPAM_LINE_5 = fp.spam5;
		Constants.SPAM_LINE_6 = fp.spam6;
		Constants.totalProfit = fp.totalProfit;
		Constants.profitCounter = fp.profitCounter;
	}
	
	public static JLabel splashWindowText;
	private static JWindow loadingCacheFrame() {
		JWindow window = new JWindow();
		window.setLayout(new BorderLayout());
		window.setSize(610, 350);
		JLabel bg = new JLabel(Utils.getImage("Eco_Typer_Splash.png"));
		bg.setLayout(null);
		splashWindowText = new JLabel();
		splashWindowText.setForeground(Color.WHITE);
		splashWindowText.setBounds(0, window.getHeight() - 15, window.getWidth(), 15);
		bg.add(splashWindowText);
		window.add(bg);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		window.setAlwaysOnTop(true);
		return window;
	}
	
}
