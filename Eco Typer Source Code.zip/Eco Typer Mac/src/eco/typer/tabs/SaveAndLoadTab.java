package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.listeners.*;
import eco.typer.utils.*;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import eco.typer.settings.Settings;

@SuppressWarnings("serial")
public class SaveAndLoadTab extends JPanel {
	
	public static CTextField fileNameField;
	private CButton saveFile, loadFile, deleteFile;
	public static JList<String> fileList;
	
	public SaveAndLoadTab() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		JLabel saveLabel = new JLabel("Save File");
		saveLabel.setBounds(10, 10, 100, 30);
		saveLabel.setFont(new Font("Cosmic Sans MS", Font.BOLD, 20));
		saveLabel.setForeground(Color.WHITE);
		add(saveLabel);
		
		fileNameField = new CTextField("", "light", true);
		fileNameField.setBounds(10, 40, 200, 30);
		fileNameField.setBorder(null);
		add(fileNameField);
		
		saveFile = new CButton("Save File");
		saveFile.setBounds(10, 70, 100, 30);
		saveFile.addActionListener(new ButtonListenerSettings());
		add(saveFile);
		
		JLabel loadLabel = new JLabel("Load File");
		loadLabel.setBounds(300, 10, 100, 30);
		loadLabel.setFont(new Font("Cosmic Sans MS", Font.BOLD, 20));
		loadLabel.setForeground(Color.WHITE);
		add(loadLabel);
		
		fileList = new JList<String>(Utils.getSavedFiles());
		fileList.setBackground(Settings.BACKGROUND_COLOR.brighter());
		fileList.setForeground(Color.WHITE);
		JScrollPane listScroller = new JScrollPane(fileList);
		listScroller.setBounds(300, 40, 200, 200);
		add(listScroller);
		
		loadFile = new CButton("Load File");
		loadFile.setBounds(300, 240, 100, 30);
		loadFile.addActionListener(new ButtonListenerSettings());
		add(loadFile);
		
		deleteFile = new CButton("Delete File");
		deleteFile.setBounds(400, 240, 100, 30);
		deleteFile.addActionListener(new ButtonListenerSettings());
		add(deleteFile);
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(10, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
	}

}
