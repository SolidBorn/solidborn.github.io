package eco.typer.custom_objects;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import eco.typer.listeners.ButtonListener;
import eco.typer.settings.Settings;

@SuppressWarnings("serial")
public class RightClickMenu extends JPopupMenu {
	
	JMenu hostingSession;
	JMenuItem startSession, endSession;
	
	JMenu logMenu;
	JMenuItem donation, advertiser, juju;
	
	JMenu settingsMenu;
	JMenuItem pinFrameToTop, toggleAlarm;
	
	JMenu locationMenu;
	JMenuItem top_left, top_middle, top_right;
	
	public RightClickMenu() {
		initHostingSession();
		if(Settings.isHostActive) {
			initLogMenu();
			addSeparator();
			initSettings();
		}
		else {
			addSeparator();
			initLocationMenu();
			initSettings();
		}
	}

	private void initHostingSession() {
		hostingSession = new JMenu("Hosting Session");
		startSession = new JMenuItem("Start Session");
		startSession.setActionCommand("Start_Hosting_Session");
		startSession.addActionListener(new ButtonListener());
		endSession = new JMenuItem("End Session");
		endSession.setActionCommand("End_Hosting_Session");
		endSession.addActionListener(new ButtonListener());
		hostingSession.add(startSession);
		hostingSession.add(endSession);
		checkHostingSessionLogic();
		add(hostingSession);
	}

	private void checkHostingSessionLogic() {
		if(!Settings.isHostActive)
			this.endSession.setEnabled(false);
		else
			this.startSession.setEnabled(false);
	}
	
	private void initLogMenu() {
		logMenu = new JMenu("Log");
		donation = new JMenuItem("Recieved Donation");
		advertiser = new JMenuItem("Paid Advertiser");
		juju = new JMenuItem("Gave JuJu");
		logMenu.add(donation);
		logMenu.addSeparator();
		logMenu.add(advertiser);
		logMenu.add(juju);
		add(logMenu);
	}
	
	private void initLocationMenu() {
		locationMenu = new JMenu("Move Frame");
		top_left = new JMenuItem("Top Left");
		top_left.setActionCommand("Move_Top_Left");
		top_left.addActionListener(new ButtonListener());
		top_middle = new JMenuItem("Top Middle");
		top_middle.setActionCommand("Move_Top_Middle");
		top_middle.addActionListener(new ButtonListener());
		top_right = new JMenuItem("Top Right");
		top_right.setActionCommand("Move_Top_Right");
		top_right.addActionListener(new ButtonListener());
		locationMenu.add(top_left);
		locationMenu.add(top_middle);
		locationMenu.add(top_right);
		add(locationMenu);
	}
	
	private void initSettings() {
		settingsMenu = new JMenu("Settings");
		pinFrameToTop = new JMenuItem("Pin To Top");
		toggleAlarm = new JMenuItem("Toggle Burners Alarm");
		settingsMenu.add(pinFrameToTop);
		settingsMenu.add(toggleAlarm);
		add(settingsMenu);
	}

}
