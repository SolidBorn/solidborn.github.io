package eco.hoster.Custom_Objects;

import javax.swing.JPopupMenu;

import eco.hoster.Listeners.IsHostingListener;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class RightClickMenu_IsHosting extends JPopupMenu {
	
	public static CMenuItem gaveJuju, recievedDonation, paidAdvertiser, screenshot, toggleAlarm;
	
	public static CMenu timerDuration;
	public static CMenuItem oneMin30, oneMin35, oneMin40, oneMin45, oneMin50, oneMin55, twoMin;
	
	public static CMenu hostingSessionMenu;
	public static CMenuItem endSession;
	
	public RightClickMenu_IsHosting() {
		initGaveJuju();
		initRecievedDonation();
		initPaidAdvertiser();
		initScreenshot();
		
		addSeparator();
		
		initToggleAlarm();
		initTimerDuration();
		initHostingSession();
	}

	private void initGaveJuju() {
		gaveJuju = new CMenuItem("Gave JuJu");
		gaveJuju.setActionCommand("Gave_JuJu");
		gaveJuju.addActionListener(new IsHostingListener());
		Utils.add(this, gaveJuju);
	}
	
	private void initRecievedDonation() {
		recievedDonation = new CMenuItem("Recieved Donation");
		recievedDonation.setActionCommand("Recieved_Donation");
		recievedDonation.addActionListener(new IsHostingListener());
		Utils.add(this, recievedDonation);
	}
	
	private void initPaidAdvertiser() {
		paidAdvertiser = new CMenuItem("Paid Advertiser");
		paidAdvertiser.setActionCommand("Paid_Advertiser");
		paidAdvertiser.addActionListener(new IsHostingListener());
		Utils.add(this, paidAdvertiser);
	}
	
	private void initScreenshot() {
		screenshot = new CMenuItem("Screenshot");
		screenshot.setActionCommand("Screenshot");
		screenshot.addActionListener(new IsHostingListener());
		Utils.add(this, screenshot);
	}
	
	private void initToggleAlarm() {
		toggleAlarm = new CMenuItem("Toggle Alarm: Off");
		toggleAlarm.setActionCommand("Toggle Alarm: Off");
		toggleAlarm.addActionListener(new IsHostingListener());
		Utils.add(this, toggleAlarm);
	}
	
	private void initTimerDuration() {
		timerDuration = new CMenu("Time Length");
		
		oneMin30 = new CMenuItem("1:30");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin30);
		oneMin35 = new CMenuItem("1:35");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin35);
		oneMin40 = new CMenuItem("1:40");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin40);
		oneMin45 = new CMenuItem("1:45");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin45);
		oneMin50 = new CMenuItem("1:50");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin50);
		oneMin55 = new CMenuItem("1:55");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, oneMin55);
		twoMin = new CMenuItem("2:00");
		//Action Command
		//Action Listener
		Utils.add(timerDuration, twoMin);
		
		Utils.add(this, timerDuration);
	}
	
	private void initHostingSession() {
		hostingSessionMenu = new CMenu("Hosting Session");
		
		endSession = new CMenuItem("End Session");
		endSession.setActionCommand("End_Hosting_Session");
		endSession.addActionListener(new IsHostingListener());
		Utils.add(hostingSessionMenu, endSession);
		
		Utils.add(this, hostingSessionMenu);
	}

}
