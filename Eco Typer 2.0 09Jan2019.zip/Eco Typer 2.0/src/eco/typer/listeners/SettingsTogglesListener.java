package eco.typer.listeners;

import eco.typer.Settings.Settings;
import eco.typer.custom_frame.CustomFrame;

public class SettingsTogglesListener {
	
	public SettingsTogglesListener() {
		
	}
	
	public static void execute(String action) {
		switch(action) {
		case "Pin to Top":
			if(Settings.frame.isAlwaysOnTop())
				Settings.frame.setAlwaysOnTop(false);
			else
				Settings.frame.setAlwaysOnTop(true);
			break;
		case "Finished Alarm":
			if(CustomFrame.settingsPanel.finishedAlarm.isTicked()) {
				CustomFrame.settingsPanel.alarmSelect.setVisible(true);
				CustomFrame.settingsPanel.finishCommand.setBounds(CustomFrame.settingsPanel.finishCommand.getX(), CustomFrame.settingsPanel.finishCommand.getY() + 40, CustomFrame.settingsPanel.finishCommand.getWidth(), CustomFrame.settingsPanel.finishCommand.getHeight());
				CustomFrame.settingsPanel.typeSpeedSlider.setBounds(CustomFrame.settingsPanel.typeSpeedSlider.getX(), CustomFrame.settingsPanel.typeSpeedSlider.getY() + 40, CustomFrame.settingsPanel.typeSpeedSlider.getWidth(), CustomFrame.settingsPanel.typeSpeedSlider.getHeight());
			}
			else {
				CustomFrame.settingsPanel.alarmSelect.setVisible(false);
				CustomFrame.settingsPanel.finishCommand.setBounds(CustomFrame.settingsPanel.finishCommand.getX(), CustomFrame.settingsPanel.finishCommand.getY() - 40, CustomFrame.settingsPanel.finishCommand.getWidth(), CustomFrame.settingsPanel.finishCommand.getHeight());
				CustomFrame.settingsPanel.typeSpeedSlider.setBounds(CustomFrame.settingsPanel.typeSpeedSlider.getX(), CustomFrame.settingsPanel.typeSpeedSlider.getY() - 40, CustomFrame.settingsPanel.typeSpeedSlider.getWidth(), CustomFrame.settingsPanel.typeSpeedSlider.getHeight());
			}
			break;
		default:
			System.err.println("Action \"" + action + "\" isn't coded in yet. Please code it in SettingsTogglesListener.java");
			break;
		}
	}

}
