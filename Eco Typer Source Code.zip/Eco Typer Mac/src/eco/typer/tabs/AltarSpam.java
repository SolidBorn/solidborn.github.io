package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.settings.*;
import eco.typer.utils.Utils;
import eco.typer.listeners.*;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class AltarSpam extends JPanel {	//This class is for the add spam -> Altar spam option

	public static CTextField hostNameF;
	private CCheckBox selectAll;
	private JLabel counterL;
	private IconLabel editSpams;
	
	public static CCheckBox spamLine1;
	public static CComboBox colorText1;
	public static CComboBox effectText1;
	public static CCheckBox spamLine2;
	public static CComboBox colorText2;
	public static CComboBox effectText2;
	public static CCheckBox spamLine3;
	public static CComboBox colorText3;
	public static CComboBox effectText3;
	public static CCheckBox spamLine4;
	public static CComboBox colorText4;
	public static CComboBox effectText4;
	public static CCheckBox spamLine5;
	public static CComboBox colorText5;
	public static CComboBox effectText5;
	public static CCheckBox spamLine6;
	public static CComboBox colorText6;
	public static CComboBox effectText6;
	
	public AltarSpam() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addHostNameField();
		addSpamLines();
		addTextEffects();
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(10, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
		CButton addSpam = new CButton("Add Spam");
		addSpam.setBounds(410, 260, 190, 30);
		addSpam.setActionCommand("Add Altar Spam");
		addSpam.addActionListener(new ButtonListener());
		add(addSpam);
	}
	
	private void addHostNameField() {
		hostNameF = new CTextField("Enter Text Here", BorderFactory.createLineBorder(Settings.PRIMARY_COLOR.darker(), 3));
		hostNameF.setBounds(10, 10, 590, 30);
		hostNameF.setBackground(null);
		hostNameF.addKeyListener(new KeyListener() {
			@Override
			public void keyReleased(KeyEvent e) {
				int charCount = hostNameF.getText().length();
				if(charCount > Settings.MAX_NAME_CHAR) {
					hostNameF.setText(hostNameF.getText().substring(0, hostNameF.getText().length() - 1));
					charCount = hostNameF.getText().length();
				}
				counterL.setText(charCount + "/" + Settings.MAX_NAME_CHAR);
			}
			@Override
			public void keyTyped(KeyEvent e) {}
			@Override
			public void keyPressed(KeyEvent e) {}
		});
		add(hostNameF);
		
		counterL = new JLabel("15/" + Settings.MAX_NAME_CHAR);
		counterL.setBounds(550, 40, 55, 30);
		counterL.setForeground(Color.WHITE.darker());
		Utils.setFont(counterL, "Neon.ttf", 16);
		add(counterL);
	}
	
	private void addSpamLines() {
		
		editSpams = new IconLabel("\uf044", "Edit Spams", 18, Color.WHITE);
		editSpams.setBounds(15, 52, 18, 18);
		editSpams.setToolTipText("Edit the preset spams to your liking");
		add(editSpams);
		
		selectAll = new CCheckBox("Select All");
		selectAll.setBounds(35, 45, 245, 30);
		checkSelected(selectAll);
		selectAll.addActionListener(e -> {
			if(selectAll.isSelected())
				selectAllSpam();
			else
				deselectAllSpam();
		});
		add(selectAll);
		
		spamLine1 = new CCheckBox(Settings.SPAM_LINE_1);
		spamLine1.setBounds(10, 75, 270, 30);
		spamLine1.setToolTipText(Settings.SPAM_LINE_1);
		checkSelected(spamLine1);
		add(spamLine1);
		
		spamLine2 = new CCheckBox(Settings.SPAM_LINE_2);
		spamLine2.setBounds(10, 105, 270, 30);
		spamLine2.setToolTipText(Settings.SPAM_LINE_2);
		checkSelected(spamLine2);
		add(spamLine2);
		
		spamLine3 = new CCheckBox(Settings.SPAM_LINE_3);
		spamLine3.setBounds(10, 135, 270, 30);
		spamLine3.setToolTipText(Settings.SPAM_LINE_3);
		checkSelected(spamLine3);
		add(spamLine3);
		
		spamLine4 = new CCheckBox(Settings.SPAM_LINE_4);
		spamLine4.setBounds(10, 165, 270, 30);
		spamLine4.setToolTipText(Settings.SPAM_LINE_4);
		checkSelected(spamLine4);
		add(spamLine4);
		
		spamLine5 = new CCheckBox(Settings.SPAM_LINE_5);
		spamLine5.setBounds(10, 195, 270, 30);
		spamLine5.setToolTipText(Settings.SPAM_LINE_5);
		checkSelected(spamLine5);
		add(spamLine5);
		
		spamLine6 = new CCheckBox(Settings.SPAM_LINE_6);
		spamLine6.setBounds(10, 225, 270, 30);
		spamLine6.setToolTipText(Settings.SPAM_LINE_6);
		checkSelected(spamLine6);
		add(spamLine6);
	}
	
	private void addTextEffects() {
		colorText1 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText1.setBounds(330, 75, 133, 30);
		colorText1.setVisible(false);
		add(colorText1);
		effectText1 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText1.setBounds(467, 75, 133, 30);
		effectText1.setVisible(false);
		add(effectText1);
		
		colorText2 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText2.setBounds(330, 105, 133, 30);
		colorText2.setVisible(false);
		add(colorText2);
		effectText2 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText2.setBounds(467, 105, 133, 30);
		effectText2.setVisible(false);
		add(effectText2);
		
		colorText3 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText3.setBounds(330, 135, 133, 30);
		colorText3.setVisible(false);
		add(colorText3);
		effectText3 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText3.setBounds(467, 	135, 133, 30);
		effectText3.setVisible(false);
		add(effectText3);
		
		colorText4 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText4.setBounds(330, 165, 133, 30);
		colorText4.setVisible(false);
		add(colorText4);
		effectText4 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText4.setBounds(467, 165, 133, 30);
		effectText4.setVisible(false);
		add(effectText4);
		
		colorText5 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText5.setBounds(330, 195, 133, 30);
		colorText5.setVisible(false);
		add(colorText5);
		effectText5 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText5.setBounds(467, 195, 133, 30);
		effectText5.setVisible(false);
		add(effectText5);
		
		colorText6 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText6.setBounds(330, 225, 133, 30);
		colorText6.setVisible(false);
		add(colorText6);
		effectText6 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText6.setBounds(467, 225, 133, 30);
		effectText6.setVisible(false);
		add(effectText6);
	}
	
	private void checkSelected(CCheckBox box) {
		box.addActionListener(e -> {
			if(box.isSelected()) {
				box.setForeground(Color.WHITE);
				checkEnabled(box, 1);
			}
			else {
				box.setForeground(Color.DARK_GRAY);
				checkEnabled(box, 0);
			}
		});
	}
	
	private void checkEnabled(CCheckBox box, int i) {
		if(i == 1) {
			if(box.getText().equals("Select All")) {
				colorText1.setVisible(true);
				effectText1.setVisible(true);
				colorText2.setVisible(true);
				effectText2.setVisible(true);
				colorText3.setVisible(true);
				effectText3.setVisible(true);
				colorText4.setVisible(true);
				effectText4.setVisible(true);
				colorText5.setVisible(true);
				effectText5.setVisible(true);
				colorText6.setVisible(true);
				effectText6.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_1)) {
				colorText1.setVisible(true);
				effectText1.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_2)) {
				colorText2.setVisible(true);
				effectText2.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_3)) {
				colorText3.setVisible(true);
				effectText3.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_4)) {
				colorText4.setVisible(true);
				effectText4.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_5)) {
				colorText5.setVisible(true);
				effectText5.setVisible(true);
			}
			if(box.getText().equals(Settings.SPAM_LINE_6)) {
				colorText6.setVisible(true);
				effectText6.setVisible(true);
			}
		}
		else {
			if(box.getText().equals("Select All")) {
				colorText1.setVisible(false);
				effectText1.setVisible(false);
				colorText2.setVisible(false);
				effectText2.setVisible(false);
				colorText3.setVisible(false);
				effectText3.setVisible(false);
				colorText4.setVisible(false);
				effectText4.setVisible(false);
				colorText5.setVisible(false);
				effectText5.setVisible(false);
				colorText6.setVisible(false);
				effectText6.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_1)) {
				colorText1.setVisible(false);
				effectText1.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_2)) {
				colorText2.setVisible(false);
				effectText2.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_3)) {
				colorText3.setVisible(false);
				effectText3.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_4)) {
				colorText4.setVisible(false);
				effectText4.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_5)) {
				colorText5.setVisible(false);
				effectText5.setVisible(false);
			}
			if(box.getText().equals(Settings.SPAM_LINE_6)) {
				colorText6.setVisible(false);
				effectText6.setVisible(false);
			}
		}
	}
	
	private void selectAllSpam() {
		spamLine1.setSelected(true);
		spamLine1.setForeground(Color.WHITE);
		spamLine2.setSelected(true);
		spamLine2.setForeground(Color.WHITE);
		spamLine3.setSelected(true);
		spamLine3.setForeground(Color.WHITE);
		spamLine4.setSelected(true);
		spamLine4.setForeground(Color.WHITE);
		spamLine5.setSelected(true);
		spamLine5.setForeground(Color.WHITE);
		spamLine6.setSelected(true);
		spamLine6.setForeground(Color.WHITE);
	}
	
	private void deselectAllSpam() {
		spamLine1.setSelected(false);
		spamLine1.setForeground(Color.DARK_GRAY);
		spamLine2.setSelected(false);
		spamLine2.setForeground(Color.DARK_GRAY);
		spamLine3.setSelected(false);
		spamLine3.setForeground(Color.DARK_GRAY);
		spamLine4.setSelected(false);
		spamLine4.setForeground(Color.DARK_GRAY);
		spamLine5.setSelected(false);
		spamLine5.setForeground(Color.DARK_GRAY);
		spamLine6.setSelected(false);
		spamLine6.setForeground(Color.DARK_GRAY);
	}
	
}
