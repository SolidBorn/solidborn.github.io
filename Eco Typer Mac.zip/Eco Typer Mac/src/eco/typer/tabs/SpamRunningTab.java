package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.listeners.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import eco.typer.settings.Settings;

@SuppressWarnings("serial")
public class SpamRunningTab extends JPanel {
	
	public static JSpinner hoursSpinner, minutesSpinner;
	private CButton setTime;
	
	public SpamRunningTab() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		JLabel spamRunningLabel = new JLabel("Spam Run Time");
		spamRunningLabel.setBounds(10, 10, 200, 30);
		spamRunningLabel.setFont(new Font("Cosmic Sans MS", Font.BOLD, 20));
		spamRunningLabel.setForeground(Color.WHITE);
		add(spamRunningLabel);
		
		SpinnerCircularListModel hoursModel = new SpinnerCircularListModel(Settings.TIME_HOURS);
		hoursSpinner = new JSpinner(hoursModel);
		hoursSpinner.setBounds(10, 40, 200, 30);
		setColors(hoursSpinner);
		add(hoursSpinner);
		
		SpinnerCircularListModel minutesModel = new SpinnerCircularListModel(Settings.TIME_MINUTES);
		minutesSpinner = new JSpinner(minutesModel);
		minutesSpinner.setBounds(10, 80, 200, 30);
		setColors(minutesSpinner);
		add(minutesSpinner);
		
		setTime = new CButton("Set Time");
		setTime.setBounds(10, 110, 150, 30);
		setTime.addActionListener(new ButtonListenerSettings());
		add(setTime);
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(10, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
	}
	
	private void setColors(JSpinner spinner) {
		JComponent editor = spinner.getEditor();
		for(int i = 0; i < editor.getComponentCount(); i++) {
			Component c = editor.getComponent(i);
			if(c instanceof JTextField) {
				((JTextField) c).setEditable(false);
				c.setForeground(Color.WHITE);
				c.setBackground(Settings.BACKGROUND_COLOR);
				((JTextField) c).setBorder(null);
				c.setFont(new Font("Cosmic Sans MS", Font.BOLD, 13));
				((JTextField) c).setHorizontalAlignment(JTextField.CENTER);
			}
		}
	}

}
