package eco.typer.panels;

import java.awt.Color;

import javax.swing.JLabel;

import eco.typer.Settings.Constants;
import eco.typer.custom_frame.CPanel;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_objects.CButton;
import eco.typer.custom_objects.CTextField;
import eco.typer.listeners.SUL;
import eco.typer.tools.Utils;

@SuppressWarnings("serial")
public class ChangePredefinedTextPanel extends CPanel {
	
	CTextField textLine1, textLine2, textLine3, textLine4, textLine5, textLine6;
	int[] yValues = new int[6];
	
	public ChangePredefinedTextPanel() {
		super("Change Defined Texts");
		
		int c = 110;
		for(int i = 0; i < 6; i++) {
			yValues[i] = c;
			c += 40;
		}
		
		ChangeTextLine1();
		ChangeTextLine2();
		ChangeTextLine3();
		ChangeTextLine4();
		ChangeTextLine5();
		ChangeTextLine6();
		WarningText();
		ChangeTextButton();
		
	}

	private void ChangeTextButton() {
		CButton changeTextButton = new CButton("Save Changes");
		changeTextButton.addMouseListener(new SUL("Save Changes."));
		changeTextButton.setBounds(410, CustomFrame.WORKPANEL_HEIGHT - 30, 190, 20);
		changeTextButton.addActionListener(e -> {
			Constants.SPAM_LINE_1 = this.textLine1.getText();
			Constants.SPAM_LINE_2 = this.textLine2.getText();
			Constants.SPAM_LINE_3 = this.textLine3.getText();
			Constants.SPAM_LINE_4 = this.textLine4.getText();
			Constants.SPAM_LINE_5 = this.textLine5.getText();
			Constants.SPAM_LINE_6 = this.textLine6.getText();
			Utils.serializeFrameData();
			CustomFrame.updateDisplay(new AddingTextPanel());
		});
		add(changeTextButton);
	}
	
	private void WarningText() {
		JLabel warningLabel = new JLabel("Make sure to include \"Name\".");
		warningLabel.setBounds(10, CustomFrame.WORKPANEL_HEIGHT - 30, CustomFrame.WORKPANEL_WIDTH - 200, 20);
		warningLabel.setForeground(Color.RED);
		warningLabel.setHorizontalAlignment(JLabel.CENTER);
		Utils.setFont(warningLabel, "Neon.ttf", 16);
		add(warningLabel);
	}

	private void ChangeTextLine1() {
		textLine1 = new CTextField(Constants.SPAM_LINE_1);
		textLine1.setBounds(10, yValues[0], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine1);
	}
	
	private void ChangeTextLine2() {
		textLine2 = new CTextField(Constants.SPAM_LINE_2);
		textLine2.setBounds(10, yValues[1], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine2);
	}
	
	private void ChangeTextLine3() {
		textLine3 = new CTextField(Constants.SPAM_LINE_3);
		textLine3.setBounds(10, yValues[2], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine3);
	}
	
	private void ChangeTextLine4() {
		textLine4 = new CTextField(Constants.SPAM_LINE_4);
		textLine4.setBounds(10, yValues[3], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine4);
	}
	
	private void ChangeTextLine5() {
		textLine5 = new CTextField(Constants.SPAM_LINE_5);
		textLine5.setBounds(10, yValues[4], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine5);
	}
	
	private void ChangeTextLine6() {
		textLine6 = new CTextField(Constants.SPAM_LINE_6);
		textLine6.setBounds(10, yValues[5], CustomFrame.WORKPANEL_WIDTH - 20, 30);
		add(textLine6);
	}

}
