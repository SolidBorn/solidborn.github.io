package tooltyper.features;

public class TyperFeatures {
	
	public static boolean screenshots = false;
	public static int screenshotIntervals = 3600;
	public static boolean screenshotTimestamps = false;
	
	public static boolean finishedAlarm = false;
	public static int executionTime = 3600;
	public static int spamInterval = 240;
	public static int finalCommand = -1;
	public static int typingSpeed = 40;
	
	
}
