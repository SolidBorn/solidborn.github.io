package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.settings.*;
import eco.typer.utils.*;
import eco.typer.listeners.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class CommunitySelector extends JPanel {
	
	//Public so any class can access these and static so an object does not need to be declared to use it
	public static CButton personalUse, altarUse;
	
	public CommunitySelector() {
		
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addPersonalButton();
		addAltarButton();
		
	}
	
	public void addPersonalButton() {
		personalUse = new CButton("Personal");
		personalUse.setBounds(170, 105, 190, 30);
		personalUse.addActionListener(new ButtonListenerCommunity());
		add(personalUse);
		
		JLabel personalIcon = new JLabel(Utils.getImage("personal.png"));
		personalIcon.setBounds(120, 80, 50, 50);
		add(personalIcon);
	}
	
	public void addAltarButton() {
		altarUse = new CButton("Altar");
		altarUse.setBounds(260, 160, 190, 30);
		altarUse.addActionListener(new ButtonListenerCommunity());
		add(altarUse);
		
		JLabel prayerIcon = new JLabel(Utils.getImage("prayer.png"));
		prayerIcon.setBounds(210, 135, 50, 50);
		add(prayerIcon);
	}

}
