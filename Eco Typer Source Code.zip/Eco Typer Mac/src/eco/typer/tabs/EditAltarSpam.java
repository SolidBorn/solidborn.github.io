package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.settings.*;
import eco.typer.listeners.*;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class EditAltarSpam extends JPanel {
	
	public static CTextField spamLineEdit1;
	public static CTextField spamLineEdit2;
	public static CTextField spamLineEdit3;
	public static CTextField spamLineEdit4;
	public static CTextField spamLineEdit5;
	public static CTextField spamLineEdit6;
	
	public EditAltarSpam() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addEditSpamLines();
		
		CButton saveChanges = new CButton("Save Changes");
		saveChanges.setBounds(410, 260, 190, 30);
		saveChanges.setActionCommand("Save New Altar Spams");
		saveChanges.addActionListener(new ButtonListener());
		add(saveChanges);
	}
	
	private void addEditSpamLines() {
		spamLineEdit1 = new CTextField(Settings.SPAM_LINE_1);
		spamLineEdit1.setBounds(10, 15, 590, 30);
		spamLineEdit1.setBackground(null);
		spamLineEdit1.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit1);
		
		spamLineEdit2 = new CTextField(Settings.SPAM_LINE_2);
		spamLineEdit2.setBounds(10, 55, 590, 30);
		spamLineEdit2.setBackground(null);
		spamLineEdit2.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit2);
		
		spamLineEdit3 = new CTextField(Settings.SPAM_LINE_3);
		spamLineEdit3.setBounds(10, 95, 590, 30);
		spamLineEdit3.setBackground(null);
		spamLineEdit3.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit3);
		
		spamLineEdit4 = new CTextField(Settings.SPAM_LINE_4);
		spamLineEdit4.setBounds(10, 135, 590, 30);
		spamLineEdit4.setBackground(null);
		spamLineEdit4.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit4);
		
		spamLineEdit5 = new CTextField(Settings.SPAM_LINE_5);
		spamLineEdit5.setBounds(10, 175, 590, 30);
		spamLineEdit5.setBackground(null);
		spamLineEdit5.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit5);
		
		spamLineEdit6 = new CTextField(Settings.SPAM_LINE_6);
		spamLineEdit6.setBounds(10, 215, 590, 30);
		spamLineEdit6.setBackground(null);
		spamLineEdit6.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60), 1));
		add(spamLineEdit6);
		
		JLabel changeNote = new JLabel("Please make sure \"Name\", \"NAME\", or \"name\" is included");
		changeNote.setBounds(5, 260, 400, 30);
		changeNote.setHorizontalAlignment(SwingConstants.CENTER);
		changeNote.setForeground(Settings.PRIMARY_COLOR);
		add(changeNote);
	}

}
