package eco.typer.tools;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Stack;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import eco.typer.Settings.Constants;
import eco.typer.custom_frame.CustomFrame;

public class Utils {
	
	public static void setFont(Component c, String fontName, float size) {
		try {
			Font font = Font.createFont(0,  Utils.class.getResource("/data/fonts/" + fontName).openStream());
			GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
			genv.registerFont(font);
			font = font.deriveFont(size);
			c.setFont(font);
		} catch(FontFormatException | IOException e) {
			Utils.writeErrorReport(e, 170);
		}
	}

	public static ImageIcon getImage(String imageName) {
		return new ImageIcon(Utils.class.getResource("/data/img/" + imageName));
	}

	public static void writeErrorReport(Exception e, int errorCode) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String sStackTrace = sw.toString(); // stack trace as a string
		
		File desktopFile = new File(System.getProperty("user.home") + "/Desktop/Eco Typer Error " + System.currentTimeMillis() + ".txt");
		try {
			PrintWriter writer = new PrintWriter(desktopFile, "UTF-8");
			writer.println("Error Code: " + errorCode);
			writer.println(sStackTrace);
			writer.close();
			JOptionPane.showMessageDialog(null, "An error file has been generated on your desktop.\nPlease send it to the developer ASAP.", "Eco Typer Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		} catch (FileNotFoundException | UnsupportedEncodingException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "Writing to file error" + desktopFile, "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}
	
	public static FrameProperities loadCache() {
		if(!Constants.CONFIGURATIONS.contains("---Edit Quick Settings---"))
			Constants.CONFIGURATIONS.add("---Edit Quick Settings---");
		if(!Constants.SAVED_FILES.contains("---Edit Files---")) {
			Constants.SAVED_FILES.add("---Edit Files---");
			Constants.SAVED_FILES.add("---Clear Text Box---");
		}
		if(!Constants.TEXT_PAGES.contains("---Edit Pages---")) {
			Constants.TEXT_PAGES.add("---Edit Pages---");
			Constants.TEXT_PAGES.add("---One Time Inputs---");
		}
		File[] files = Constants.HOST_FILES_DIRECTORY.listFiles();
		for(File f : files)
			if(f.isFile() && f.toString().contains(".cfg"))
				Constants.CONFIGURATIONS.add(f.getName().replace(".cfg", ""));
			else if(f.isFile() && f.toString().contains(".eco"))
				Constants.SAVED_FILES.add(f.getName().replaceAll(".eco", ""));
			else
				Constants.TEXT_PAGES.add(f.getName().replaceAll(".epg", ""));
		
		FrameProperities fp = null;
		if(new File(System.getProperty("user.home") + "/Eco Typer/Cache").exists())
			fp = deserializeData(fp);
		else {
			fp = new FrameProperities();
			fp.color = Color.GREEN.darker();
			fp.spam1 = "[ Name ] Free Perfect Juju Sips [ Name ]";
			fp.spam2 = "[ Name ] All The Training Essentials [ Name ]";
			fp.spam3 = "[ Name ] ><> Prayer Party <>< [ Name ]";
			fp.spam4 = "[ Name ]   <<< .H.O.S.T >>>   [ Name ]";
			fp.spam5 = "[ Name ] Come Join My House [ Name ]";
			fp.spam6 = "The Current Host Is: Name";
			fp.totalProfit = 0.0;
			fp.profitCounter = new ArrayList<MoneyCounter>();
		}
		return fp;
	}
	
	public static void serializeFrameData() {
		FrameProperities fp = new FrameProperities();
		fp.color = Constants.PRIMARY_COLOR;
		fp.spam1 = Constants.SPAM_LINE_1;
		fp.spam2 = Constants.SPAM_LINE_2;
		fp.spam3 = Constants.SPAM_LINE_3;
		fp.spam4 = Constants.SPAM_LINE_4;
		fp.spam5 = Constants.SPAM_LINE_5;
		fp.spam6 = Constants.SPAM_LINE_6;
		fp.totalProfit = Constants.totalProfit;
		fp.profitCounter = Constants.profitCounter;
		
		try {
			FileOutputStream outStream = new FileOutputStream(System.getProperty("user.home") + "/Eco Typer/Cache");
			ObjectOutputStream out = new ObjectOutputStream(outStream);
			out.writeObject(fp);
			out.close();
			outStream.close();
			System.out.println("Serialized Data now stored in " + System.getProperty("user.home") + "/Eco Typer/Cache");
		} catch (IOException e) {
			//Utils.submitErrorReport(Utils.formatError(e.getClass() + ": ", e.getMessage(), e.getStackTrace()));
			e.printStackTrace();
			Utils.writeErrorReport(e, 701);
		}
	}
	
	private static FrameProperities deserializeData(FrameProperities fp) {
		FileInputStream fileIn = null;
		ObjectInputStream in = null;
		try {
			fileIn = new FileInputStream(System.getProperty("user.home") + "/Eco Typer/Cache");
			in = new ObjectInputStream(fileIn);
			fp = (FrameProperities) in.readObject();
			in.close();
			fileIn.close();
		} catch (ClassNotFoundException | IOException e) {
			try {	//All streams should be closed prior to data manipulation
				in.close();
				fileIn.close();
			} catch (IOException e1) {
				Utils.writeErrorReport(e1, 899);
			}
			Constants.splashWindow.dispose();
			File cache_file = new File(System.getProperty("user.home") + "/Eco Typer/Cache");
			cache_file.delete();
			JOptionPane.showMessageDialog(null, "We're sorry, but the newest version of Eco Typer isn't compatiable with the cache of the older version.\nThe older version will now be deleted. Please re-start Eco Typer.", "Cache Reading Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		return fp;
	}

	public static void updateSettings(String selected) {
		File fileName = new File(Constants.HOST_FILES_DIRECTORY + "/" + selected + ".cfg");
		Stack<String> settings = new Stack<String>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(fileName));
			String line;
			while((line = reader.readLine()) != null)
				settings.push(line);
			updateSettingsBasedOnLoadedConfiguration(settings);
			reader.close();
		} catch (IOException e1) {
			Utils.writeErrorReport(e1, 500);
		}
	
	}

	private static void updateSettingsBasedOnLoadedConfiguration(Stack<String> settings) {
		CustomFrame.settingsPanel.watchRsClient.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.gameTime.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.twentyFourClock.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.finishedAlarm.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.pinToTop.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.compactMode.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.timeStamps.setTick(Boolean.parseBoolean(settings.pop()));
		CustomFrame.settingsPanel.screenshotTime.setText("Screenshots: " + settings.pop());
		CustomFrame.settingsPanel.typeSpeedSlider.setValue(Integer.parseInt(settings.pop().substring(0, 2)));
		CustomFrame.settingsPanel.finishCommand.setText(settings.pop());
		CustomFrame.settingsPanel.execTime.setText(settings.pop());
		CustomFrame.settingsPanel.spamDelay.setText(settings.pop());
		
	}
	
}