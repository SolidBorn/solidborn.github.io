package eco.typer.listeners;
import eco.typer.custom_frame.*;
import eco.typer.tabs.*;
import eco.typer.utils.*;
import eco.typer.settings.*;
import eco.typer.custom_objects.*;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		
		case "Add Spam":	//Comes from "SpamTextTab" tab in eco.typer.tabs package
			if(Utils.getTabCount() > 2)
				Toolkit.getDefaultToolkit().beep();
			else {
				CustomFrame.tabbedPane.add("Community Selector", new CommunitySelector());
				Utils.setLastTab();
				Utils.disableButtons();
			}
			break;
		
		case "Edit Spam":	//Comes from "SpamTextTab" tab in eco.typer.tabs package
			if(!SpamTextTab.textArea.getText().isEmpty()) {
				Utils.disableButtons();
				SpamTextTab.textArea.setEditable(true);
				SpamTextTab.textArea.getCaret().setVisible(true);
				SpamTextTab.textArea.setBackground(Color.DARK_GRAY);
				SpamTextTab.editSpam.setEnabled(true);
				SpamTextTab.editSpam.setText("Done Editing");
				SpamTextTab.clearAllSpam.setVisible(true);
			}
			else
				Toolkit.getDefaultToolkit().beep();
			break;
			
		case "Clear All Spam":	//Comes from "SpamTextTab" tab in eco.typer.tabs package
			SpamTextTab.textArea.setText(null);
			SpamTextTab.textArea.setEditable(false);
			SpamTextTab.textArea.getCaret().setVisible(false);
			SpamTextTab.textArea.setBackground(null);
			SpamTextTab.clearAllSpam.setVisible(false);
			SpamTextTab.editSpam.setText("Edit Spam");
			Utils.enableButtons();
			break;
			
		case "Done Editing":	//"SpamTextTab" tab in eco.typer.tabs package changes text to "Done Editing", which triggers this
			SpamTextTab.textArea.setText(SpamTextTab.textArea.getText().trim());
			SpamTextTab.textArea.setText(SpamTextTab.textArea.getText().replaceAll("(?m)^\\s", ""));
			Utils.enableButtons();
			SpamTextTab.clearAllSpam.setVisible(false);
			SpamTextTab.textArea.setEditable(false);
			SpamTextTab.textArea.getCaret().setVisible(false);
			SpamTextTab.textArea.setBackground(null);
			SpamTextTab.editSpam.setText("Edit Spam");
			break;
			
		case "Add Personal Spam":	//Comes from "CommunitySelector" tab in eco.typer.tabs package
			if(!PersonalSpam.spamLine1.isVisible() || PersonalSpam.spamLine1.getText().isEmpty())
				Toolkit.getDefaultToolkit().beep();
			else {
				addPersonalSpam();	//TODO
				Settings.HOST_NAME = "Personal (N/A)";
				Utils.enableButtons();
				Utils.closeLastTab();
			}
			break;
			
		case "Add Altar Spam":	//Comes from "CommunitySelector" tab in eco.typer.tabs package
			if((!AltarSpam.spamLine1.isSelected()) || AltarSpam.hostNameF.getText().isEmpty() || AltarSpam.hostNameF.getText().equals("Enter Text Here"))
				Toolkit.getDefaultToolkit().beep();
			else {
				addAltarSpam();
				Settings.HOST_NAME = AltarSpam.hostNameF.getText();
				Utils.enableButtons();
				Utils.closeLastTab();
			}
			break;
			
		case "Save New Altar Spams":	//Comes from "EditAltarSpam" tab in eco.typer.tabs package
			if(checkLines()) {
				Settings.SPAM_LINE_1 = EditAltarSpam.spamLineEdit1.getText();
				Settings.SPAM_LINE_2 = EditAltarSpam.spamLineEdit2.getText();
				Settings.SPAM_LINE_3 = EditAltarSpam.spamLineEdit3.getText();
				Settings.SPAM_LINE_4 = EditAltarSpam.spamLineEdit4.getText();
				Settings.SPAM_LINE_5 = EditAltarSpam.spamLineEdit5.getText();
				Settings.SPAM_LINE_6 = EditAltarSpam.spamLineEdit6.getText();
				Utils.serializeFrameData();
				Utils.enableButtons();
				Utils.closeLastTab();
			}
			else
				Toolkit.getDefaultToolkit().beep();
			break;
			
		case "Cancel":	//Called throughout the program
			Utils.closeLastTab();
			SpamTextTab.clearAllSpam.setVisible(false);
			Utils.enableButtons();
			if(SettingsTab.spamSpeed.getSelectedItem().toString().equals("Custom Delay Time")) {
				SettingsTab.spamSpeed.setEditable(true);
				SettingsTab.spamSpeed.setSelectedItem("Spam Intervals");
				SettingsTab.spamSpeed.setEditable(false);
			}
			if(SettingsTab.spamSpeed.getSelectedItem().toString().equals("Custom Time")) {
				SettingsTab.spamSpeed.setEditable(true);
				SettingsTab.spamSpeed.setSelectedItem("Execution Time");
				SettingsTab.spamSpeed.setEditable(false);
			}
			break;
		
		}

	}
	
	private boolean checkLines() {
		if(EditAltarSpam.spamLineEdit1.getText().isEmpty())
			return false;
		else if(EditAltarSpam.spamLineEdit2.getText().isEmpty())
			return false;
		else if(EditAltarSpam.spamLineEdit3.getText().isEmpty())
			return false;
		else if(EditAltarSpam.spamLineEdit4.getText().isEmpty())
			return false;
		else if(EditAltarSpam.spamLineEdit5.getText().isEmpty())
			return false;
		else if(EditAltarSpam.spamLineEdit6.getText().isEmpty())
			return false;
		else
			return true;
	}
	
	private void addPersonalSpam() {
		if(PersonalSpam.spamLine1.isVisible() && !PersonalSpam.spamLine1.getText().equals("")) {
			String hostName = PersonalSpam.spamLine1.getText();
			String textColor = PersonalSpam.colorText1.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText1.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine2.isVisible() && !PersonalSpam.spamLine2.getText().equals("")) {
			String hostName = PersonalSpam.spamLine2.getText();
			String textColor = PersonalSpam.colorText2.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText2.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine3.isVisible() && !PersonalSpam.spamLine3.getText().equals("")) {
			String hostName = PersonalSpam.spamLine3.getText();
			String textColor = PersonalSpam.colorText3.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText3.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine4.isVisible() && !PersonalSpam.spamLine4.getText().equals("")) {
			String hostName = PersonalSpam.spamLine4.getText();
			String textColor = PersonalSpam.colorText4.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText4.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine5.isVisible() && !PersonalSpam.spamLine5.getText().equals("")) {
			String hostName = PersonalSpam.spamLine5.getText();
			String textColor = PersonalSpam.colorText5.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText5.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine6.isVisible() && !PersonalSpam.spamLine6.getText().equals("")) {
			String hostName = PersonalSpam.spamLine6.getText();
			String textColor = PersonalSpam.colorText6.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText6.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(PersonalSpam.spamLine7.isVisible() && !PersonalSpam.spamLine7.getText().equals("")) {
			String hostName = PersonalSpam.spamLine7.getText();
			String textColor = PersonalSpam.colorText7.getSelectedItem().toString();
			String textEffect = PersonalSpam.effectText7.getSelectedItem().toString();
			String spamType = "personal";
			addSpamLines(spamType, null, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
	}
	
	private void addAltarSpam() {
		if(AltarSpam.spamLine1.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText1.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText1.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_1;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(AltarSpam.spamLine2.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText2.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText2.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_2;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(AltarSpam.spamLine3.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText3.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText3.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_3;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(AltarSpam.spamLine4.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText4.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText4.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_4;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(AltarSpam.spamLine5.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText5.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText5.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_5;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
		if(AltarSpam.spamLine6.isSelected()) {
			String hostName = AltarSpam.hostNameF.getText();
			String textColor = AltarSpam.colorText6.getSelectedItem().toString();
			String textEffect = AltarSpam.effectText6.getSelectedItem().toString();
			String spamType = "altar";
			String spamLine = Settings.SPAM_LINE_6;
			addSpamLines(spamType, spamLine, hostName, textColor, textEffect, SpamTextTab.textArea);
		}
	}
	
	private void addSpamLines(String spamType, String spamLine, String hostName, String textColor, String textEffect, CTextArea textArea) {
		if(hostName.equals("") || textArea.getLineCount() == 13)
			Toolkit.getDefaultToolkit().beep();
		else {
			String finalRet1 = null, finalRet2 = null, finalRet3, finalS;
			finalRet3 = (spamType.equals("altar")) ? spamLine.replaceAll("Name", hostName) : hostName;
			finalRet3 = (spamType.equals("altar")) ? finalRet3.replaceAll("name", hostName) : finalRet3;
			finalRet3 = (spamType.equals("altar")) ? finalRet3.replaceAll("NAME", hostName) : finalRet3;
			switch(textColor) {
			case "Default":
			case "Text Color":
				finalRet1 = "";
				break;
			case "Red":
				finalRet1 = "red:";
				break;
			case "White":
				finalRet1 = "white:";
				break;
			case "Green":
				finalRet1 = "green:";
				break;
			case "Cyan":
				finalRet1 = "cyan:";
				break;
			case "Purple":
				finalRet1 = "purple:";
				break;
			case "Glow 1":
				finalRet1 = "glow1:";
				break;
			case "Glow 2":
				finalRet1 = "glow2:";
				break;
			case "Glow 3":
				finalRet1 = "glow3:";
				break;
			case "Flash 1":
				finalRet1 = "flash1:";
				break;
			case "Flash 2":
				finalRet1 = "flash2:";
				break;
			case "Flash 3":
				finalRet1 = "flash3:";
				break;
				
			}
			switch(textEffect) {
			case "Default":
			case "Text Effect":
				finalRet2 = "";
				break;
			case "Scroll":
				finalRet2 = "scroll:";
				break;
			case "Wave":
				finalRet2 = "wave:";
				break;
			case "Wave 2":
				finalRet2 = "wave2:";
				break;
			case "Shake":
				finalRet2 = "shake:";
				break;
			case "Slide":
				finalRet2 = "slide:";
				break;
			}
			finalS = finalRet1 + finalRet2 + finalRet3;
			if(!textArea.getText().isEmpty())
				textArea.setText(textArea.getText().concat("\n" + finalS));
			else
				textArea.setText(finalS);
		}
	}

}
