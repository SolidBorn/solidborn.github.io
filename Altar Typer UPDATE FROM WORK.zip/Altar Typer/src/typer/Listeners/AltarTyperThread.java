package typer.Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.Timer;

import typer.Settings.Settings;
import typer.Tabs.CentralPanel;
import typer.Tools.Host;
import typer.Tools.RobotClass;
import typer.Tools.Utils;

public class AltarTyperThread implements Runnable {

	private Thread worker;
    private boolean running;
    private int timerCount;
    
    public AltarTyperThread() {
    	running = false;
    }
    
    public void start() {
    	worker = new Thread(this);
    	worker.start();
    	startTimer(Settings.antibanSettings.getStop_timer_time());
    }
    
    private void startTimer(int stop_timer_time) {
    	timerCount = stop_timer_time;
    	Timer stopTimer = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!running)
					((Timer)e.getSource()).stop();
				if(timerCount <= 0) {
					((Timer)e.getSource()).stop();
					CentralPanel.stopTyping.doClick();
				}
				Settings.frame.setTitle(Settings.FRAME_TITLE + "(" + timerCount + ")");
				timerCount--;
			}
    	});
    	stopTimer.start();
	}

	public void stop() {
    	running = false;
    }
	
	public void run() {
		running = true;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			Utils.writeErrorReport(e, 142);
		}
		CentralPanel.stopTyping.setEnabled(true);
		
		String[] texts = CentralPanel.spamTexts.getText().split("\n");
//		for(int i = 0; i < texts.length; i++)
//			texts[i] = texts[i].substring(0, texts[i].length() - 4);
//		int currentLineCount = 0;
    	String currentLineString = "";
    	boolean typeHost = false;
    	int typeHostCount = 0;
		while (running) {
        	if(typeHost == true) {
        		currentLineString = getHostSpam();
        		typeHostCount++;
        		if(typeHostCount == Settings.antibanSettings.getHostCount()) {
        			typeHost = false;
        			typeHostCount = 0;
        		}
        	} else {
        		int nextSpamIndex = getRandom(0, texts.length - 1);
    			int previousValue = Integer.parseInt(texts[nextSpamIndex].substring(texts[nextSpamIndex].length() - 3, texts[nextSpamIndex].length() - 1));
    			int errorCatch = 0;
    			while(previousValue == 0) {
    				nextSpamIndex = getRandom(0, texts.length - 1);
    				previousValue = Integer.parseInt(texts[nextSpamIndex].substring(texts[nextSpamIndex].length() - 3, texts[nextSpamIndex].length() - 1));
    				errorCatch++;
    				if(errorCatch > 1000)
    					texts = CentralPanel.spamTexts.getText().split("\n");
    			}
    			errorCatch = 0;
    			currentLineString = texts[nextSpamIndex].substring(0, texts[nextSpamIndex].length() - 4);
    			previousValue--;
    			texts[nextSpamIndex] = texts[nextSpamIndex].substring(0, texts[nextSpamIndex].length() - 4) + "%" + formatInt(previousValue) + "%";
        		typeHost = true;
        	}
        	//Now that we have gotten the current line, we can type it
        	/** TODO
        	 * Implement anti-bans
        	 * 1. Random delay times			done
        	 * 2. Random typing speed			done
        	 * 3. Random breaking				not started
        	 * 4. Stop timer					done
        	 * 5. Probability on spam			done
        	 */
        	for(char c : currentLineString.toCharArray()) {
        		RobotClass.typeCharacter(c);
        		if(!running)
        			break;
        		sleep(getRandom(Settings.antibanSettings.getType_speed_delay_min(), Settings.antibanSettings.getType_speed_delay_max()));
        	}
        	RobotClass.pressEnter();
        	sleep(getRandom(Settings.antibanSettings.getDelay_time_delay_min(), Settings.antibanSettings.getDelay_time_delay_max()));
        	
        }
	}

	private String formatInt(int previousValue) {
		if(previousValue <= 9)
			return "0" + previousValue;
		return previousValue + "";
	}

	private String getHostSpam() {
		String hostSpam = "";
		String locationAndServer = CentralPanel.serverType.getSelectedItem().toString().replace(" - ", " ");
		String[] subData = locationAndServer.split(" ");
		for(Host h : Settings.allHosts)
			if(CentralPanel.onlyVerifiedHosts.isSelected()) {
				if(h.getServer().equals(subData[0]) && h.getLocation().equals(subData[1]) && !h.getUsername().contains("*"))
					hostSpam += "\"" + h.getUsername() + "\" ";
			} else {
				if(h.getServer().equals(subData[0]) && h.getLocation().equals(subData[1]) && !h.getUsername().contains("*"))
					hostSpam += "\"" + h.getUsername() + "\" ";
				if(h.getServer().equals(subData[0]) && h.getLocation().equals(subData[1]) && !hostSpam.contains(h.getUsername()))
					hostSpam += "\"" + h.getUsername() + "\" ";
			}
				
					
		if(hostSpam.equals(""))
			if(CentralPanel.stopWhenNoHosts.isSelected()) {
				CentralPanel.stopTyping.doClick();
				JOptionPane.showMessageDialog(Settings.frame, "Stopped: No Hosts");
			} else
				return "";
		else {
			hostSpam = "Current Hosts: " + hostSpam;
			hostSpam = hostSpam.substring(0, hostSpam.length() - 1);
			hostSpam = hostSpam.replace("*", "");
			hostSpam = hostSpam.replaceAll("\" \"", "\", \"");
		}
		return hostSpam;
	}

	private int getRandom(int smallestWait, int biggestWait) {
		return new Random().nextInt(biggestWait - smallestWait + 1) + smallestWait;
	}
	
	private void sleep(int i) {
		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			Utils.writeErrorReport(e, 142);
		}
	}
	
}