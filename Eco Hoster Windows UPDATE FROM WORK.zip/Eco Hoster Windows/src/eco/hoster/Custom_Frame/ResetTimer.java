package eco.hoster.Custom_Frame;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import eco.hoster.Custom_Objects.CButton;
import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class ResetTimer extends JPanel {
	
	public static JLabel watermark;
	public static CButton resetTimerB;
	
	public ResetTimer() {
		setProperities();
		
		addWatermark();
		addResetButton();
	}

	private void setProperities() {
		setLayout(null);
		setBounds(Settings.FRAME_WIDTH - 150, 0, 150, Settings.FRAME_HEIGHT);
		setBackground(Settings.BACKGROUND_COLOR);
	}
	
	private void addWatermark() {
		watermark = new JLabel("Made by: Dakota");
		watermark.setForeground(Color.WHITE);
		watermark.setHorizontalAlignment(JLabel.CENTER);
		watermark.setBounds(0, 0, 150, Settings.FRAME_HEIGHT);
		Utils.setFont(watermark, "OpenSans-Light.ttf", 12);
		add(watermark);
	}
	
	private void addResetButton() {
		resetTimerB = new CButton("Reset Timer");
		resetTimerB.setBounds(0, 0, 150, Settings.FRAME_HEIGHT);
		resetTimerB.setVisible(false);
		Utils.add(this, resetTimerB);
	}
	
	public void showWatermark() {
		watermark.setVisible(true);
		resetTimerB.setVisible(false);
	}
	
	public void showResetTimer() {
		watermark.setVisible(false);
		resetTimerB.setVisible(true);
	}

}
