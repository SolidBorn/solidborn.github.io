package eco.typer.custom_frame;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import eco.typer.Settings.Constants;
import eco.typer.panels.ExtraSettingsPanel;
import eco.typer.panels.ProfitCounterDisplay;
import eco.typer.tools.Utils;

@SuppressWarnings("serial")
public class LeftSelectionMenu extends JPanel {
	
	private int width = 50;
	private int height = Constants.FRAME_HEIGHT - 25;
	
	private ImageContainer spamIcon;
	private ImageContainer settingsIcon;
	private ImageContainer extraSettings;
	private ImageContainer profitIcon;
	
	public LeftSelectionMenu() {
		setBackground(new Color(60, 60, 60));
		setBounds(0, 25, this.width, this.height);
		setLayout(null);
		
		spamIcon = new ImageContainer(Utils.getImage("spam_color.png"), "Spam Display");
		spamIcon.setBounds(0, 20, this.width, 43);
		add(spamIcon);
		
		settingsIcon = new ImageContainer(Utils.getImage("settings_color.png"), "Settings");
		settingsIcon.setBounds(0, 70, this.width, 43);
		add(settingsIcon);
		
		extraSettings = new ImageContainer(Utils.getImage("extraSettings_color.png"), "Theme Chooser, ScreenShot Viewer, Eco Typer Uninstaller");
		extraSettings.setBounds(0, this.height - 100, this.width, 43);
		add(extraSettings);
		
		profitIcon = new ImageContainer(Utils.getImage("profit_color.png"), "Profit Counter");
		profitIcon.setBounds(0, this.height - 50, this.width, 43);
		add(profitIcon);
		
//		playPauseIcon = new ImageContainer(Utils.getImage(""), "Start Typer");
//		playPauseIcon.setBounds(0, this.height - 50, this.width, 43);
//		add(playPauseIcon);
	}
	
	public void freeze() {
		this.spamIcon.updateIcon(Utils.getImage("spam_blackwhite.png"));
		this.spamIcon.freeze();
		this.settingsIcon.updateIcon(Utils.getImage("settings_blackwhite.png"));
		this.settingsIcon.freeze();
		this.extraSettings.setVisible(false);
		this.profitIcon.updateIcon(Utils.getImage("profit_blackwhite.png"));
		this.profitIcon.freeze();
	}
	
	public void unfreeze() {
		this.spamIcon.updateIcon(Utils.getImage("spam_color.png"));
		this.spamIcon.unfreeze();
		this.settingsIcon.updateIcon(Utils.getImage("settings_color.png"));
		this.settingsIcon.unfreeze();
		this.extraSettings.setVisible(true);
		this.profitIcon.updateIcon(Utils.getImage("profit_color.png"));
		this.profitIcon.unfreeze();
	}

}


@SuppressWarnings("serial")
class ImageContainer extends JPanel implements MouseListener {
	
	private String objectStatusText;
	private JLabel icon;
	private boolean isFrozen = false;

	public ImageContainer(ImageIcon image, String statusText) {
		setBackground(new Color(60, 60, 60));
		addMouseListener(this);
		this.objectStatusText = statusText;
		
		icon = new JLabel(image);
		add(icon);
	}
	
	public void freeze() {
		this.isFrozen = true;
	}
	
	public void unfreeze() {
		this.isFrozen = false;
	}

	public void updateIcon(ImageIcon imageIcon) {
		this.icon.setIcon(imageIcon);
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		if(!this.isFrozen) {
			this.setBackground(this.getBackground().brighter());
			CustomFrame.updateStatus(objectStatusText);
		}
	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(!this.isFrozen) {
			this.setBackground(new Color(60, 60, 60));
			CustomFrame.updateStatus(null);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(!this.isFrozen) {
			if(this.objectStatusText.equals("Spam Display")) {
				CustomFrame.updateDisplay(CustomFrame.spamDisplay);
				CustomFrame.lastVisitedPanel = CustomFrame.spamDisplay;
			}
			else if(this.objectStatusText.equals("Settings")) {
				CustomFrame.updateDisplay(CustomFrame.settingsPanel);
				CustomFrame.lastVisitedPanel = CustomFrame.settingsPanel;
			}
			else if(this.objectStatusText.equals("Theme Chooser, ScreenShot Viewer, Eco Typer Uninstaller")) {
				CustomFrame.updateDisplay(new ExtraSettingsPanel());
			}
			else if(this.objectStatusText.equals("Profit Counter")) {
				CustomFrame.updateDisplay(new ProfitCounterDisplay());
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}
	
}