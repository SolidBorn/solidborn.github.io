package eco.typer.panels;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

import eco.typer.Settings.Constants;
import eco.typer.Settings.Settings;
import eco.typer.custom_frame.CPanel;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_objects.CButton;
import eco.typer.custom_objects.CComboBox;
import eco.typer.custom_objects.CTextArea;
import eco.typer.listeners.SUL;
import eco.typer.tools.Utils;

@SuppressWarnings("serial")
public class SpamDisplay extends CPanel {
	
	public CTextArea spamLinesDisplay;
	public CButton addTextButton;
	
	public SpamDisplay() {
		super("Text Display");
		
		LoadFile();
		SpamDisplayBox();
		EditSpamButton();
		AddSpamButton();
	}
	
	private void AddSpamButton() {
		addTextButton = new CButton("Add Text");
		addTextButton.setBounds(10, CustomFrame.WORKPANEL_HEIGHT - 35, 190, 20);
		addTextButton.addMouseListener(new SUL("Add spam to the spambox"));
		addTextButton.addActionListener(e -> {
			CustomFrame.updateDisplay(new AddingTextPanel());
			addTextButton.setBackground(Constants.PRIMARY_COLOR);		//Possible bug? Weird...
							/*
							 * Whenever I click the "Add Text" button it goes dark and never resets, so I'm
							 * resetting it manually with this line. It's probably a bug I don't care to properly fix.
							 * 
							 * It has to do with the mouse never properly leaving the 'bounds' of the button,
							 * therefore never registering to revert back to the original color, this also is true
							 * for the status text of this button, which I fixed by changing mouseRelease in SUL.java
							 */
		});
		add(addTextButton);
	}

	private void EditSpamButton() {
		CButton editSpamBox = new CButton("Edit Spam Box", Constants.BACKGROUND_COLOR.brighter());
		editSpamBox.setBounds(CustomFrame.WORKPANEL_WIDTH - 150, CustomFrame.WORKPANEL_HEIGHT - 75, 140, 20);
		editSpamBox.addMouseListener(new SUL("Allows you to edit the spam manually"));
		editSpamBox.addActionListener(e -> {
			switch(editSpamBox.getText()) {
			case "Done Editing":
				CustomFrame.leftSelectionMenu.unfreeze();
				addTextButton.setEnabled(true);
				spamLinesDisplay.setText(spamLinesDisplay.getText().trim());
				spamLinesDisplay.setText(spamLinesDisplay.getText().replaceAll("(?m)^\\s", ""));
				spamLinesDisplay.setEditable(false);
				spamLinesDisplay.getCaret().setVisible(false);
				spamLinesDisplay.setBackground(Constants.BACKGROUND_COLOR);
				editSpamBox.addMouseListener(new SUL("Allows you to edit the spam manually"));
				editSpamBox.setText("Edit Spam Box");
				break;
			case "Edit Spam Box":
				if(!spamLinesDisplay.getText().isEmpty()) {
					CustomFrame.leftSelectionMenu.freeze();
					addTextButton.setEnabled(false);
					spamLinesDisplay.setEditable(true);
					spamLinesDisplay.getCaret().setVisible(true);
					spamLinesDisplay.setBackground(Constants.BACKGROUND_COLOR.brighter());
					editSpamBox.addMouseListener(new SUL("Finish Editing"));
					editSpamBox.setText("Done Editing");
				} else
					Toolkit.getDefaultToolkit().beep();
				break;
			default:
				Settings.frame.dispose();
				JOptionPane.showMessageDialog(null, "Something VERY bad happened and you should NEVER see this.\nPlease tell and show the developer\nPackage: eco.typer.panels\nClass: SpamDisplay.java");
				System.exit(0);
				break;
			}
		});
		add(editSpamBox);
	}

	private void SpamDisplayBox() {
		JPanel border = new JPanel();	//JPanel for the border around textarea
		border.setBounds(10, 90, CustomFrame.WORKPANEL_WIDTH - 20, 240);
		border.setBackground(null);
//		border.setBorder(BorderFactory.createLineBorder(Constants.PRIMARY_COLOR.darker(), 3));
//		border.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		border.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Constants.PRIMARY_COLOR, Color.CYAN));
		border.setLayout(null);
		add(border);
		
		spamLinesDisplay = new CTextArea("", Color.WHITE);
		spamLinesDisplay.setBounds(5, 5, border.getWidth() - 10, border.getHeight() - 10);
		AttachListeners(spamLinesDisplay);
		border.add(spamLinesDisplay);
	}

	private void LoadFile() {
		CComboBox fileSelector = new CComboBox("Quick File Select", Constants.SAVED_FILES);
		fileSelector.addMouseListener(new SUL("Use this to quickly load saved files."));
		fileSelector.setBounds(10, 50, 190, 30);
		fileSelector.addActionListener(e -> {
			switch(fileSelector.getSelectedIndex()) {
			case 0:
				if(!spamLinesDisplay.isEditable())
					CustomFrame.updateDisplay(new HostFileEditor());
				break;
			case 1:
				spamLinesDisplay.setText("");
				break;
			default:
				LoadInSelectedFile(fileSelector.getSelectedItem() + "");
				break;
			}
			fileSelector.setText("Quick File Select");
		});
		add(fileSelector);
	}

	private void LoadInSelectedFile(String fileName) {
		File file = new File(Constants.HOST_FILES_DIRECTORY + "/" + fileName + ".eco");
		spamLinesDisplay.setText("");
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(file));
			String line;
			while((line = reader.readLine()) != null)
				spamLinesDisplay.append(line + ",");
			spamLinesDisplay.setText(spamLinesDisplay.getText().substring(0, spamLinesDisplay.getText().length() - 1));
			spamLinesDisplay.setText(spamLinesDisplay.getText().replaceAll(",", "\n"));
			reader.close();
		} catch (IOException e1) {
			Utils.writeErrorReport(e1, 763);
		}
	}
	
	private void AttachListeners(CTextArea spamLinesDisplay2) {
		spamLinesDisplay.addKeyListener(new KeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER || (e.getKeyCode() == KeyEvent.VK_BACK_SPACE && spamLinesDisplay.getText().substring(spamLinesDisplay.getCaretPosition() - 1,  spamLinesDisplay.getCaretPosition()).equals("\n")))
					e.consume();
			}
			@Override
			public void keyTyped(KeyEvent e) {}
			@Override
			public void keyReleased(KeyEvent e) {}
			
		});
		spamLinesDisplay.getDocument().addDocumentListener(new DocumentListener() {	//Makes it so the user can not paste or altar the text any other way than manually typing it
			@Override
			public void insertUpdate(DocumentEvent e) {
				check();
			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				check();
			}
			@Override
			public void changedUpdate(DocumentEvent e) {
				check();
			}
			public void check() {
				if(spamLinesDisplay.getLineCount() > 13) {
					String content = null;
					try {
						content = spamLinesDisplay.getDocument().getText(0, spamLinesDisplay.getDocument().getLength());
					}
					catch(BadLocationException e) {
						Utils.writeErrorReport(e, 393);
					}
					int lastLineBreak = content.lastIndexOf("\n");
					try {
						spamLinesDisplay.getDocument().remove(lastLineBreak, spamLinesDisplay.getDocument().getLength() - lastLineBreak);
					} catch(BadLocationException e) {
						Utils.writeErrorReport(e, 394);
					}
				}
			}
		});
	}

	@Override
	public String toString() {
		return "Spam Display Instance";
	}

}
