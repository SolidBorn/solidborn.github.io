package eco.hoster.Custom_Objects;

import javax.swing.JCheckBoxMenuItem;

import eco.hoster.Settings.Settings;

@SuppressWarnings("serial")
public class CCheckBoxMenuItem extends JCheckBoxMenuItem {
	
	public CCheckBoxMenuItem(String text) {
		super(text);
		setForeground(Settings.PRIMARY_COLOR);
		setBackground(Settings.BACKGROUND_COLOR);
		setOpaque(true);
	}

}
