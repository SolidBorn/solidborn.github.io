package eco.hoster.Listeners;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.hoster.Custom_Frame.CustomFrame;
import eco.hoster.Custom_Objects.RightClickMenu_IsHosting;
import eco.hoster.Settings.Settings;

public class IsHostingListener implements ActionListener {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		
		case "Gave_JuJu":
			System.out.println("Show => Gave Juju");
			break;
			
		case "Recieved_Donation":
			System.out.println("Show => Recieved Donation");
			break;
			
		case "Paid_Advertiser":
			System.out.println("Show => Paid Advertiser");
			break;
			
		case "Screenshot":
			System.out.println("Show => Screenshot");
			break;
			
		case "Toggle Alarm: Off":
			Settings.soundBurnerAlarm = false;
			RightClickMenu_IsHosting.toggleAlarm.setText("Toggle Alarm: On");
			RightClickMenu_IsHosting.toggleAlarm.setActionCommand("Toggle Alarm: On");
			break;
			
		case "Toggle Alarm: On":
			Settings.soundBurnerAlarm = true;
			RightClickMenu_IsHosting.toggleAlarm.setText("Toggle Alarm: Off");
			RightClickMenu_IsHosting.toggleAlarm.setActionCommand("Toggle Alarm: Off");
			break;
			
		case "End_Hosting_Session":
			Settings.isHostActive = false;
			CustomFrame.resetTimer.showWatermark();
			//--- Below this will change
			CustomFrame.iconAndTimer.timeColor.setBackground(Color.WHITE);
			CustomFrame.iconAndTimer.title.setText(Settings.FRAME_TITLE);
			//--- Above this will change
			break;
		
		default:
			System.err.println("Unrecognized Button Command - " + e.getActionCommand());
			break;
		}
	}

}
