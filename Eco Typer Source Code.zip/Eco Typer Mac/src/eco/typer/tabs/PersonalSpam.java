package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.settings.*;
import eco.typer.listeners.*;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PersonalSpam extends JPanel {	//This class is for the add spam -> Personal Spam option
	
	private IconLabel plusSpamIcon;
	private IconLabel minusSpamIcon;

	public static CTextField spamLine1;
	public static CComboBox colorText1;
	public static CComboBox effectText1;
	public static CTextField spamLine2;
	public static CComboBox colorText2;
	public static CComboBox effectText2;
	public static CTextField spamLine3;
	public static CComboBox colorText3;
	public static CComboBox effectText3;
	public static CTextField spamLine4;
	public static CComboBox colorText4;
	public static CComboBox effectText4;
	public static CTextField spamLine5;
	public static CComboBox colorText5;
	public static CComboBox effectText5;
	public static CTextField spamLine6;
	public static CComboBox colorText6;
	public static CComboBox effectText6;
	public static CTextField spamLine7;
	public static CComboBox colorText7;
	public static CComboBox effectText7;
	
	public PersonalSpam() {
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		addIcons();
		addSpamLines();
		addTextEffects();
		
		CButton cancel = new CButton("Cancel");
		cancel.setBounds(10, 260, 190, 30);
		cancel.addActionListener(new ButtonListener());
		add(cancel);
		CButton addSpam = new CButton("Add Spam");
		addSpam.setActionCommand("Add Personal Spam");
		addSpam.setBounds(410, 260, 190, 30);
		addSpam.addActionListener(new ButtonListener());
		add(addSpam);
	}
	
	private void addIcons() {
		plusSpamIcon = new IconLabel("\uf055", "PlusPersonalLine", 15, Color.WHITE);
		plusSpamIcon.setBounds(Settings.FRAME_WIDTH - 22, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(plusSpamIcon);
		
		minusSpamIcon = new IconLabel("\uf056", "MinusPersonalLine", 15, Color.WHITE);
		minusSpamIcon.setBounds(Settings.FRAME_WIDTH - 44, Settings.FRAME_HEIGHT - 110, 18, 18);
		add(minusSpamIcon);
	}
	
	private void addSpamLines() {
		spamLine1 = new CTextField();
		spamLine1.setBounds(10, 15, 300, 30);
		spamLine1.setForeground(Color.WHITE);
		spamLine1.setVisible(false);
		addKeyCount(spamLine1);
		add(spamLine1);
		
		spamLine2 = new CTextField();
		spamLine2.setBounds(10, 45, 300, 30);
		spamLine2.setForeground(Color.WHITE);
		spamLine2.setVisible(false);
		addKeyCount(spamLine2);
		add(spamLine2);
		
		spamLine3 = new CTextField();
		spamLine3.setBounds(10, 75, 300, 30);
		spamLine3.setForeground(Color.WHITE);
		spamLine3.setVisible(false);
		addKeyCount(spamLine3);
		add(spamLine3);
		
		spamLine4 = new CTextField();
		spamLine4.setBounds(10, 105, 300, 30);
		spamLine4.setForeground(Color.WHITE);
		spamLine4.setVisible(false);
		addKeyCount(spamLine4);
		add(spamLine4);
		
		spamLine5 = new CTextField();
		spamLine5.setBounds(10, 135, 300, 30);
		spamLine5.setForeground(Color.WHITE);
		spamLine5.setVisible(false);
		addKeyCount(spamLine5);
		add(spamLine5);
		
		spamLine6 = new CTextField();
		spamLine6.setBounds(10, 165, 300, 30);
		spamLine6.setForeground(Color.WHITE);
		spamLine6.setVisible(false);
		addKeyCount(spamLine6);
		add(spamLine6);
		
		spamLine7 = new CTextField();
		spamLine7.setBounds(10, 195, 300, 30);
		spamLine7.setForeground(Color.WHITE);
		spamLine7.setVisible(false);
		addKeyCount(spamLine7);
		add(spamLine7);
	}
	
	private void addTextEffects() {
		colorText1 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText1.setBounds(330, 15, 133, 30);
		colorText1.setVisible(false);
		add(colorText1);
		effectText1 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText1.setBounds(467, 15, 133, 30);
		effectText1.setVisible(false);
		add(effectText1);
		
		colorText2 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText2.setBounds(330, 45, 133, 30);
		colorText2.setVisible(false);
		add(colorText2);
		effectText2 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText2.setBounds(467, 45, 133, 30);
		effectText2.setVisible(false);
		add(effectText2);
		
		colorText3 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText3.setBounds(330, 75, 133, 30);
		colorText3.setVisible(false);
		add(colorText3);
		effectText3 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText3.setBounds(467, 75, 133, 30);
		effectText3.setVisible(false);
		add(effectText3);
		
		colorText4 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText4.setBounds(330, 105, 133, 30);
		colorText4.setVisible(false);
		add(colorText4);
		effectText4 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText4.setBounds(467, 105, 133, 30);
		effectText4.setVisible(false);
		add(effectText4);
		
		colorText5 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText5.setBounds(330, 135, 133, 30);
		colorText5.setVisible(false);
		add(colorText5);
		effectText5 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText5.setBounds(467, 135, 133, 30);
		effectText5.setVisible(false);
		add(effectText5);
		
		colorText6 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText6.setBounds(330, 165, 133, 30);
		colorText6.setVisible(false);
		add(colorText6);
		effectText6 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText6.setBounds(467, 165, 133, 30);
		effectText6.setVisible(false);
		add(effectText6);
		
		colorText7 = new CComboBox("Text Color", Settings.TEXT_COLORS);
		colorText7.setBounds(330, 195, 133, 30);
		colorText7.setVisible(false);
		add(colorText7);
		effectText7 = new CComboBox("Text Effect", Settings.TEXT_EFFECT);
		effectText7.setBounds(467, 195, 133, 30);
		effectText7.setVisible(false);
		add(effectText7);
	}
	
	private void addKeyCount(CTextField tf) {
		tf.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {}

			@Override
			public void keyPressed(KeyEvent e) {}

			@Override
			public void keyReleased(KeyEvent e) {
				int charCount = tf.getText().length();
				if(charCount > Settings.MAX_REG_CHAR) {
					Toolkit.getDefaultToolkit().beep();
					tf.setText(tf.getText().substring(0, tf.getText().length() - 1));
					charCount = tf.getText().length();
				}
			}
			
		});
	}
	
}
