package eco.typer.listeners;

import eco.typer.Settings.Settings;

public class SettingsTogglesListener {
	
	public SettingsTogglesListener() {
		
	}
	
	public static void execute(String action, boolean beingTurnedOn) {
		switch(action) {
		case "Pin to Top":
			if(beingTurnedOn)
				Settings.frame.setAlwaysOnTop(true);
			else
				Settings.frame.setAlwaysOnTop(false);
			break;
		default:
			System.err.println("Action \"" + action + "\" isn't coded in yet. Please code it in SettingsTogglesListener.java");
			break;
		}
	}

}
