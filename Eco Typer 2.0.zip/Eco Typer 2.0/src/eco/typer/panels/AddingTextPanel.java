package eco.typer.panels;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;

import eco.typer.Settings.Constants;
import eco.typer.custom_frame.CPanel;
import eco.typer.custom_frame.CustomFrame;
import eco.typer.custom_objects.CButton;
import eco.typer.custom_objects.CComboBox;
import eco.typer.custom_objects.CTextField;
import eco.typer.listeners.SUL;
import eco.typer.tools.Utils;

@SuppressWarnings("serial")
public class AddingTextPanel extends CPanel {
	
	CTextField playerNameInputField;
	JLabel playerNameLengthLabel;
	JLabel textLine1, textLine2, textLine3, textLine4, textLine5, textLine6;
	JLabel[] labels = new JLabel[6];
	CComboBox colorText1, colorText2, colorText3, colorText4, colorText5, colorText6;
	CComboBox[] colors = new CComboBox[6];
	CComboBox effectText1, effectText2, effectText3, effectText4, effectText5, effectText6;
	CComboBox[] effects = new CComboBox[6];
	
	int[] yValues = new int[6];
	
	public AddingTextPanel() {
		super("Text Configurations");
		
		int c = 110;
		for(int i = 0; i < 6; i++) {
			yValues[i] = c;
			c += 40;
		}
		
		PlayerNameField();
		PageSelector();
		TextLine1();
		TextLine2();
		TextLine3();
		TextLine4();
		TextLine5();
		TextLine6();
		AddTextButton();
	}

	private void PageSelector() {
		CComboBox pageSelector = new CComboBox("Page Select", Constants.TEXT_PAGES);
		pageSelector.addMouseListener(new SUL("Use this to quickly change pages."));
		pageSelector.setBounds(CustomFrame.WORKPANEL_WIDTH - 200, 50, 190, 30);
		pageSelector.addActionListener(e -> {
			switch(pageSelector.getSelectedIndex()) {
			case 0:	//This is where they want to edit states
				CustomFrame.updateDisplay(new PageSelector());
//				System.err.println("I WANT TO EDIT MY STATES 1. Add Pages 2. Delete Pages");
				break;
			case 1:
				System.out.println("One Time Inputs");
				break;
			default:	//They've selected a page
				
				break;
			}
			pageSelector.setText("Page Select");
		});
		add(pageSelector);
	}

	private void AddTextButton() {
		CButton addTextButton = new CButton("Add Text");
		addTextButton.addMouseListener(new SUL("Add Text."));
		addTextButton.setBounds(410, CustomFrame.WORKPANEL_HEIGHT - 30, 190, 20);
		addTextButton.addActionListener(e -> {
			if(playerNameInputField.getText().equals("") || playerNameInputField.getText().equals("Player Name")) {
				Toolkit.getDefaultToolkit().beep();
			}
			else {
				for(int i = 0; i < 6; i++) {
					if(labels[i].getForeground().getRed() == 255) {
						String result = formatTextForRuneScape((String) colors[i].getSelectedItem(), (String) effects[i].getSelectedItem(), labels[i].getText(), playerNameInputField.getText());
						if(CustomFrame.spamDisplay.spamLinesDisplay.getText().equals(""))
							CustomFrame.spamDisplay.spamLinesDisplay.setText(result);
						else
							CustomFrame.spamDisplay.spamLinesDisplay.append("\n" + result);
					}
				}
				CustomFrame.updateDisplay(CustomFrame.lastVisitedPanel);
			}
		});
		add(addTextButton);
		
		CButton editPredefinedText = new CButton("Edit Predefined Text", Constants.BACKGROUND_COLOR.brighter());
		editPredefinedText.setBounds(0, CustomFrame.WORKPANEL_HEIGHT - 46, 200, 20);
		editPredefinedText.addMouseListener(new SUL("Allows you to change predefined text"));
		editPredefinedText.addActionListener(e -> {
			CustomFrame.updateDisplay(new ChangePredefinedTextPanel());
		});
		add(editPredefinedText);
		
	}

	private String formatTextForRuneScape(String color, String effect, String text, String playerName) {
		color = color.replaceAll("\\s+", "");
		effect = effect.replaceAll("\\s+", "");
		String result = color.toLowerCase() + ":" + effect.toLowerCase() + ":" + text;
		result = result.replace("textcolor:", "");
		result = result.replace("texteffect:", "");
		result = result.replaceAll("default:", "");
		result = result.replaceAll("(?i)Name", playerName);
		return result;
	}

	private void PlayerNameField() {
		playerNameInputField = new CTextField("Player Name", BorderFactory.createLineBorder(Constants.PRIMARY_COLOR.darker(), 1));
		playerNameInputField.setBounds(10, 50, 250, 30);
		playerNameInputField.setBackground(null);
		playerNameInputField.addKeyListener(new KeyListener() {
			@Override
			public void keyReleased(KeyEvent e) {
				int charCount = playerNameInputField.getText().length();
				if(charCount > Constants.MAX_NAME_CHARACTERS) {
					playerNameInputField.setText(playerNameInputField.getText().substring(0, playerNameInputField.getText().length() - 1));
					charCount = playerNameInputField.getText().length();
				}
				playerNameLengthLabel.setText(charCount + "/" + Constants.MAX_NAME_CHARACTERS);
			}
			@Override
			public void keyTyped(KeyEvent e) {}
			@Override
			public void keyPressed(KeyEvent e) {}
		});
		add(playerNameInputField);
		playerNameInputField.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {
				if(playerNameInputField.getText().equals("Player Name")) {
					playerNameInputField.setText(null);
					playerNameInputField.setForeground(Color.WHITE);
					playerNameLengthLabel.setText(0 + "/" + Constants.MAX_NAME_CHARACTERS);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {}
		});
		
		playerNameLengthLabel = new JLabel("Player Name".length() + "/" + Constants.MAX_NAME_CHARACTERS);
		playerNameLengthLabel.setBounds(playerNameInputField.getWidth() + 20, 60, 55, 30);
		playerNameLengthLabel.setForeground(Color.WHITE.darker());
		Utils.setFont(playerNameLengthLabel, "Neon.ttf", 16);
		add(playerNameLengthLabel);
	}

	private void TextLine1() {
		colorText1 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText1.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[0], 133, 30);
		colorText1.setMaximumRowCount(12);
		colorText1.setVisible(false);
		colors[0] = colorText1;
		add(colorText1);
		
		effectText1 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText1.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[0], 133, 30);
		effectText1.setVisible(false);
		effects[0] = effectText1;
		add(effectText1);
		
		textLine1 = new JLabel(Constants.SPAM_LINE_1);
		textLine1.setBounds(10, yValues[0], 310, 30);
		textLine1.setForeground(Color.DARK_GRAY.brighter());
		textLine1.setHorizontalAlignment(JLabel.CENTER);
		textLine1.addMouseListener(new AddingTextPanelListener(textLine1, Constants.SPAM_LINE_1, colorText1, effectText1));
		Utils.setFont(textLine1, "Neon.ttf", 16);
		labels[0] = textLine1;
		add(textLine1);
	}
	
	private void TextLine2() {
		colorText2 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText2.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[1], 133, 30);
		colorText2.setMaximumRowCount(12);
		colorText2.setVisible(false);
		colors[1] = colorText2;
		add(colorText2);
		
		effectText2 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText2.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[1], 133, 30);
		effectText2.setVisible(false);
		effects[1] = effectText2;
		add(effectText2);
		
		textLine2 = new JLabel(Constants.SPAM_LINE_2);
		textLine2.setBounds(10, yValues[1], 310, 30);
		textLine2.setForeground(Color.DARK_GRAY.brighter());
		textLine2.setHorizontalAlignment(JLabel.CENTER);
		textLine2.addMouseListener(new AddingTextPanelListener(textLine2, Constants.SPAM_LINE_2, colorText2, effectText2));
		Utils.setFont(textLine2, "Neon.ttf", 16);
		labels[1] = textLine2;
		add(textLine2);
	}
	
	private void TextLine3() {
		colorText3 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText3.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[2], 133, 30);
		colorText3.setMaximumRowCount(12);
		colorText3.setVisible(false);
		colors[2] = colorText3;
		add(colorText3);
		
		effectText3 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText3.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[2], 133, 30);
		effectText3.setVisible(false);
		effects[2] = effectText3;
		add(effectText3);
		
		textLine3 = new JLabel(Constants.SPAM_LINE_3);
		textLine3.setBounds(10, yValues[2], 310, 30);
		textLine3.setForeground(Color.DARK_GRAY.brighter());
		textLine3.setHorizontalAlignment(JLabel.CENTER);
		textLine3.addMouseListener(new AddingTextPanelListener(textLine3, Constants.SPAM_LINE_3, colorText3, effectText3));
		Utils.setFont(textLine3, "Neon.ttf", 16);
		labels[2] = textLine3;
		add(textLine3);
	}
	
	private void TextLine4() {
		colorText4 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText4.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[3], 133, 30);
		colorText4.setMaximumRowCount(12);
		colorText4.setVisible(false);
		colors[3] = colorText4;
		add(colorText4);
		
		effectText4 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText4.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[3], 133, 30);
		effectText4.setVisible(false);
		effects[3] = effectText4;
		add(effectText4);
		
		textLine4 = new JLabel(Constants.SPAM_LINE_4);
		textLine4.setBounds(10, yValues[3], 310, 30);
		textLine4.setForeground(Color.DARK_GRAY.brighter());
		textLine4.setHorizontalAlignment(JLabel.CENTER);
		textLine4.addMouseListener(new AddingTextPanelListener(textLine4, Constants.SPAM_LINE_4, colorText4, effectText4));
		Utils.setFont(textLine4, "Neon.ttf", 16);
		labels[3] = textLine4;
		add(textLine4);
	}
	
	private void TextLine5() {
		colorText5 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText5.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[4], 133, 30);
		colorText5.setMaximumRowCount(12);
		colorText5.setVisible(false);
		colors[4] = colorText5;
		add(colorText5);
		
		effectText5 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText5.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[4], 133, 30);
		effectText5.setVisible(false);
		effects[4] = effectText5;
		add(effectText5);
		
		textLine5 = new JLabel(Constants.SPAM_LINE_5);
		textLine5.setBounds(10, yValues[4], 310, 30);
		textLine5.setForeground(Color.DARK_GRAY.brighter());
		textLine5.setHorizontalAlignment(JLabel.CENTER);
		textLine5.addMouseListener(new AddingTextPanelListener(textLine5, Constants.SPAM_LINE_5, colorText5, effectText5));
		Utils.setFont(textLine5, "Neon.ttf", 16);
		labels[4] = textLine5;
		add(textLine5);
	}
	
	private void TextLine6() {
		colorText6 = new CComboBox("Text Color", Constants.TEXT_COLORS);
		colorText6.setBounds(CustomFrame.WORKPANEL_WIDTH - 280, yValues[5], 133, 30);
		colorText6.setMaximumRowCount(12);
		colorText6.setVisible(false);
		colors[5] = colorText6;
		add(colorText6);
		
		effectText6 = new CComboBox("Text Effect", Constants.TEXT_EFFECT);
		effectText6.setBounds(CustomFrame.WORKPANEL_WIDTH - 140, yValues[5], 133, 30);
		effectText6.setVisible(false);
		effects[5] = effectText6;
		add(effectText6);
		
		textLine6 = new JLabel(Constants.SPAM_LINE_6);
		textLine6.setBounds(10, yValues[5], 310, 30);
		textLine6.setForeground(Color.DARK_GRAY.brighter());
		textLine6.setHorizontalAlignment(JLabel.CENTER);
		textLine6.addMouseListener(new AddingTextPanelListener(textLine6, Constants.SPAM_LINE_6, colorText6, effectText6));
		Utils.setFont(textLine6, "Neon.ttf", 16);
		labels[5] = textLine6;
		add(textLine6);
	}

}

class AddingTextPanelListener implements MouseListener {

	JLabel label;
	String sulText;
	CComboBox effectBox;
	CComboBox colorBox;
	boolean isTicked;
	
	public AddingTextPanelListener(JLabel label, String text, CComboBox colorBox, CComboBox effectBox) {
		this.label = label;
		this.sulText = text;
		this.effectBox = effectBox;
		this.colorBox = colorBox;
		this.isTicked = false;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(this.isTicked) {
			this.isTicked = false;
			this.effectBox.setVisible(false);
			this.colorBox.setVisible(false);
			this.label.setForeground(Color.DARK_GRAY.brighter());
		} else {
			this.isTicked = true;
			this.effectBox.setVisible(true);
			this.colorBox.setVisible(true);
			this.label.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(this.isTicked == false)
			this.label.setForeground(Color.WHITE.darker());
		CustomFrame.updateStatus(sulText);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(this.isTicked == false)
			this.label.setForeground(Color.DARK_GRAY.brighter());
		CustomFrame.updateStatus("");
	}
	
}