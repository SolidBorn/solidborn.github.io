package eco.typer.listeners;
import eco.typer.custom_frame.*;
import eco.typer.utils.*;
import eco.typer.settings.*;
import eco.typer.custom_objects.*;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		
		case "Start_Hosting_Session":
			Settings.isHostActive = true;
			break;
		case "End_Hosting_Session":
			Settings.isHostActive = false;
			break;
		
		case "Move_Top_Left":
			Settings.frame.setLocation(0, 0);
			break;
		case "Move_Top_Middle":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() / 2 - Settings.FRAME_WIDTH / 2, 0);
			break;
		case "Move_Top_Right":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - Settings.FRAME_WIDTH, 0);
			break;
		
		default:
			System.err.println("Unrecognized Button Command - " + e.getActionCommand());
			break;
		}

	}

}
