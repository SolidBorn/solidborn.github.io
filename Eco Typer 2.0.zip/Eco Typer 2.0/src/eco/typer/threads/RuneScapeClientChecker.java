package eco.typer.threads;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import eco.typer.Settings.Constants;
import eco.typer.tools.Utils;

public class RuneScapeClientChecker implements Runnable {

	private Thread worker;
	private boolean running;
	
	public RuneScapeClientChecker() {
		running = false;
	}
	
	public void start() {
		worker = new Thread(this);
		worker.start();
	}
	
	public void stop() {
		running = false;
	}
	
	@Override
	public void run() {
		running = true;
		while(running) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				Utils.writeErrorReport(e, 823);
			}
			try {
				String line;
				Process p;
				if(Constants.OPERATING_SYSTEM.equals("Windows"))
					p = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
				else
					p = Runtime.getRuntime().exec("ps -e");
				BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
				boolean isRuneScapeRunning = false;
				while ((line = input.readLine()) != null) {
			    	if(line.contains("rs2client"))
			    		isRuneScapeRunning = true;
			    }
				if(isRuneScapeRunning == false) {
			    	System.err.println("RuneScape Client Closed... Stopping Typer");
			    	System.exit(0);
			    }
				input.close();
			} catch (Exception e) {
				Utils.writeErrorReport(e, 824);
			}
		}
	}

}
