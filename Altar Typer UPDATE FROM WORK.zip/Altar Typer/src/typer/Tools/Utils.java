package typer.Tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.swing.JOptionPane;

public class Utils {
	
	public static void writeErrorReport(Exception e, int errorCode) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String sStackTrace = sw.toString(); // stack trace as a string
		
		File desktopFile = new File(System.getProperty("user.home") + "/Desktop/Altar Typer Error " + System.currentTimeMillis() + ".txt");
		try {
			PrintWriter writer = new PrintWriter(desktopFile, "UTF-8");
			writer.println("Error Code: " + errorCode);
			writer.println(sStackTrace);
			writer.close();
			JOptionPane.showMessageDialog(null, "An error file has been generated on your desktop.\nPlease send it to the developer ASAP.", "Altar Typer Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		} catch (FileNotFoundException | UnsupportedEncodingException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "Writing to file error" + desktopFile, "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}

}
