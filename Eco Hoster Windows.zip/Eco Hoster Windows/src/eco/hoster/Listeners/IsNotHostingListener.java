package eco.hoster.Listeners;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.hoster.Custom_Frame.CustomFrame;
import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

public class IsNotHostingListener implements ActionListener {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
			//Hosting
		case "Start_Hosting_Session":
			Settings.isHostActive = true;
			CustomFrame.resetTimer.showResetTimer();
			//--- Below this will change
			CustomFrame.iconAndTimer.timeColor.setBackground(Color.GREEN.darker());
			CustomFrame.iconAndTimer.title.setText("Burners: 1:44");
			//--- Above this will change
			break;
			
			//Settings
		case "Theme_Picker":
			System.out.println("Show => Theme Picker");
			break;
		case "Screenshots":
			System.out.println("Show => Screenshots");
			break;
		case "Email_Me":
			Utils.openWebpage("mailto:pistonbyte5@gmail.com,loyalmodding@gmail.com?subject=Eco%20Hoster&body=Please%20type%20your%20message%20here%0A%0A*Unless%20otherwise%20noted,%20the%20email%20you%20send%20this%20from%20will%20be%20how%20we%20reply%20to%20you*");
			break;
		case "Developer_Message":
			System.out.println("Show => Developer Message");
			break;
		case "Information":
			System.out.println("Show => Information");
			break;
		case "Delete_Cache":
			System.out.println("Show => Delete Cache");
			break;
		case "Bug_Report":
			String operatingSystem = System.getProperty("os.name").replaceAll(" ", "%20");
			String javaVersion = System.getProperty("java.version").replaceAll(" ", "%20");
			Utils.openWebpage("mailto:pistonbyte5@gmail.com,loyalmodding@gmail.com?subject=Eco%20Hoster%20Bug%20Report&body=Please%20type%20the%20issue%20here%0A%0A---%20DO%20NOT%20DELETE%20---%0A--%20OS:%20" + operatingSystem + "%0A--%20Java:%20" + javaVersion + "%0A%0A*Unless%20otherwise%20noted,%20the%20email%20you%20send%20this%20from%20will%20be%20how%20we%20reply%20to%20you*%0AThank%20you%20from%20the%20Eco%20Typer%20Team%20-----");
			break;
		
			//Move Frame
		case "Move_Top_Left":
			Settings.frame.setLocation(0, 0);
			break;
		case "Move_Top_Middle":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() / 2 - Settings.FRAME_WIDTH / 2, 0);
			break;
		case "Move_Top_Right":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - Settings.FRAME_WIDTH, 0);
			break;
			
			//Exit
		case "Close Program":
			System.exit(0);
			break;
		
		default:
			System.err.println("Unrecognized Button Command - " + e.getActionCommand());
			break;
		}

	}
	
//	private void startHostingSession() {	TODO
//		Settings.isHostActive = true;
//		CustomFrameTitleBar.exit.setVisible(false);
//		CustomFrameTitleBar.mini.setVisible(false);
//		CustomFrameTitleBar.resetTimer.setVisible(true);
//	}
//	
//	private void endHostingSession() {
//		Settings.isHostActive = false;
//		CustomFrameTitleBar.exit.setVisible(true);
//		CustomFrameTitleBar.mini.setVisible(true);
//		CustomFrameTitleBar.resetTimer.setVisible(false);
//	}

}
