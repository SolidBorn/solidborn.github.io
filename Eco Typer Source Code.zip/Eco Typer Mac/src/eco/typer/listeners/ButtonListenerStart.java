package eco.typer.listeners;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.Timer;

import eco.typer.custom_frame.*;
import eco.typer.settings.*;
import eco.typer.tabs.*;
import eco.typer.utils.*;

public class ButtonListenerStart implements ActionListener {
	
	/**
	 * This class is messy, and busy, but I promise myself (and you if you need the source code) that
	 * I cleaned this code up as much as I could.
	 * I also promise if you read this, you'll know exactly what it does.
	 */
	
	public static int timeRem, timeElap, SCREENSHOT_2 = 1, BEGINNING_DELAY = 5000;
	public static String SCREENSHOT_1;
	public static Timer runTimeTimer;
	public static Thread backgroundThread;
	public static boolean RUNNING = false;

	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		case "Start":
			if(SpamTextTab.textArea.getText().equals("") || SettingsTab.spamSpeed.getSelectedItem().toString().contains("Spam") || SettingsTab.execTime.getSelectedItem().toString().contains("Time"))
				Toolkit.getDefaultToolkit().beep();
			else {
				disableSettings();
				BEGINNING_DELAY = 5000;
				RUNNING = true;
				setCompact();
				setDelayAndTime();
				displayStartEndTimes();
				startDisplayTimer();
				checkScreenshot();
				startTyping();
			}
			break;
			
		case "Stop":
			RUNNING = false;
			backgroundThread.stop();
			BEGINNING_DELAY = 5000;
			SCREENSHOT_2 = 1;
			RobotClass.releaseShift();
			SettingsTab.start.setText("Start");
			enableSettings();
			unsetCompact();
			resetVariables();
			break;
			
		case "Pause":
			runTimeTimer.stop();
			CustomFrameTitleBar.pause.setText("Resume");
			RUNNING = false;
			RobotClass.releaseShift();
			BEGINNING_DELAY = 5000;
			break;
			
		case "Resume":
			runTimeTimer.start();
			CustomFrameTitleBar.pause.setText("Pause");
			RUNNING = true;
			break;
		}
		
	}
	
	private void displayStartEndTimes() {
		SettingsTab.startTime.setText("Start Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now())));
		switch(SettingsTab.execTime.getSelectedItem().toString()) {
		case "1 Minute(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusMinutes(1))));
			break;
		case "15 Minute(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusMinutes(15))));
			break;
		case "30 Minute(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusMinutes(30))));
			break;
		case "45 Minute(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusMinutes(45))));
			break;
		case "1 Hour(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusHours(1))));
			break;
		case "2 Hour(s)":
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusHours(2))));
			break;
		default:
			SettingsTab.endTime.setText("End Time: " + (DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.now().plusHours(Settings.EXEC_HOUR).plusMinutes(Settings.EXEC_MINUTE))));
			break;
		}
	}
	
	private void setDelayAndTime() {
		//Delay
		switch(SettingsTab.spamSpeed.getSelectedItem().toString()) {
		case "0 Second(s)":
			Settings.SPAM_DELAY = 100;
			break;
		case "1 Second(s)":
			Settings.SPAM_DELAY = 1000;
			break;
		case "2 Second(s)":
			Settings.SPAM_DELAY = 2000;
			break;
		case "4 Second(s)":
			Settings.SPAM_DELAY = 4000;
			break;
		case "7 Second(s)":
			Settings.SPAM_DELAY = 7000;
			break;
		default:
			Settings.SPAM_DELAY = 1000 * Integer.parseInt(SettingsTab.spamSpeed.getSelectedItem().toString().replace(" Second(s)", ""));
			break;
		}
		//Time
		switch(SettingsTab.execTime.getSelectedItem().toString()) {
		case "1 Minute(s)":
			Settings.EXEC_HOUR = 0;
			Settings.EXEC_MINUTE = 1;
			Settings.EXEC_TIME = 60 * 1;
			break;
		case "15 Minute(s)":
			Settings.EXEC_HOUR = 0;
			Settings.EXEC_MINUTE = 15;
			Settings.EXEC_TIME = 60 * 15;
			break;
		case "30 Minute(s)":
			Settings.EXEC_HOUR = 0;
			Settings.EXEC_MINUTE = 30;
			Settings.EXEC_TIME = 60 * 30;
			break;
		case "45 Minute(s)":
			Settings.EXEC_HOUR = 0;
			Settings.EXEC_MINUTE = 45;
			Settings.EXEC_TIME = 60 * 45;
			break;
		case "1 Hour(s)":
			Settings.EXEC_HOUR = 1;
			Settings.EXEC_MINUTE = 0;
			Settings.EXEC_TIME = 60 * 61;
			break;
		case "2 Hour(s)":
			Settings.EXEC_HOUR = 2;
			Settings.EXEC_MINUTE = 0;
			Settings.EXEC_TIME = 60 * 121;
			break;
		default:
			Settings.EXEC_HOUR = Integer.parseInt(SettingsTab.execTime.getSelectedItem().toString().substring(0, 2));
			Settings.EXEC_MINUTE = Integer.parseInt(SettingsTab.execTime.getSelectedItem().toString().substring(13, 15));
			Settings.EXEC_TIME = 60 * (60 * Settings.EXEC_HOUR) + 60 * Settings.EXEC_MINUTE;
			break;
		}
	}
	
	private void startDisplayTimer() {
		timeElap = 0;
		timeRem = Settings.EXEC_TIME;
		runTimeTimer = new Timer(1000, new ActionListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				if(timeRem < 0) {	//This if statement ends / resets everything / and performs the final command
					RUNNING = false;
					backgroundThread.stop();
					BEGINNING_DELAY = 5000;
					SCREENSHOT_2 = 1;
					SettingsTab.start.setText("Start");
					resetVariables();
					enableSettings();
					unsetCompact();
					switch(SettingsTab.finishCommand.getSelectedItem().toString()) {
					case "Final Command":
					case "Do Nothing":
						SettingsTab.remainingTime.setText("Remaining Time: 00:00");
						break;
					case "Close This Program":
						System.exit(0);
						break;
					}
					((Timer)e.getSource()).stop();
				} else {
					SettingsTab.elapsedTime.setText("Elapsed Time: " + Integer.toString(timeElap / 3600) + " : " + Integer.toString((timeElap % 3600) / 60) + " : " + Integer.toString(timeElap % 60));
					SettingsTab.remainingTime.setText("Remaining Time: " + Integer.toString(timeRem / 3600) + " : " + Integer.toString((timeRem % 3600) / 60) + " : " + Integer.toString(timeRem % 60));
					CustomFrameTitleBar.title.setText(Settings.FRAME_TITLE + " (" + Integer.toString(timeRem / 3600) + " : " + Integer.toString((timeRem % 3600) / 60) + " : " + Integer.toString(timeRem % 60) + " )");
					timeRem--;
					timeElap++;
					switch(SettingsTab.hourlyScreenshot.getSelectedItem().toString()) {
					case "Screenshots: 15 Minutes":
						if(timeRem % 900 == 0)
							takeScreenshot();
						break;
					case "Screenshots: 30 Minutes":
						if(timeRem % 1800 == 0)
							takeScreenshot();
						break;
					case "Screenshots: 45 Minutes":
						if(timeRem % 2700 == 0)
							takeScreenshot();
						break;
					case "Screenshots: 1 Hour":
						if(timeRem % 3600 == 0)
							takeScreenshot();
						break;
					}
				}
			}
		});
		runTimeTimer.start();
	}
	
	private void startTyping() {
		backgroundThread = new Thread(new Runnable() {
			@SuppressWarnings("static-access")
			@Override
			public void run() {
				String[] spammerTexts = SpamTextTab.textArea.getText().split("\\n");
				List<String> spammerTextList = Arrays.asList(spammerTexts);
				int currentLine = 0;
				
				while(true) {
					if(BEGINNING_DELAY != 0) {
						try {	backgroundThread.sleep(BEGINNING_DELAY);	} catch (InterruptedException e) {}
						BEGINNING_DELAY = 0;
					}
					
					for(currentLine = 0; currentLine < spammerTextList.size(); currentLine++) {
						String line = (String) spammerTextList.get(currentLine);
						for(char value : line.toCharArray()) {
							if(RUNNING) {
								try {	backgroundThread.sleep(SettingsTab.typeSpeedSlider.getValue());	} catch (InterruptedException e) {}
								try {	RobotClass.typeCharacter(value);	} catch (AWTException e) {}
							}
						}
						if(RUNNING)
							RobotClass.pressEnter();
						try {	backgroundThread.sleep(Settings.SPAM_DELAY);	} catch (InterruptedException e) {}
					}
					currentLine = 0;
				}
			}
		});
		backgroundThread.start();
	}
	
	private void setCompact() {
		disableSettings();
		CustomFrameTitleBar.stop.setVisible(true);
		CustomFrameTitleBar.pause.setVisible(true);
		CustomFrameTitleBar.title.setBounds(0, 0, Settings.FRAME_WIDTH - 300, 25);
		if(SettingsTab.compactMode.isSelected()) {
			SettingsTab.startTime.setBounds(10, 10, 190, 30);
			SettingsTab.endTime.setBounds(210, 10, 190, 30);
			SettingsTab.elapsedTime.setBounds(410, 10, 190, 30);
			SettingsTab.remainingTime.setBounds(410, 50, 190, 30);
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - Settings.FRAME_WIDTH, 0);
			Settings.frame.setSize(Settings.FRAME_WIDTH, 25);
		}
	}
	
	private void unsetCompact() {
		enableSettings();
		CustomFrameTitleBar.stop.setVisible(false);
		CustomFrameTitleBar.pause.setVisible(false);
		CustomFrameTitleBar.title.setBounds(0, 0, Settings.FRAME_WIDTH, 25);
		CustomFrameTitleBar.title.setText(Settings.FRAME_TITLE);
		if(SettingsTab.compactMode.isSelected()) {
			SettingsTab.startTime.setBounds(10, 90, 190, 30);
			SettingsTab.endTime.setBounds(10, 130, 190, 30);
			SettingsTab.elapsedTime.setBounds(10, 170, 190, 30);
			SettingsTab.remainingTime.setBounds(10, 210, 190, 30);
			Settings.frame.setSize(Settings.FRAME_WIDTH, Settings.FRAME_HEIGHT);
		}
	}
	
	private void enableSettings() {
		SettingsTab.spamSpeed.setVisible(true);
		SettingsTab.execTime.setVisible(true);
		SettingsTab.finishCommand.setVisible(true);
		SettingsTab.loadFile.setVisible(true);
		SettingsTab.alwaysOnTop.setVisible(true);
		SettingsTab.hourlyScreenshot.setVisible(true);
		SettingsTab.developerMessage.setVisible(true);
		SettingsTab.infoForm.setVisible(true);
		SettingsTab.screenshots.setVisible(true);
		SettingsTab.compactMode.setVisible(true);
		SettingsTab.typeSpeedSlider.setVisible(true);
		SettingsTab.start.setVisible(true);
		SettingsTab.emailMe.setVisible(true);
		SettingsTab.themeChooser.setVisible(true);
		SettingsTab.ssTimeStamp.setVisible(true);
	}
	
	private void disableSettings() {
		SettingsTab.spamSpeed.setVisible(false);
		SettingsTab.execTime.setVisible(false);
		SettingsTab.finishCommand.setVisible(false);
		SettingsTab.loadFile.setVisible(false);
		SettingsTab.alwaysOnTop.setVisible(false);
		SettingsTab.hourlyScreenshot.setVisible(false);
		SettingsTab.developerMessage.setVisible(false);
		SettingsTab.infoForm.setVisible(false);
		SettingsTab.screenshots.setVisible(false);
		SettingsTab.compactMode.setVisible(false);
		SettingsTab.typeSpeedSlider.setVisible(false);
		SettingsTab.start.setVisible(false);
		SettingsTab.emailMe.setVisible(false);
		SettingsTab.themeChooser.setVisible(false);
		SettingsTab.ssTimeStamp.setVisible(false);
	}
	
	private void resetVariables() {
		Settings.EXEC_HOUR = 0;
		Settings.EXEC_MINUTE = 0;
		Settings.EXEC_TIME = 0;
		runTimeTimer.stop();
		SettingsTab.startTime.setText("Start Time:");
		SettingsTab.endTime.setText("End Time:");
		SettingsTab.elapsedTime.setText("Elapsed Time:");
		SettingsTab.remainingTime.setText("Remaining Time:");
	}
	
	private void checkScreenshot() {
		if(!SettingsTab.hourlyScreenshot.getSelectedItem().equals("Screenshots: Off")) {
			DateFormat dateFormat = new SimpleDateFormat("MM-dd-yy  (HH mm ss)");
			SCREENSHOT_1 = dateFormat.format(new Date());
			File screenshotFolder = new File(Settings.SCREENSHOT_DIR + "/" + SCREENSHOT_1);
			screenshotFolder.mkdir();
		}
	}
	
	private void takeScreenshot() {
		while(new File(Settings.SCREENSHOT_DIR + "/" + SCREENSHOT_1 + "/" + SCREENSHOT_2 + ".png").exists())
			SCREENSHOT_2++;
		String fileName = Settings.SCREENSHOT_DIR + "/" + SCREENSHOT_1 + "/" + SCREENSHOT_2 + ".png";
		if(!SettingsTab.ssTimeStamp.isSelected()) {
			Robot robot = null;
			try { robot = new Robot(); } catch (AWTException e) {}
			
			Rectangle screenRect = new Rectangle(0, 0, 0, 0);
			for(GraphicsDevice gd : GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices())
				screenRect = screenRect.union(gd.getDefaultConfiguration().getBounds());
			BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
			try {	ImageIO.write(screenFullImage, "png", new File(fileName));	} catch (IOException e) {}
		} else {
			Utils.TimeStampScreenshot(fileName);
		}
	}

}
