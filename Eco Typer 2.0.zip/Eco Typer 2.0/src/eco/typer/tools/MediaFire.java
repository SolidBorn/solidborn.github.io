package eco.typer.tools;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

/**
 * @author Dakota
 *
 */
public class MediaFire {
	
	public void download(String Download_URL, String Save_File_Path) throws Exception{
		
		String downloadLink = fetchDownloadLink(getUrlSource(Download_URL));
        saveUrl(downloadLink, Save_File_Path);
		
	}

	private static String getUrlSource(String url) throws IOException  {
		System.out.println("Connecting...");
        URL yahoo = new URL(url);
        URLConnection yc = yahoo.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(
                yc.getInputStream(), "UTF-8"));
        String inputLine;
        String total="";
        while ((inputLine = in.readLine()) != null)
           total+=inputLine;
        in.close();
        return total;
    }
	
	private static String fetchDownloadLink(String str) {
		System.out.println("Fetching download link");
        try {
            String regex = "(?=\\<)|(?<=\\>)";
            String data[] = str.split(regex);
            String found = "NOTFOUND";
            for (String dat : data) {
                if (dat.contains("DLP_mOnDownload(this)")) {
                    found = dat;
                    break;
                }
            }
            String wentthru = found.substring(found.indexOf("href=\"") + 6);
            wentthru = wentthru.substring(0, wentthru.indexOf("\""));
            return wentthru;
        } catch (Exception e) {
            Utils.writeErrorReport(e, 200);
            return "ERROR";
        }
    }
	
	private static void saveUrl(final String urlString, String filename) throws Exception {
		System.out.println("Downloading...");
        filename = filename + urlString.substring(urlString.lastIndexOf("."), urlString.length());
        BufferedInputStream in = null;
        FileOutputStream fout = null;
        try {
            in = new BufferedInputStream(new URL(urlString).openStream());
            fout = new FileOutputStream(filename);
            
            final byte data[] = new byte[1024];
            int count;
            while ((count = in.read(data, 0, 1024)) != -1) 
            {
                fout.write(data, 0, count);
            }
        } finally {
            if (in != null) {
                in.close();
            }
            if (fout != null) {
                fout.close();
            }
        }
        System.out.println("Success!");
    }

}
