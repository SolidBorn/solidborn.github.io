package typer.Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import typer.Settings.Settings;
import typer.Tabs.CentralPanel;
import typer.Tools.Utils;

public class ButtonListener implements ActionListener {
	
	private static AltarTyperThread typer;

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		case "Start Typing":
			JOptionPane.showMessageDialog(Settings.frame, "Once you press okay, you have 5 seconds\nto click in the runescape client");
			typer = new AltarTyperThread();
			typer.start();
			CentralPanel.startTyping.setEnabled(false);
			CentralPanel.spamTexts.setEditable(false);
			CentralPanel.stopTyping.setBounds(300, 200, Settings.FRAME_WIDTH - 310, 30);
			Settings.frame.setSize(Settings.FRAME_WIDTH, 300);
			break;
		case "Stop Typing":
			typer.stop();
			CentralPanel.startTyping.setEnabled(true);
			CentralPanel.stopTyping.setEnabled(false);
			CentralPanel.stopTyping.setBounds(300, Settings.FRAME_HEIGHT - 100, Settings.FRAME_WIDTH - 310, 30);
			Settings.frame.setSize(Settings.FRAME_WIDTH, Settings.FRAME_HEIGHT);
			try {
				Thread.sleep(Settings.antibanSettings.getType_speed_delay_max() * 2);
				CentralPanel.spamTexts.setEditable(true);
			} catch (InterruptedException e1) {
				Utils.writeErrorReport(e1, 942);
			}
			break;
		case "Configs":
			String configs = "Breaks per hour: " + Settings.antibanSettings.getBreaks_per_hour_min() + " - " + Settings.antibanSettings.getBreaks_per_hour_max() + "\n"
								+ "Break lengths: " + Settings.antibanSettings.getBreak_length_min() + "ms - " + Settings.antibanSettings.getBreak_length_max() + "ms\n"
								+ "\n"
								+ "Typing Speeds: " + Settings.antibanSettings.getType_speed_delay_min() + "ms - " + Settings.antibanSettings.getType_speed_delay_max() + "ms\n"
								+ "\n"
								+ "Delay lengths: " + Settings.antibanSettings.getDelay_time_delay_min() + "ms - " + Settings.antibanSettings.getDelay_time_delay_max() + "ms\n"
								+ "\n"
								+ "Stop timer: " + Settings.antibanSettings.getStop_timer_time() + "s";
			JOptionPane.showMessageDialog(Settings.frame, configs, "Configs", JOptionPane.INFORMATION_MESSAGE);
			break;
		}
		
	}
	
	

}