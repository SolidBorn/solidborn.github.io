package client.frame;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import client.watcher.RuneScapeClientChecker;

public class Frame {
	
	public static JTextArea console;
	
	public static void main(String[] args) {
		
		RuneScapeClientChecker clientChecker = new RuneScapeClientChecker();
		clientChecker.start();
		
		JFrame frame = new JFrame("Client Watcher");
		frame.setSize(600,  280);
		frame.setLayout(new BorderLayout());
		
		console = new JTextArea();
		frame.add(console, BorderLayout.CENTER);
		
		frame.setLocation(10, 10);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
