package eco.hoster.Settings;

import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import eco.hoster.Custom_Frame.CustomFrame;
import eco.hoster.Utils.Audio;

public class Settings {
	
	public static final int FRAME_WIDTH = 610;
	public static final int FRAME_HEIGHT = 25;
	public static final Color BORDER_COLOR = new Color(0, 0, 0);
	public static final Color BACKGROUND_COLOR = new Color(30, 30, 30);
	public static final Color ICON_SHADOW = new Color(0, 0, 0);
	public static final Color PRIMARY_COLOR = new Color(0, 178, 0);
	public static final Color BUTTON_DEFALT_COLOR = new Color(255, 255, 255);
	public static final String FRAME_TITLE = "Eco Hoster";
	
	public static boolean isHostActive = false;
	public static boolean soundBurnerAlarm = true;
	
	public static Audio audio = new Audio("/data/audio/Rollinginthedeep.mid");
	
	public static CustomFrame frame;	//Creates a custom frame object
	public static void main(String[] args) {
		
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			JOptionPane.showMessageDialog(null, "Fatal Error => Settings.java", "Fatal Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
		frame = new CustomFrame();
		
	}

}
