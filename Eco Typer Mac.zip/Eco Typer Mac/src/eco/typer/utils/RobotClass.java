package eco.typer.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import eco.typer.settings.Settings;

public class RobotClass {
	
	//This class should never crash, but the instance it does... Throw AWTException
	public static void typeCharacter(char c) throws AWTException {
		Robot bot = new Robot();
		//bot.setAutoDelay(10); //TODO
		if (Settings.shiftCases.contains(c)) {
			bot.keyPress(KeyEvent.VK_SHIFT);
			bot.delay(35);
		}
	    int keyStroke = Settings.mapStrokes.get(Character.toLowerCase(c));
	    bot.keyPress(keyStroke);
	    bot.keyRelease(keyStroke);
	    if (Settings.shiftCases.contains(c)) {
	    	bot.delay(35);
	    	bot.keyRelease(KeyEvent.VK_SHIFT);
	    }
		
	}
	
	public static void pressEnter() {
		try {
			Robot bot = new Robot();
			bot.delay(200);
			bot.keyPress(KeyEvent.VK_ENTER);
			bot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void releaseShift() {
		try {
			Robot releaseBot = new Robot();
			releaseBot.keyRelease(KeyEvent.VK_SHIFT);
		} catch (AWTException e) {	System.err.println("Some went wrong: RobotClass -> Release Shift");	}
		
	}
	
}
