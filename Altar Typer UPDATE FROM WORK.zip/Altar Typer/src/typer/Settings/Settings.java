package typer.Settings;

import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import typer.Tools.AntibanSettings;
import typer.Tools.Host;
import typer.Tools.HostUpdaterThread;
import typer.Tools.Utils;

/**
 * Copyright (C) © 2008 - 2017 Altar Community - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential Written by Dakota Nickel <loyalmodding@gmail.com>
 *
 * Function Advertising the clan and website to gain users Version: v0.1.0
 * [updated 11/10/2018 (MM/DD/YYYY)] Requirements: Latest version of Java
 * (Java.com) Author Dakota @ discord Im Dakota#8264
 */

public class Settings {
	
	public static final int FRAME_WIDTH = 610;
	public static final int FRAME_HEIGHT = 500;
	public static final String FRAME_TITLE = "Altar Tool - Copyrighted";
	public static final String TEXTFILE_LINK = "http://altar.rs/altartracker.txt";
	
	public static final int revision = 3;
	
	
	public static AntibanSettings antibanSettings;
	public static ArrayList<Character> shiftCases;
	public static Map<Character, Integer> mapStrokes;
	public static ArrayList<Host> allHosts;
	
	public static JFrame frame;
	public static void main(String[] args) {
		
		try {	//This line is especially important on mac because it allows it to look like the windows version
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			JOptionPane.showMessageDialog(null, "layout not supported");
			System.exit(0);
		}
		
		initializeShiftCases();
		initializeAntibanSettings();
		allHosts = new ArrayList<Host>();
		frame = new CustomFrame();
		
		System.setProperty("http.agent", "Chrome");
		HostUpdaterThread grabHosts = new HostUpdaterThread();
		grabHosts.start();
		
	}

	private static void initializeAntibanSettings() {
		File fakeConfigFile = new File(System.getProperty("user.home") + "/Desktop/AltarTyperConfigFile2.txt");
		if(!fakeConfigFile.exists()) {
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter(fakeConfigFile));
				writer.write("#BREAKS" + "\n");
				writer.write("[These are the settings for random breaks]" + "\n");
				writer.write("[Length times must be entered in milliseconds]" + "\n");
				writer.write("PER_HOUR_MIN=2" + "\n");
				writer.write("PER_HOUR_MAX=6" + "\n");
				writer.write("LENGTH_MIN=125000" + "\n");
				writer.write("LENGTH_MAX=250000" + "\n");
				writer.write("\n");
				writer.write("#TYPING_SPEED" + "\n");
				writer.write("[These are the settings for the typing speed]" + "\n");
				writer.write("[Values are entered in milliseconds, per_char must be 'true' or 'false']" + "\n");
				writer.write("DELAY_MIN=12" + "\n");
				writer.write("DELAY_MAX=37" + "\n");
				writer.write("\n");
				writer.write("#DELAY_TIME" + "\n");
				writer.write("[These are the settings for the delay timing]" + "\n");
				writer.write("[Values must be entered in milliseconds]" + "\n");
				writer.write("DELAY_MIN=798" + "\n");
				writer.write("DELAY_MAX=3632" + "\n");
				writer.write("\n");
				writer.write("#STOP_TIMER" + "\n");
				writer.write("[This is where you can set how long it'll type before stopping]" + "\n");
				writer.write("[Values must be entered in hours]" + "\n");
				writer.write("TIME=6");
				writer.write("\n");
				writer.write("#HOST_COUNT" + "\n");
				writer.write("[This is how many host spams occur for every 1 general spam]" + "\n");
				writer.write("COUNT=3");
				writer.close();
			} catch (IOException e) {
				Utils.writeErrorReport(e, 030);
			}
			JOptionPane.showMessageDialog(null, "Config file created\n" + fakeConfigFile, "Config File", JOptionPane.INFORMATION_MESSAGE);
		}
		/**
		 * Right here I have to check if that file exists, and if it doesn't then I have to make it
		 */
		antibanSettings = new AntibanSettings();
		String message = "";
		Scanner sc = null;
		try {
			sc = new Scanner(fakeConfigFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			if(!line.startsWith("[") && !line.startsWith("#") && !line.equals("")) {
				message += line;
				message += "\n";
			}
		}
		sc.close();
		
		String[] settings = message.split("\n");
		for(int i = 0; i < settings.length; i++) {
			settings[i] = settings[i].substring(settings[i].indexOf("=") + 1, settings[i].length());
		}
		try {
			antibanSettings.setBreaks_per_hour_min(Integer.parseInt(settings[0]));
			antibanSettings.setBreaks_per_hour_max(Integer.parseInt(settings[1]));
			antibanSettings.setBreak_length_min(Integer.parseInt(settings[2]));
			antibanSettings.setBreak_length_max(Integer.parseInt(settings[3]));
			antibanSettings.setType_speed_delay_min(Integer.parseInt(settings[4]));
			antibanSettings.setType_speed_delay_max(Integer.parseInt(settings[5]));
			antibanSettings.setDelay_time_delay_min(Integer.parseInt(settings[6]));
			antibanSettings.setDelay_time_delay_max(Integer.parseInt(settings[7]));
			antibanSettings.setStop_timer_time(Integer.parseInt(settings[8]) * 3600);
			antibanSettings.setHostCount(Integer.parseInt(settings[9]));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Something wen't wrong with the config file, delete it and restart.", "Error", JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}

	private static void initializeShiftCases() {
		char[] shiftC = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '{', '}', '|', ':', '<', '>', '?', '+', '"'};
		shiftCases = new ArrayList<Character>();
		for(char c : shiftC)
			shiftCases.add(c);
		mapStrokes = new HashMap<>();
		mapStrokes.put('a', KeyEvent.VK_A);
		mapStrokes.put('b',  KeyEvent.VK_B);
		mapStrokes.put('c',  KeyEvent.VK_C);
		mapStrokes.put('d',  KeyEvent.VK_D);
		mapStrokes.put('e',  KeyEvent.VK_E);
		mapStrokes.put('f',  KeyEvent.VK_F);
		mapStrokes.put('g',  KeyEvent.VK_G);
		mapStrokes.put('h',  KeyEvent.VK_H);
		mapStrokes.put('i',  KeyEvent.VK_I);
		mapStrokes.put('j',  KeyEvent.VK_J);
		mapStrokes.put('k',  KeyEvent.VK_K);
		mapStrokes.put('l',  KeyEvent.VK_L);
		mapStrokes.put('m',  KeyEvent.VK_M);
		mapStrokes.put('n',  KeyEvent.VK_N);
		mapStrokes.put('o',  KeyEvent.VK_O);
		mapStrokes.put('p',  KeyEvent.VK_P);
		mapStrokes.put('q',  KeyEvent.VK_Q);
		mapStrokes.put('r',  KeyEvent.VK_R);
		mapStrokes.put('s',  KeyEvent.VK_S);
		mapStrokes.put('t',  KeyEvent.VK_T);
		mapStrokes.put('u',  KeyEvent.VK_U);
		mapStrokes.put('v',  KeyEvent.VK_V);
		mapStrokes.put('w',  KeyEvent.VK_W);
		mapStrokes.put('x',  KeyEvent.VK_X);
		mapStrokes.put('y',  KeyEvent.VK_Y);
		mapStrokes.put('z',  KeyEvent.VK_Z);
		mapStrokes.put('`', KeyEvent.VK_BACK_QUOTE);
		mapStrokes.put('0', KeyEvent.VK_0);
		mapStrokes.put('1', KeyEvent.VK_1);
		mapStrokes.put('2', KeyEvent.VK_2);
		mapStrokes.put('3', KeyEvent.VK_3);
		mapStrokes.put('4', KeyEvent.VK_4);
		mapStrokes.put('5', KeyEvent.VK_5);
		mapStrokes.put('6', KeyEvent.VK_6);
		mapStrokes.put('7', KeyEvent.VK_7);
		mapStrokes.put('8', KeyEvent.VK_8);
		mapStrokes.put('9', KeyEvent.VK_9);
		mapStrokes.put('-', KeyEvent.VK_MINUS);
		mapStrokes.put('=', KeyEvent.VK_EQUALS);
		mapStrokes.put('\t', KeyEvent.VK_TAB);
		mapStrokes.put('\n', KeyEvent.VK_ENTER);
		mapStrokes.put('[', KeyEvent.VK_OPEN_BRACKET);
		mapStrokes.put(']', KeyEvent.VK_CLOSE_BRACKET);
		mapStrokes.put('\\', KeyEvent.VK_BACK_SLASH);
		mapStrokes.put(';', KeyEvent.VK_SEMICOLON);
		mapStrokes.put('\'', KeyEvent.VK_QUOTE);
		mapStrokes.put('\"', KeyEvent.VK_QUOTEDBL);
		mapStrokes.put(',', KeyEvent.VK_COMMA);
		mapStrokes.put('.', KeyEvent.VK_PERIOD);
		mapStrokes.put('/', KeyEvent.VK_SLASH);
		mapStrokes.put(' ', KeyEvent.VK_SPACE);
		//All the items that require shift are below
		mapStrokes.put('~', KeyEvent.VK_BACK_QUOTE);
		mapStrokes.put('!', KeyEvent.VK_1);
		mapStrokes.put('@', KeyEvent.VK_2);
		mapStrokes.put('#', KeyEvent.VK_3);
		mapStrokes.put('$', KeyEvent.VK_4);
		mapStrokes.put('%', KeyEvent.VK_5);
		mapStrokes.put('^', KeyEvent.VK_6);
		mapStrokes.put('&', KeyEvent.VK_7);
		mapStrokes.put('*', KeyEvent.VK_8);
		mapStrokes.put('(', KeyEvent.VK_9);
		mapStrokes.put(')', KeyEvent.VK_0);
		mapStrokes.put('_', KeyEvent.VK_MINUS);
		mapStrokes.put('{', KeyEvent.VK_OPEN_BRACKET);
		mapStrokes.put('}', KeyEvent.VK_CLOSE_BRACKET);
		mapStrokes.put('|', KeyEvent.VK_BACK_SLASH);
		mapStrokes.put(':', KeyEvent.VK_SEMICOLON);
		mapStrokes.put('<', KeyEvent.VK_COMMA);
		mapStrokes.put('>', KeyEvent.VK_PERIOD);
		mapStrokes.put('?', KeyEvent.VK_SLASH);
		mapStrokes.put('+', KeyEvent.VK_EQUALS);
		mapStrokes.put('"', KeyEvent.VK_QUOTE);
		//-----------------
	}

}
