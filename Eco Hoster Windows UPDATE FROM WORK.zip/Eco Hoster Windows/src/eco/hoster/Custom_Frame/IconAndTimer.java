package eco.hoster.Custom_Frame;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class IconAndTimer extends JPanel {
	
	public JLabel title;
	public JPanel timeColor;
	
	public IconAndTimer() {
		setProperities();
		
		addIcon();
		addColorBar();
		addTitle();
	}

	private void setProperities() {
		setLayout(null);
		setBounds(0, 0, 160, Settings.FRAME_HEIGHT);
		setBackground(new Color(60, 60, 60));
	}
	
	private void addIcon() {
		JLabel icon = new JLabel(Utils.getImage("iconS.png"));
		icon.setBounds(3, -2, 24, 28);
		add(icon);
	}
	
	private void addColorBar() {
		timeColor = new JPanel();
		timeColor.setBackground(Color.WHITE);
		timeColor.setBounds(30, 0, 10, Settings.FRAME_HEIGHT);
		add(timeColor);
	}
	
	private void addTitle() {
		title = new JLabel(Settings.FRAME_TITLE);
		title.setForeground(Color.WHITE);
		Utils.setFont(title, "OpenSans-Regular.ttf", 18);
		title.setBounds(45, 0, 160 - 45, Settings.FRAME_HEIGHT);
		add(title);
	}

}
