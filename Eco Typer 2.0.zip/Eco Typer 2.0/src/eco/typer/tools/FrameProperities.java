package eco.typer.tools;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class FrameProperities implements Serializable {
	
	public Color color;
	public String spam1;
	public String spam2;
	public String spam3;
	public String spam4;
	public String spam5;
	public String spam6;
	public double totalProfit;
	public ArrayList<MoneyCounter> profitCounter;

}
