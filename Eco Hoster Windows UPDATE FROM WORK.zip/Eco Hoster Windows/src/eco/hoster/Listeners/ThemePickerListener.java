package eco.hoster.Listeners;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

public class ThemePickerListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		case "THEME_BLUE":
			Settings.PRIMARY_COLOR = Color.BLUE;
			doUtils();
			break;
		case "THEME_GREEN":
			Settings.PRIMARY_COLOR = Color.GREEN;
			doUtils();
			break;
			
		case "THEME_YELLOW":
			Settings.PRIMARY_COLOR = Color.YELLOW;
			doUtils();
			break;
			
		case "THEME_PINK":
			Settings.PRIMARY_COLOR = Color.PINK;
			doUtils();
			break;
			
		case "THEME_CYAN":
			Settings.PRIMARY_COLOR = Color.CYAN;
			doUtils();
			break;
			
		case "THEME_RED":
			Settings.PRIMARY_COLOR = Color.RED;
			doUtils();
			break;
			
		case "THEME_ORANGE":
			Settings.PRIMARY_COLOR = Color.ORANGE;
			doUtils();
			break;
			
		case "THEME_MAGENTA":
			Settings.PRIMARY_COLOR = Color.MAGENTA;
			doUtils();
			break;
			
		case "THEME_CUSTOM_1":
			Settings.PRIMARY_COLOR = new Color(11, 117, 115);
			doUtils();
			break;
			
		case "THEME_CUSTOM_2":
			Settings.PRIMARY_COLOR = new Color(30, 144, 255);
			doUtils();
			break;
			
		case "THEME_CUSTOM_3":
			Settings.PRIMARY_COLOR = new Color(105, 139, 34);
			doUtils();
			break;
			
		case "THEME_CUSTOM_4":
			Settings.PRIMARY_COLOR = new Color(72, 61, 139);
			doUtils();
			break;
			
		case "THEME_CUSTOM_5":
			Settings.PRIMARY_COLOR = new Color(238, 54, 0);
			doUtils();
			break;
		}
		
	}

	private void doUtils() {
		Utils.updateTheme();
		Utils.clearWorkspace();
		//TODO Searialize new frame color
	}

}
