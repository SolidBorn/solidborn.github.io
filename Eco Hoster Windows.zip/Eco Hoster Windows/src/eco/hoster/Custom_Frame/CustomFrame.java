package eco.hoster.Custom_Frame;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

import eco.hoster.Custom_Objects.RightClickMenu_IsHosting;
import eco.hoster.Custom_Objects.RightClickMenu_IsNotHosting;
import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class CustomFrame extends JFrame {
	
	public static Workspace workspace;
	public static IconAndTimer iconAndTimer;
	public static ResetTimer resetTimer;
	
	public CustomFrame() {
		
		getContentPane().setBackground(Settings.BACKGROUND_COLOR);
		setUndecorated(true);
		setTitle(Settings.FRAME_TITLE);
		setSize(Settings.FRAME_WIDTH, Settings.FRAME_HEIGHT);
		setVisible(true);
		IconAndTimer();
		ResetTimer();
		initWorkspace();
		MouseListener();
		setIconImage(Utils.getImage("iconB.png").getImage());
		setLayout(null);
		setLocationRelativeTo(null);
		setAlwaysOnTop(true);
		getRootPane().setBorder(new LineBorder(Color.BLACK));
		getContentPane().setBackground(Settings.BACKGROUND_COLOR);	//Up to here is some standards on the frame
		
		//-------------------------------------------------------
		//This is at the end so the frame can appear first, then add everything, then update itself
		//This is so people don't think the program hangs up
		revalidate();
		repaint();
		
	}

	private void IconAndTimer() {
		iconAndTimer = new IconAndTimer();
		add(iconAndTimer);
	}
	
	private void ResetTimer() {
		resetTimer = new ResetTimer();
		add(resetTimer);
	}
	
	private void initWorkspace() {
		workspace = new Workspace();
		add(workspace);
	}
	
	private void MouseListener() {	//Here down allows the custom frame to be moved like a normal frame
		RightClickMenu_IsHosting popup_IsHosting = new RightClickMenu_IsHosting();
		RightClickMenu_IsNotHosting popup_IsNotHosting = new RightClickMenu_IsNotHosting();
		addMouseListener(new MouseAdapter() {
	        public void mousePressed(MouseEvent e) {
	            if(e.getButton() == MouseEvent.BUTTON3) {
	            	workspace.rightClickNotif.setVisible(false);
	            	if(Settings.isHostActive) {
	            		popup_IsHosting.show(e.getComponent(), e.getX(), e.getY());
	            	}
	            	else if(!Settings.isHostActive) {
	            		popup_IsNotHosting.show(e.getComponent(), e.getX(), e.getY());
	            	}
	            	else {
	            		JOptionPane.showMessageDialog(null, "Fatal Error", "Error", JOptionPane.ERROR_MESSAGE);
	            	}
	            }
	        }
	    });
	}

}
