package eco.typer.settings;
import eco.typer.custom_frame.*;
import eco.typer.utils.*;
import java.awt.Color;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Settings {
	
	public static final int FRAME_WIDTH = 610;
	public static final int FRAME_HEIGHT = 25;
	public static final Color BORDER_COLOR = new Color(0, 0, 0);
	public static final Color BACKGROUND_COLOR = new Color(30, 30, 30);
	public static final Color ICON_SHADOW = new Color(0, 0, 0);
	public static Color PRIMARY_COLOR = new Color(0, 178, 0);
	public static final Color BUTTON_DEFALT_COLOR = new Color(255, 255, 255);
	public static final String FRAME_TITLE = "Eco Hoster";
	
	public static boolean isHostActive = false;
	
	public static Audio audio = new Audio("/data/audio/Fireflies.mid");
	
	public static CustomFrame frame;	//Creates a custom frame object
	public static void main(String[] args) {
		
		try {	//This line is especially important on mac because it allows it to look like the windows version
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		
		frame = new CustomFrame();
		
	}

}
