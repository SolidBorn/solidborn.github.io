package eco.hoster.Custom_Objects;

import javax.swing.JMenu;

import eco.hoster.Settings.Settings;

@SuppressWarnings("serial")
public class CMenu extends JMenu {
	
	public CMenu(String text) {
		super(text);
		setForeground(Settings.PRIMARY_COLOR);
		setBackground(Settings.BACKGROUND_COLOR);
		setOpaque(true);
	}

}
