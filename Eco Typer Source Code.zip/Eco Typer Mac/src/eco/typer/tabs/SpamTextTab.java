package eco.typer.tabs;
import eco.typer.custom_objects.*;
import eco.typer.settings.*;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

import eco.typer.listeners.ButtonListener;

@SuppressWarnings("serial")
public class SpamTextTab extends JPanel {
	
	public static CButton addSpam, clearAllSpam, editSpam; //Public so any object of this type can access it, and static so this object does not have to be declared to access it
	public static CTextArea textArea;
	
	public SpamTextTab() {
		
		setBackground(Settings.BACKGROUND_COLOR);
		setLayout(null);
		
		JPanel border = new JPanel();	//JPanel for the border around textarea
		border.setBounds(10, 10, Settings.FRAME_WIDTH - 20, 240);
		border.setBackground(null);
		border.setBorder(BorderFactory.createLineBorder(Settings.PRIMARY_COLOR.darker(), 3));
		border.setLayout(null);
		add(border);
		
		textArea = new CTextArea("", Color.WHITE);
		textArea.setBounds(10, 10, 570, 220);
		textArea.addKeyListener(new KeyListener() {	//Makes it so the user can not delete a line manually
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER || (e.getKeyCode() == KeyEvent.VK_BACK_SPACE && textArea.getText().substring(textArea.getCaretPosition() - 1,  textArea.getCaretPosition()).equals("\n")))
					e.consume();
			}
			@Override
			public void keyTyped(KeyEvent e) {}
			@Override
			public void keyReleased(KeyEvent e) {}
			
		});
		textArea.getDocument().addDocumentListener(new DocumentListener() {	//Makes it so the user can not paste or altar the text any other way than manually typing it
			@Override
			public void insertUpdate(DocumentEvent e) {
				check();
			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				check();
			}
			@Override
			public void changedUpdate(DocumentEvent e) {
				check();
			}
			public void check() {
				if(textArea.getLineCount() > 13) {
					String content = null;
					try {
						content = textArea.getDocument().getText(0, textArea.getDocument().getLength());
					}
					catch(BadLocationException e) {
						e.printStackTrace();
					}
					int lastLineBreak = content.lastIndexOf("\n");
					try {
						textArea.getDocument().remove(lastLineBreak, textArea.getDocument().getLength() - lastLineBreak);
					} catch(BadLocationException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		addSpam = new CButton("Add Spam");
		addSpam.setBounds(10, 260, 190, 30);
		addSpam.addActionListener(new ButtonListener());
		add(addSpam);
		clearAllSpam = new CButton("Clear All Spam");
		clearAllSpam.setBounds(210, 260, 190, 30);
		clearAllSpam.setVisible(false);
		clearAllSpam.addActionListener(new ButtonListener());
		add(clearAllSpam);
		editSpam = new CButton("Edit Spam");
		editSpam.setBounds(410, 260, 190, 30);
		editSpam.addActionListener(new ButtonListener());
		add(editSpam);
		
		border.add(textArea);
		
	}

}
