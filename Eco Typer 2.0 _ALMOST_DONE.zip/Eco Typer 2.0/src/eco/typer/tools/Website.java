package eco.typer.tools;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import eco.typer.Settings.Constants;
import eco.typer.Settings.Settings;

public class Website {
	
	private String websiteData;
	
	public Website() {
		String status = "Try again";
		int tryCount = 0;
		
		while(status.equals("Try again")) {
			if(Settings.speedUpBoot) break;
			try {
				URL url = new URL(Constants.TEXTFILE_LINKS[Constants.linkToConnectTo]);
			
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
				
				String line;
				while((line = reader.readLine()) != null) {
					websiteData += " " + line;
				}
				reader.close();
				
				if(!websiteData.contains("#Start Alert"))
					websiteData = "";
				else
					status = "Stop";
			} catch (StringIndexOutOfBoundsException | IOException e1) {
				Settings.splashWindowText.setText("Reading Data From Website - Trying again... " + tryCount + "/4");
				tryCount++;
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(tryCount >= 4) {
					Constants.splashWindow.dispose();
					break;
				}
			}
		}
	}
	
	public int checkForUpdate() {
		if(getVersion().equals("null"))
			return 0;	//We could not tell
		else if(!Settings.VERSION.equals(getVersion()))
			return 1;	//There is an update
		else
			return -1;	//There is no update
	}
	
	public boolean checkAlertStatus() {
		return true;
		//I need to compare frameproperities loaded in alert to Constants.ALERT to make a decision
	}

	public String getDownloadLink() {
		String webString = this.websiteData;
		if(webString == null) return "null";
				
		webString = webString.substring(webString.indexOf("#Start Download"), webString.indexOf("#End Download"));
		webString = webString.substring("#Start Download".length() + 7, webString.length());
		webString = webString.replaceAll("<br />", ",");
		webString = webString.trim();
		webString = webString.substring(0, webString.length() - 1);
		
		return webString;
	}
	
	private String getVersion() {
		String webString = this.websiteData;
		if(webString == null) return "null";		
		
		webString = webString.substring(webString.indexOf("#Start Version"), webString.indexOf("#End Version"));
		webString = webString.substring("#Start Version".length() + 7, webString.length());
		webString = webString.replaceAll("<br />", ",");
		webString = webString.trim();
		webString = webString.substring(0, webString.length() - 1);
		
		return webString;
	}
	
	public String getUpdateDesc() {
		String webString = this.websiteData;
		if(webString == null) return "null";		
		
		webString = webString.substring(webString.indexOf("#Start Update-Description"), webString.indexOf("#End Update-Description"));
		webString = webString.substring("#Start Update-Description".length() + 7, webString.length());
		webString = webString.replaceAll("<br /> ", "\n");
		webString = webString.replaceAll("&quot;", "\"");
		webString = webString.trim();
				
		return webString;
	}
	
	public String getAlert() {
		String webString = this.websiteData;
		if(webString == null) return "null";
		
		webString = webString.substring(webString.indexOf("#Start Alert"), webString.indexOf("#End Alert"));
		webString = webString.substring("#Start Alert".length() + 7, webString.length());
		webString = webString.replaceAll("<br /> ", "\n");
		webString = webString.replaceAll("&quot;", "\"");
		
		return webString;
	}

	public String getOperatingSystem() {
		String osName = System.getProperty("os.name").toLowerCase();
		if(osName.contains("window"))
			return "Windows";
		else if(osName.contains("mac"))
			return "Mac";
		else
			return "Linux";
	}

}
