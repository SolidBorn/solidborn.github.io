package eco.typer.listeners;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.typer.custom_frame.CustomFrame;
import eco.typer.utils.Utils;
import eco.typer.tabs.*;

public class ButtonListenerCommunity implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
		
		case "Personal":
			Utils.closeLastTab();
			if(CustomFrame.tabbedPane.getTabCount() > 2)
				Toolkit.getDefaultToolkit().beep();
			else {
				CustomFrame.tabbedPane.add("Personal Spam", new PersonalSpam());
				Utils.setLastTab();
				Utils.disableButtons();
			}
			break;
			
		case "Altar":
			Utils.closeLastTab();
			if(CustomFrame.tabbedPane.getTabCount() > 2)
				Toolkit.getDefaultToolkit().beep();
			else {
				CustomFrame.tabbedPane.add("Altar Spam", new AltarSpam());
				Utils.setLastTab();
				Utils.disableButtons();
			}
			break;
		
		}
		
	}
}
