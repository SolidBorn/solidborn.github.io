package eco.hoster.Listeners;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eco.hoster.Custom_Frame.CustomFrame;
import eco.hoster.Custom_Objects.CButton;
import eco.hoster.Settings.Settings;
import eco.hoster.Utils.Utils;

public class IsNotHostingListener implements ActionListener {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch(e.getActionCommand()) {
			//Hosting
		case "Start_Hosting_Session":
			Settings.isHostActive = true;
			CustomFrame.resetTimer.showResetTimer();
			//--- Below this will change
			CustomFrame.iconAndTimer.timeColor.setBackground(Color.GREEN.darker());
			CustomFrame.iconAndTimer.title.setText("Burners: 1:44");
			//--- Above this will change
			break;
			
			//Settings
		case "Theme_Picker":
			showThemePicker();
			break;
		case "Screenshots":
			System.out.println("Show => Screenshots");
			break;
		case "Email_Me":
			Utils.openWebpage("mailto:pistonbyte5@gmail.com,loyalmodding@gmail.com?subject=Eco%20Hoster&body=Please%20type%20your%20message%20here%0A%0A*Unless%20otherwise%20noted,%20the%20email%20you%20send%20this%20from%20will%20be%20how%20we%20reply%20to%20you*");
			break;
		case "Developer_Message":
			System.out.println("Show => Developer Message");
			break;
		case "Information":
			System.out.println("Show => Information");
			break;
		case "Delete_Cache":
			System.out.println("Show => Delete Cache");
			break;
		case "Bug_Report":
			String operatingSystem = System.getProperty("os.name").replaceAll(" ", "%20");
			String javaVersion = System.getProperty("java.version").replaceAll(" ", "%20");
			Utils.openWebpage("mailto:pistonbyte5@gmail.com,loyalmodding@gmail.com?subject=Eco%20Hoster%20Bug%20Report&body=Please%20type%20the%20issue%20here%0A%0A---%20DO%20NOT%20DELETE%20---%0A--%20OS:%20" + operatingSystem + "%0A--%20Java:%20" + javaVersion + "%0A%0A*Unless%20otherwise%20noted,%20the%20email%20you%20send%20this%20from%20will%20be%20how%20we%20reply%20to%20you*%0AThank%20you%20from%20the%20Eco%20Typer%20Team%20-----");
			break;
		
			//Move Frame
		case "Move_Top_Left":
			Settings.frame.setLocation(0, 0);
			break;
		case "Move_Top_Middle":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() / 2 - Settings.FRAME_WIDTH / 2, 0);
			break;
		case "Move_Top_Right":
			Settings.frame.setLocation((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - Settings.FRAME_WIDTH, 0);
			break;
			
			//Exit
		case "Close Program":
			System.exit(0);
			break;
		
		default:
			System.err.println("Unrecognized Button Command - " + e.getActionCommand());
			break;
		}

	}

	private void showThemePicker() {
		CButton blueB = new CButton(null, Color.BLUE);
		blueB.setActionCommand("THEME_BLUE");
		blueB.addActionListener(new ThemePickerListener());
		blueB.setBounds(0, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(blueB);
		
		CButton greenB = new CButton(null, Color.GREEN);
		greenB.setActionCommand("THEME_GREEN");
		greenB.addActionListener(new ThemePickerListener());
		greenB.setBounds(23, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(greenB);
		
		CButton yellowB = new CButton(null, Color.YELLOW);
		yellowB.setActionCommand("THEME_YELLOW");
		yellowB.addActionListener(new ThemePickerListener());
		yellowB.setBounds(46, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(yellowB);
		
		CButton pinkB = new CButton(null, Color.PINK);
		pinkB.setActionCommand("THEME_PINK");
		pinkB.addActionListener(new ThemePickerListener());
		pinkB.setBounds(69, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(pinkB);
		
		CButton cyanB = new CButton(null, Color.CYAN);
		cyanB.setActionCommand("THEME_CYAN");
		cyanB.addActionListener(new ThemePickerListener());
		cyanB.setBounds(92, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(cyanB);
		
		CButton redB = new CButton(null, Color.RED);
		redB.setActionCommand("THEME_RED");
		redB.addActionListener(new ThemePickerListener());
		redB.setBounds(115, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(redB);
		
		CButton orangeB = new CButton(null, Color.ORANGE);
		orangeB.setActionCommand("THEME_ORANGE");
		orangeB.addActionListener(new ThemePickerListener());
		orangeB.setBounds(138, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(orangeB);
		
		CButton magentaB = new CButton(null, Color.MAGENTA);
		magentaB.setActionCommand("THEME_MAGENTA");
		magentaB.addActionListener(new ThemePickerListener());
		magentaB.setBounds(161, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(magentaB);
		
		CButton customOneB = new CButton(null, new Color(11, 117, 115));
		customOneB.setActionCommand("THEME_CUSTOM_1");
		customOneB.addActionListener(new ThemePickerListener());
		customOneB.setBounds(184, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(customOneB);
		
		CButton customTwoB = new CButton(null, new Color(30, 144, 255));
		customTwoB.setActionCommand("THEME_CUSTOM_2");
		customTwoB.addActionListener(new ThemePickerListener());
		customTwoB.setBounds(207, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(customTwoB);
		
		CButton customThreeB = new CButton(null, new Color(105, 139, 34));
		customThreeB.setActionCommand("THEME_CUSTOM_3");
		customThreeB.addActionListener(new ThemePickerListener());
		customThreeB.setBounds(230, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(customThreeB);
		
		CButton customFourB = new CButton(null, new Color(72, 61, 139));
		customFourB.setActionCommand("THEME_CUSTOM_4");
		customFourB.addActionListener(new ThemePickerListener());
		customFourB.setBounds(253, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(customFourB);
		
		CButton customFiveB = new CButton(null, new Color(238, 54, 0));
		customFiveB.setActionCommand("THEME_CUSTOM_5");
		customFiveB.addActionListener(new ThemePickerListener());
		customFiveB.setBounds(276, 0, 18, Settings.FRAME_HEIGHT);
		CustomFrame.workspace.add(customFiveB);
		
		CustomFrame.workspace.revalidate();
		CustomFrame.workspace.repaint();
	}

}
