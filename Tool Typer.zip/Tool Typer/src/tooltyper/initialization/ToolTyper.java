package tooltyper.initialization;

import java.awt.AWTException;
import java.awt.Robot;

import tooltyper.features.TyperFeatures;

public class ToolTyper {
	
	Robot bot;
	
	
	/**
	 * <p>
	 * This method will initialize the typer.
	 * To kill the typer, call the terminate method.
	 * <p><p>
	 * <DL>
	 * <DT> <b>Defaults:</b>
	 * <DD> screenshots (take screenshots) - false
	 * <DD> <p> screenshot intervals (how long between screenshots) - 3600 seconds
	 * <DD> <p> screenshot time stamps (put a time stamp on the screenshots) - false
	 * <DD> <p> finished alarm (sound alarm when time is up) - false
	 * <DD> <p> execution time (how long the typer will run for) - 3600 seconds
	 * <DD> <p> spam interval (how long between each spam the typer will wait) - 240 seconds
	 * <DD> <p> final command (apply a command when the timer finishes) - -1 (none)
	 * <DD> typing speed (how fast the typer will type) - 40 milliseconds
	 * </DL>
	 */
	public void initialize() {
		try {
			bot = new Robot();
			System.err.println(TyperFeatures.screenshots);
		} catch (AWTException e) {
			System.err.println("TyperTool failed to initialize.");
			e.printStackTrace();
		}
	}
	
	/**
	 * <p>
	 * Toggle on or off the screenshots
	 * @param screenshots - boolean
	 */
	public static void setScreenshots(boolean screenshots) {
		TyperFeatures.screenshots = screenshots;
	}
	public static void setScreenshotIntervals(int screenshotIntervals) {
		TyperFeatures.screenshotIntervals = screenshotIntervals;
	}
	public static void setScreenshotTimestamps(boolean screenshotTimestamps) {
		TyperFeatures.screenshotTimestamps = screenshotTimestamps;
	}
	public static void setFinishedAlarm(boolean finishedAlarm) {
		TyperFeatures.finishedAlarm = finishedAlarm;
	}
	public static void setExecutionTime(int executionTime) {
		TyperFeatures.executionTime = executionTime;
	}
	public static void setSpamInterval(int spamInterval) {
		TyperFeatures.spamInterval = spamInterval;
	}
	public static void setFinalCommand(int finalCommand) {
		TyperFeatures.finalCommand = finalCommand;
	}
	public static void setTypingSpeed(int typingSpeed) {
		TyperFeatures.typingSpeed = typingSpeed;
	}
	
	/**
	 * This method will release all the resources.
	 */
	public void terminate() {
		bot = null;
		System.gc();
	}

}
