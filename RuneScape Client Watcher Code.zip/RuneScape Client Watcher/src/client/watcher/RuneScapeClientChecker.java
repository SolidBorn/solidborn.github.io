package client.watcher;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import client.frame.Frame;

public class RuneScapeClientChecker implements Runnable {

	private Thread worker;
	private boolean running;
	
	public RuneScapeClientChecker() {
		running = false;
	}
	
	public void start() {
		worker = new Thread(this);
		worker.start();
	}
	
	public void stop() {
		running = false;
	}
	
	@Override
	public void run() {
		running = true;
		while(running) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Frame.console.append("Checking for RuneScape Client...   ");
			try {
				String line;
				Process p;
				if(getOS().equals("Windows"))
					p = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
				else
					p = Runtime.getRuntime().exec("ps -e");
				BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
				boolean isRuneScapeRunning = false;
				while ((line = input.readLine()) != null) {
//					System.out.println(line);
			    	if(line.contains("rs2client") || line.contains("RuneScape")) {
			    		isRuneScapeRunning = true;
			    		System.err.println(line);
			    	}
			    }
				if(isRuneScapeRunning == false) {
					Frame.console.append(">>> RuneScape Client Unknown, Stopping Typer" + "\n");
			    } else
			    	Frame.console.append(">>> Client found!" + "\n");
				input.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private String getOS() {
		String osName = System.getProperty("os.name").toLowerCase();
		if(osName.contains("window"))
			return "Windows";
		else if(osName.contains("mac"))
			return "Mac";
		else
			return "Linux";
	}

}
