package typer.Tabs;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import typer.Listeners.ButtonListener;
import typer.Settings.Settings;

@SuppressWarnings("serial")
public class CentralPanel extends JPanel {
	
	public static DefaultTableModel tableModel;
	public static JTable hostTable;
	public static JButton startTyping, stopTyping;
	public static JComboBox<String> serverType;
	
	public static JTextArea spamTexts;
	
	public static JRadioButton randomBreaks, staticBreaks;
	public static JRadioButton randomTypeSpeed, staticTypeSpeed;
	public static JRadioButton randomDelay, staticDelay;
	
	public static JCheckBox onlyVerifiedHosts;
	
	public CentralPanel() {
		setLayout(null);
		
		HostDisplayPanel();
		AlwaysOnTop();
		OnlyVerifiedHosts();
		ShowSpams();
		StartButton();
	}

	private void OnlyVerifiedHosts() {
		onlyVerifiedHosts = new JCheckBox("Only Verified Hosts");
		onlyVerifiedHosts.setBounds(5, 240, 150, 30);
		add(onlyVerifiedHosts);
	}

	private void AlwaysOnTop() {
		JCheckBox pinToTop = new JCheckBox("Pin To Top");
		pinToTop.setBounds(5, 200, 100, 30);
		pinToTop.setSelected(true);
		pinToTop.addActionListener(e -> {
			if(pinToTop.isSelected())
				Settings.frame.setAlwaysOnTop(true);
			else
				Settings.frame.setAlwaysOnTop(false);
		});
		add(pinToTop);
	}

	private void ShowSpams() {
		String messages = "Join \"Altar\" Friends Chat for all your hosting needs!%25%" + "\n"
				+ "Always active, always friendly! - \"Altar\" Friends Chat!%10%" + "\n"
				+ "Are you a host? Add your name to our list via the Discord tracker!%05%" + "\n"
				+ "Join our discord! discord.gg/93k68sm%30%" + "\n"
				+ "Tired of looking for a host? Join \"Altar\" Friends Chat!%10%" + "\n"
				+ "Want to recieve free advertising? Join our discord%10%" + "\n"
				+ "Need an altar to train at? Join \"Altar\" FC!%10%";
		spamTexts = new JTextArea(messages);
		JScrollPane spamScroller = new JScrollPane(spamTexts);
		spamScroller.setBounds(5, Settings.FRAME_HEIGHT - 215, Settings.FRAME_WIDTH - 10, 110);
		add(spamScroller);
	}

	private void StartButton() {
		String[] servers = {"RS3 - Yanille", "RS3 - Taverly", "OSRS - Rimmington", "OSRS - Yanille"};
		serverType = new JComboBox<String>(servers);
		serverType.setBounds(5, Settings.FRAME_HEIGHT - 100, 140, 30);
		serverType.addActionListener(e -> {
			if(serverType.getSelectedItem().toString().contains("RS3"))
				spamTexts.setText(spamTexts.getText().replace("\"07 Altar\"", "\"Altar\""));
			if(serverType.getSelectedItem().toString().contains("OSRS"))
				spamTexts.setText(spamTexts.getText().replace("\"Altar\"", "\"07 Altar\""));
		});
		add(serverType);
		
		startTyping = new JButton("Start Typing");
		startTyping.setBounds(150, Settings.FRAME_HEIGHT - 100, 140, 30);
		startTyping.addActionListener(new ButtonListener());
		add(startTyping);
		
		stopTyping = new JButton("Stop Typing");
		stopTyping.setEnabled(false);
		stopTyping.setBounds(300, Settings.FRAME_HEIGHT - 100, Settings.FRAME_WIDTH - 310, 30);
		stopTyping.addActionListener(new ButtonListener());
		add(stopTyping);
		
	}

	private void HostDisplayPanel() {
		JLabel revisionLabel = new JLabel("Revision: " + Settings.revision);
		revisionLabel.setBounds(310, 5, 100, 30);
		add(revisionLabel);
		
		
		JLabel hostLabel = new JLabel("Currently Active Hosts");
		hostLabel.setBounds(5, 5, 300, 30);
		add(hostLabel);
		
		JButton seeConfigs = new JButton("Configs");
		seeConfigs.setBounds(Settings.FRAME_WIDTH - 105, 5, 100, 20);
		seeConfigs.addActionListener(new ButtonListener());
		add(seeConfigs);
		
		tableModel = new DefaultTableModel();
		String[] headers = {"Server", "Username", "World", "Location"};
		for(String s : headers)
			tableModel.addColumn(s);
		hostTable = new JTable(tableModel);
		hostTable.setEnabled(false);
		JScrollPane scrollPane = new JScrollPane(hostTable);
		scrollPane.setBounds(5, 40, Settings.FRAME_WIDTH - 10, 150);
		add(scrollPane);
	}

}
