package eco.hoster.Custom_Objects;

import javax.swing.JMenuItem;

import eco.hoster.Settings.Settings;

@SuppressWarnings("serial")
public class CMenuItem extends JMenuItem {
	
	public CMenuItem(String text) {
		super(text);
		setForeground(Settings.PRIMARY_COLOR);
		setBackground(Settings.BACKGROUND_COLOR);
		setOpaque(true);
	}

}
