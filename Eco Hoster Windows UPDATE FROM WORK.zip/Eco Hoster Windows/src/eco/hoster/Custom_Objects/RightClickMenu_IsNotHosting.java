package eco.hoster.Custom_Objects;

import javax.swing.JPopupMenu;

import eco.hoster.Listeners.IsNotHostingListener;
import eco.hoster.Utils.Utils;

@SuppressWarnings("serial")
public class RightClickMenu_IsNotHosting extends JPopupMenu {
	
	public CMenu hostingSessionMenu;
	public CMenuItem startSession;
	
	public CMenu settingsMenu;
	public CMenuItem themePicker, screenshots, emailMe, developerMessage, information, deleteCache, bugReport;
	
	public CMenu locationMenu;
	public CMenuItem top_left, top_middle, top_right;
	
	public CMenu exitMenu;
	public CMenuItem exit;
	
	public RightClickMenu_IsNotHosting() {
		initHostingSession();
		initSettings();
		initFrameLocationMenu();
		
		addSeparator();
		
		initExit();
	}

	private void initHostingSession() {
		hostingSessionMenu = new CMenu("Hosting Session");
		
		startSession = new CMenuItem("Start Session");
		startSession.setActionCommand("Start_Hosting_Session");
		startSession.addActionListener(new IsNotHostingListener());
		Utils.add(hostingSessionMenu, startSession);
		
		Utils.add(this, hostingSessionMenu);
	}
	
	private void initSettings() {
		settingsMenu = new CMenu("Settings");
		
		themePicker = new CMenuItem("Theme Picker");
		themePicker.setActionCommand("Theme_Picker");
		themePicker.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, themePicker);
		screenshots = new CMenuItem("Screenshots");
		screenshots.setActionCommand("Screenshots");
		screenshots.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, screenshots);
		emailMe = new CMenuItem("Email Me");
		emailMe.setActionCommand("Email_Me");
		emailMe.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, emailMe);
		developerMessage = new CMenuItem("Developer Message");
		developerMessage.setActionCommand("Developer_Message");
		developerMessage.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, developerMessage);
		information = new CMenuItem("Information");
		information.setActionCommand("Information");
		information.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, information);
		settingsMenu.addSeparator();
		deleteCache = new CMenuItem("Delete Cache");
		deleteCache.setActionCommand("Delete_Cache");
		deleteCache.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, deleteCache);
		bugReport = new CMenuItem("Bug Report");
		bugReport.setActionCommand("Bug_Report");
		bugReport.addActionListener(new IsNotHostingListener());
		Utils.add(settingsMenu, bugReport);
		
		Utils.add(this, settingsMenu);
	}
	
	private void initFrameLocationMenu() {
		locationMenu = new CMenu("Move Frame");
		
		top_left = new CMenuItem("Top Left");
		top_left.setActionCommand("Move_Top_Left");
		top_left.addActionListener(new IsNotHostingListener());
		Utils.add(locationMenu, top_left);
		top_middle = new CMenuItem("Top Middle");
		top_middle.setActionCommand("Move_Top_Middle");
		top_middle.addActionListener(new IsNotHostingListener());
		Utils.add(locationMenu, top_middle);
		top_right = new CMenuItem("Top Right");
		top_right.setActionCommand("Move_Top_Right");
		top_right.addActionListener(new IsNotHostingListener());
		Utils.add(locationMenu, top_right);
		
		Utils.add(this, locationMenu);
	}
	
	private void initExit() {
		exitMenu = new CMenu("Exit");
		
		exit = new CMenuItem("Close Program");
		exit.setActionCommand("Close Program");
		exit.addActionListener(new IsNotHostingListener());
		Utils.add(exitMenu, exit);
		
		Utils.add(this, exitMenu);
	}

}
